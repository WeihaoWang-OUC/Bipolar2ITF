clear

%% 划定范围
lonRange = [-49.5,16.5;31.5,115.5;153.5,287.5;0  ,360];
latRange = [-30  ,66.5;-30 ,90   ;-30  ,66   ;-90,-30];

%% 读取数据
cd D:\Desktop\work\SO&ITF\data\CESM2\areacello\
lon = ncread("areacello_Ofx_CESM2_ssp585_r4i1p1f1_gn.nc",'lon');
lat = ncread("areacello_Ofx_CESM2_ssp585_r4i1p1f1_gn.nc",'lat');
areacello = ncread("areacello_Ofx_CESM2_ssp585_r4i1p1f1_gn.nc",'areacello');
sftof = ncread("..\sftof_Ofx_CESM2_ssp585_r4i1p1f1_gn.nc",'sftof');

%% 根据范围给定mask数组
%  大西洋需分段单独算
x_mask1 = lon>=lonRange(1,1)+360 & lon<=360;
x_mask2 = lon>=0 & lon<=lonRange(1,2);
x_mask = x_mask1+x_mask2;
y_mask = lat>=latRange(1,1) & lat<=latRange(1,2);
mask = x_mask.*y_mask.*sftof/100;
S(1) = sum(areacello.*mask,"all");

%  其他大洋正常算
for i = 2:4
    x_mask = lon>=lonRange(i,1) & lon<=lonRange(i,2);
    y_mask = lat>=latRange(i,1) & lat<=latRange(i,2);
    mask = x_mask.*y_mask.*sftof/100;
    S(i) = sum(areacello.*mask,"all");
end

r1 = S(3)/sum(S(1:3),"all");%ITF/SO
r2 = S(3)/sum(S(2:3),"all");%rIP
rx1 = sum(S(2:3),"all")/sum(S(2:4),"all");%rN
ry1 = sum(S(2:3),"all")/S(1);%rS
rx2 = S(3)/sum(S(2:4),"all");
ry2 = S(3)/S(1);
