clear
modelList = {'ACCESS-CM2','ACCESS-ESM1-5','CESM2','CESM2-WACCM','CIESM','CMCC-CM2-SR5','CMCC-ESM2','CanESM5','CanESM5-1','CanESM5-CanOE','EC-Earth3-CC','GISS-E2-1-G','HadGEM3-GC31-LL','HadGEM3-GC31-MM','IPSL-CM6A-LR','MPI-ESM1-2-HR','MRI-ESM2-0','NorESM2-LM','NorESM2-MM','UKESM1-0-LL','Multimodel Mean'};
colorList = {"#0072BD",	"#D95319","#EDB120","#7E2F8E","#77AC30","#4DBEEE","#A2142F"};

%% 读入数据
cd D:\Desktop\work\SO&ITF\data\
figure(1)
clf
set(gcf,'color','white')
set(gcf,'position',[50,50,1200,1200])
set(gcf, 'DefaultTextFontName', 'Times New Roman');
ax = axes('Position', [0.1, 0.1, 0.8, 0.8]);
set(gca,'Fontsize',16,'FontName','Times New Roman')
set(gca, 'XTick', 0:1:12, 'YTick', -12:1:0);
hold on

ITF = zeros([length(modelList),1]);
IND = zeros([length(modelList),1]);
error = zeros([length(modelList),1]);

plot([0,12],[0,-12],'k--');
text(8.75, -8.75, '100%', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize',20,'Rotation',atand(-1));
plot([0,12],0.5*[0,-12],'k--');
text(8.75, -8.75*0.5, '50%', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize',20,'Rotation',atand(-0.5));
plot(0.5*[0,12],[0,-12],'k--');
text(4.5, -8.75, '150%', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize',20,'Rotation',atand(-2));
plot([0,12],0.75*[0,-12],'k--');
text(8.75, -8.75*0.75, '75%', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize',20,'Rotation',atand(-0.75));
plot(0.75*[0,12],[0,-12],'k--');
text(8.75*0.75, -8.75, '125%', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize',20,'Rotation',atand(-4/3));
plot([0,12],0.25*[0,-12],'k--');
text(8.75, -8.75*0.25, '25%', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize',20,'Rotation',atand(-0.25));
plot(0.25*[0,12],[0,-12],'k--');
text(8.75*0.25, -8.75, '175%', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize',20,'Rotation',atand(-4));
plot([0,12],0.76*[0,-12],'--','Color',.6*[1 1 1],'LineWidth',2)

for i = 1:7
    load(strcat(modelList{i},'\T.mat'),"ITFa","INDa","ITFk","PACk","INDk");
    % [INDtrend,INDlower,INDupper] = calculateError(INDa);
    % IND(i) = INDtrend;
    % [ITFtrend,ITFlower,ITFupper] = calculateError(ITFa);
    % ITF(i) = ITFtrend;
    % [xmin,ymin,xmax,ymax] = errorbar(ITFtrend,ITFlower,ITFupper,INDtrend,INDlower,INDupper);
    IND(i) = INDk(end)-INDk(1);
    PAC(i) = PACk(end)-PACk(1);
    ITF(i) = ITFk(end)-ITFk(1);
    eval(strcat('s',num2str(i),' = scatter(IND(i)+PAC(i),ITF(i)-PAC(i),300,"filled","MarkerFaceColor","',colorList{i},'");'));
    % eval(strcat('p',num2str(i),' = plot([IND(i)+xmin,IND(i)+xmax],[ITF(i)+ymin,ITF(i)+ymax],"color","',colorList{i},'","linewidth",2);'));
end

for i = 8:14
    load(strcat(modelList{i},'\T.mat'),"ITFa","INDa","ITFk","PACk","INDk");
    % [INDtrend,INDlower,INDupper] = calculateError(INDa);
    % IND(i) = INDtrend;
    % [ITFtrend,ITFlower,ITFupper] = calculateError(ITFa);
    % ITF(i) = ITFtrend;
    % [xmin,ymin,xmax,ymax] = errorbar(ITFtrend,ITFlower,ITFupper,INDtrend,INDlower,INDupper);
    IND(i) = INDk(end)-INDk(1);
    PAC(i) = PACk(end)-PACk(1);
    ITF(i) = ITFk(end)-ITFk(1);
    eval(strcat('s',num2str(i),' = scatter(IND(i)+PAC(i),ITF(i)-PAC(i),300,"filled","square","MarkerFaceColor","',colorList{i-7},'");'));
    % eval(strcat('p',num2str(i),' = plot([IND(i)+xmin,IND(i)+xmax],[ITF(i)+ymin,ITF(i)+ymax],"color","',colorList{i-7},'","linewidth",2);'));
    % eval(strcat('q',num2str(i),' = plot([IND(i),IND(i)],[ITFl(i),ITFu(i)],"color","',colorList{i-7},'","linewidth",2);'));
end

for i = 15:length(modelList)-1
    load(strcat(modelList{i},'\T.mat'),"ITFa","INDa","ITFk","PACk","INDk");
    % [INDtrend,INDlower,INDupper] = calculateError(INDa);
    % IND(i) = INDtrend;
    % [ITFtrend,ITFlower,ITFupper] = calculateError(ITFa);
    % ITF(i) = ITFtrend;
    % [xmin,ymin,xmax,ymax] = errorbar(ITFtrend,ITFlower,ITFupper,INDtrend,INDlower,INDupper);
    IND(i) = INDk(end)-INDk(1);
    PAC(i) = PACk(end)-PACk(1);
    ITF(i) = ITFk(end)-ITFk(1);
    eval(strcat('s',num2str(i),' = scatter(IND(i)+PAC(i),ITF(i)-PAC(i),300,"filled","^","MarkerFaceColor","',colorList{i-14},'");'));
    % eval(strcat('p',num2str(i),' = plot([IND(i)+xmin,IND(i)+xmax],[ITF(i)+ymin,ITF(i)+ymax],"color","',colorList{i-14},'","linewidth",2);'));
end

ITF(end) = mean(ITF(1:end-1),"all");
IND(end) = mean(IND(1:end-1),"all");
PAC(end) = mean(PAC(1:end-1),"all");
s15 = scatter(IND(end)+PAC(end),ITF(end)-PAC(end),300,"filled","hexagram","MarkerFaceColor","black");

ax.TickDir = 'out';
xlim([0 12])
ylim([-12 0])
xlabel('Indian transport change excluding Pacific wind effect (Sv)','FontSize',30,'FontName','Times New Roman')
ylabel('ITF transport change excluding Pacific wind effect (Sv)','FontSize',30,'FontName','Times New Roman')

lgdList = cell([1,length(modelList)+8]);
for i = 1:8
    lgdList{i} = '';
end
for i = 1:length(modelList)
    lgdList{i+8} = modelList{i};
    % lgdList{2*i+8} = '';
end
[~,lgd] = legend(lgdList,'FontSize',16,'NumColumns',1,'Location', 'northwest','FontName','Times New Roman');
for i = length(modelList)+1:2*length(modelList)
    lgd(i).Children.MarkerSize = 16;
end

xc = get(gca,'XColor');
yc = get(gca,'YColor');
unit = get(gca,'units');
ax = axes( 'Units', unit,...
'Position',get(gca,'Position'),...
'XAxisLocation','top',...
'YAxisLocation','right',...
'Color','none',...
'XColor',xc,...
'YColor',yc);
set(ax, 'linewidth',1,...
'XTick', [],...
'YTick', [],'Fontsize',12);
box on

%% 保存
% cd D:\Desktop\work\SO&ITF\picture\total\
% path = cd;
% exportgraphics(gcf, strcat(path,'/INDvsITF.jpg'));
% close;

function [trend,lower,upper] = calculateError(T)
t = (1:86)';
X = [ones(size(t)) t];
[b, bint] = regress(T', X, 0.05);
trend = b(2)*85;
lower = bint(2,1)*85;
upper = bint(2,2)*85;
end

function [xmin,ymin,xmax,ymax] = errorbar(ITFtrend,ITFlower,ITFupper,INDtrend,INDlower,INDupper)
Rmax = ITFlower/INDlower;
Rmin = ITFupper/INDupper;
R = ITFtrend/INDtrend;
xmin = (Rmin-R)*cos(atan(-1/R));
ymin = (Rmin-R)*sin(atan(-1/R));
xmax = (Rmax-R)*cos(atan(-1/R));
ymax = (Rmax-R)*sin(atan(-1/R));
end