clear
data = load('D:\Desktop\work\SO&ITF\data\inx.mat');
modelList = cell([length(data.modelList)-1 1]);
for i = 1:length(data.modelList)
    if strcmp(data.modelList{i},'Multimodel Mean')
        target = i;
    end
end
for i = 1:length(modelList)
    if i<target
        modelList{i} = data.modelList{i};
    elseif i>=target
        modelList{i} = data.modelList{i+1};
    end
end
modelList0 = {'ACCESS-CM2','ACCESS-ESM1-5','CESM2','CESM2-WACCM','CIESM','CMCC-CM2-SR5','CMCC-ESM2','CanESM5','CanESM5-1','CanESM5-CanOE','EC-Earth3-CC','GISS-E2-1-G','HadGEM3-GC31-LL','HadGEM3-GC31-MM','IPSL-CM6A-LR','MPI-ESM1-2-HR','MRI-ESM2-0','NorESM2-LM','NorESM2-MM','UKESM1-0-LL'};
colorList = {"#0072BD",	"#D95319","#EDB120","#7E2F8E","#77AC30","#4DBEEE","#A2142F"};
inx = zeros([length(modelList) 1]);
for i = 1:length(modelList)
    origin = modelList0{i};
    for j = 1:length(modelList)
        tmp = modelList{j};
        if strcmp(origin,tmp)
            inx(i) = j;
        end
    end
end

%% 读入数据
cd D:\Desktop\work\SO&ITF\data\
figure(1)
set(gcf,'color','white')
set(gcf,'position',[100,100,2000,1000])
set(gcf, 'DefaultTextFontName', 'Times New Roman');
clf
hold on
set(gca,'Fontsize',16,'FontName','Times New Roman')
set(gca, 'ydir', 'reverse')

for i = 1:7
    load(strcat(modelList0{i},'\T.mat'),"INDa","PACa","ITFa");
    [ITF,ITFl,ITFu] = calculateError(ITFa);
    [IND,INDl,INDu] = calculateError(INDa);
    [PAC,PACl,PACu] = calculateError(PACa);
    error = [-0.75*INDu+0.25*PACu -0.75*INDu+0.25*PACl -0.75*INDl+0.25*PACu -0.75*INDl+0.25*PACl];
    plot([inx(i),inx(i)],[min(error,[],"all"),max(error,[],"all")],'k-','LineWidth',2,'Marker','_','MarkerSize',30)
    scatter(inx(i),-0.75*IND+0.25*PAC,50,"filled","MarkerFaceColor",'k');
    scatter(inx(i),ITF,300,"filled","MarkerFaceColor",colorList{i});
end

for i = 8:14
    load(strcat(modelList0{i},'\T.mat'),"INDa","PACa","ITFa");
    [ITF,ITFl,ITFu] = calculateError(ITFa);
    [IND,INDl,INDu] = calculateError(INDa);
    [PAC,PACl,PACu] = calculateError(PACa);
    % r1(i) = ITF;
    % r2(i) = -0.7*IND+0.3*PAC;
    error = [-0.75*INDu+0.25*PACu -0.75*INDu+0.25*PACl -0.75*INDl+0.25*PACu -0.75*INDl+0.25*PACl];
    plot([inx(i),inx(i)],[min(error,[],"all"),max(error,[],"all")],'k-','LineWidth',2,'Marker','_','MarkerSize',30)
    scatter(inx(i),-0.75*IND+0.25*PAC,50,"filled","MarkerFaceColor",'k');
    scatter(inx(i),ITF,300,"filled","square","MarkerFaceColor",colorList{i-7});
end

for i = 15:length(modelList0)
    load(strcat(modelList0{i},'\T.mat'),"INDa","PACa","ITFa");
    [ITF,ITFl,ITFu] = calculateError(ITFa);
    [IND,INDl,INDu] = calculateError(INDa);
    [PAC,PACl,PACu] = calculateError(PACa);
    error = [-0.75*INDu+0.25*PACu -0.75*INDu+0.25*PACl -0.75*INDl+0.25*PACu -0.75*INDl+0.25*PACl];
    plot([inx(i),inx(i)],[min(error,[],"all"),max(error,[],"all")],'k-','LineWidth',2,'Marker','_','MarkerSize',30)
    scatter(inx(i),-0.75*IND+0.25*PAC,50,"filled","MarkerFaceColor",'k');
    scatter(inx(i),ITF,300,"filled","^","MarkerFaceColor",colorList{i-14});
end

% lgdList = cell([length(modelList)+2,1]);
% for i = 1:length(modelList)
%     lgdList{i} = '';
% end
% lgdList{i+1} = 'Induced by wind, AMOC & SO';
% lgdList{i+2} = 'In Models';
% [~,lgd] = legend(lgdList,'Location', 'best','FontSize',28,'FontName','Times New Roman');
% 
% for i = 3:4
%     lgd(i).Children.MarkerSize = 16;
% end

xticks(1:20)
xlim([0 21])
xticklabels(modelList)

ax = gca;
ax.TickDir = 'out';
ylabel('ITF changes (Sv)',"FontSize",30,'FontName','Times New Roman')

xc = get(gca,'XColor');
yc = get(gca,'YColor');
unit = get(gca,'units');
ax = axes( 'Units', unit,...
'Position',get(gca,'Position'),...
'XAxisLocation','top',...
'YAxisLocation','right',...
'Color','none',...
'XColor',xc,...
'YColor',yc);
set(ax, 'linewidth',1,...
'XTick', [],...
'YTick', [],'Fontsize',12);
box on

%% 保存
cd D:\Desktop\work\SO&ITF\picture\total\
path = cd;
exportgraphics(gcf, strcat(path,'/errorAnalysis.jpg'));
close;

function [trend,lower,upper] = calculateError(T)
t = (1:86)';
X = [ones(size(t)) t];
[b, bint] = regress(T', X, 0.05);
trend = b(2)*85;
lower = bint(2,1)*85;
upper = bint(2,2)*85;
end