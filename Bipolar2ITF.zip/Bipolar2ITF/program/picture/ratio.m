clear
modelList = {'ACCESS-CM2','ACCESS-ESM1-5','CESM2','CESM2-WACCM','CIESM','CanESM5','CanESM5-CanOE','HadGEM3-GC31-LL','HadGEM3-GC31-MM','IPSL-CM6A-LR','MRI-ESM2-0','NorESM2-LM','NorESM2-MM','UKESM1-0-LL'};
colorstyle = {"#0072BD","#A2142F","#EDB120"};

%% 读入数据
cd D:\Desktop\work\SO&ITF\data\

for i = 1:length(modelList)
    load(strcat(modelList{i},'\T.mat'),"ITFk","INDk","PACk");
    ITF = -abs(ITFk(end)-ITFk(1));
    IND = INDk(end)-INDk(1);
    PAC = PACk(end)-PACk(1);
    data(i) = (0.3*PAC-0.7*IND)/ITF;
end

%%  画图
cd D:\Desktop\work\SO&ITF\picture\total\
figure(1)
set(gcf,'color','white')
set(gcf,'position',[100,100,1000,700])
clf
hold on
grid on
box on
s = scatter(1:length(modelList),data,200,"k",'filled');

ylabel('Ratio',"FontSize",36)
% legend(b, {'ITF', 'by NA', 'by SO'}, 'Location', 'best','FontSize',16); % 添加图例，并指定位置

% path = cd;
% saveas(gcf,strcat(path,'/contrast.jpg'));
% close;