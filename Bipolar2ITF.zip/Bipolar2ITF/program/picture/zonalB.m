clear
modelList = {'ACCESS-CM2','ACCESS-ESM1-5','CESM2','CESM2-WACCM','CanESM5','CanESM5-CanOE','HadGEM3-GC31-LL','IPSL-CM6A-LR','NorESM2-LM','NorESM2-MM','UKESM1-0-LL'};
colorList = {"#0072BD",	"#D95319","#EDB120","#7E2F8E","#77AC30","#4DBEEE","#A2142F"};
foldname = 'D:\Desktop\work\SO&ITF\picture\total';
if ~exist(foldname,"dir")
    mkdir(foldname)
end
cd(foldname)

str = {};
lat = -70:5:-30;
for i = 1:length(lat)
    str{i} = strcat(num2str(-lat(i)),'\circ','S');
end

%% 气候态
%  浮力通量
hold on
figure(1)
set(gcf,'color','white')
set(gcf,'position',[100,100,1000,800])
for i = 1:7
    loadfile = strcat('D:\Desktop\work\SO&ITF\data\',modelList{i},'\B.mat');
    load(loadfile,"B","lat");
    eval(strcat('p',num2str(i),' = plot(lat,B,"lineWidth",2);'));%"color","',colorList{i},'","lineWidth",2);'));
end

for i = 8:length(modelList)
    loadfile = strcat('D:\Desktop\work\SO&ITF\data\',modelList{i},'\B.mat');
    load(loadfile,"B","lat");
    eval(strcat('p',num2str(i),' = plot(lat,B,"--","lineWidth",2);'));%"color","',colorList{i},'","lineWidth",2);'));
end
k = plot([-70 -30],[0 0],'k--',LineWidth=1);
xlim([-70 -30])
ylabel('Buoyancy flux(m^2/s^3)','FontSize',36)
xticks(-70:5:-30)
xticklabels(str)
axis normal
lgdList = cell([1,length(modelList)+1]);
lgdList{end} = '';
for i = 1:length(modelList)
    lgdList{i} = modelList{i};
end
[~,~] = legend(lgdList,'FontSize',14,'NumColumns',1);
path = cd;
saveas(gcf,strcat(path,'/buoyancyClimatology.jpg'));
close;

%  热通量
hold on
figure(1)
set(gcf,'color','white')
set(gcf,'position',[100,100,1000,800])
for i = 1:length(modelList)
    loadfile = strcat('D:\Desktop\work\SO&ITF\data\',modelList{i},'\B.mat');
    load(loadfile,"H","lat");
    eval(strcat('p',num2str(i),' = plot(lat,H,"color","',colorList{i},'","lineWidth",2);'));
end
k = plot([-70 -30],[0 0],'k--',LineWidth=1);
xlim([-70 -30])
axis normal
lgdList = cell([1,length(modelList)+1]);
lgdList{end} = '';
for i = 1:length(modelList)
    lgdList{i} = modelList{i};
end
[~,~] = legend(lgdList,'FontSize',14,'NumColumns',1);
path = cd;
saveas(gcf,strcat(path,'/heatClimatology.jpg'));
close;

%  淡水通量
hold on
figure(1)
set(gcf,'color','white')
set(gcf,'position',[100,100,1000,800])
for i = 1:length(modelList)
    loadfile = strcat('D:\Desktop\work\SO&ITF\data\',modelList{i},'\B.mat');
    load(loadfile,"F","lat");
    eval(strcat('p',num2str(i),' = plot(lat,F,"color","',colorList{i},'","lineWidth",2);'));
end
k = plot([-70 -30],[0 0],'k--',LineWidth=1);
xlim([-70 -30])
axis normal
lgdList = cell([1,length(modelList)+1]);
lgdList{end} = '';
for i = 1:length(modelList)
    lgdList{i} = modelList{i};
end
[~,lgd] = legend(lgdList,'FontSize',14,'NumColumns',1);
path = cd;
saveas(gcf,strcat(path,'/freshwaterClimatology.jpg'));
close;

%% 趋势
%  浮力通量
hold on
figure(1)
set(gcf,'color','white')
set(gcf,'position',[100,100,1000,800])
for i = 1:7
    loadfile = strcat('D:\Desktop\work\SO&ITF\data\',modelList{i},'\B.mat');
    load(loadfile,"Btrend","lat");
    eval(strcat('p',num2str(i),' = plot(lat,Btrend,"lineWidth",2);'));%"color","',colorList{i},'","lineWidth",2);'));
end

for i = 8:length(modelList)
    loadfile = strcat('D:\Desktop\work\SO&ITF\data\',modelList{i},'\B.mat');
    load(loadfile,"Btrend","lat");
    eval(strcat('p',num2str(i),' = plot(lat,Btrend,"--","lineWidth",2);'));%"color","',colorList{i},'","lineWidth",2);'));
end

k = plot([-70 -30],[0 0],'k--',LineWidth=1);
xlim([-70 -30])
xticks(-70:5:-30)
xticklabels(str)
xlim([-70 -30])
ylabel('Buoyancy flux(m^2/s^3)','FontSize',36)
axis normal
lgdList = cell([1,length(modelList)+1]);
lgdList{end} = '';
for i = 1:length(modelList)
    lgdList{i} = modelList{i};
end
[~,~] = legend(lgdList,'FontSize',14,'NumColumns',1);
path = cd;
saveas(gcf,strcat(path,'/buoyancyTrend.jpg'));
close;

%  热通量
hold on
figure(1)
set(gcf,'color','white')
set(gcf,'position',[100,100,1000,800])
for i = 1:length(modelList)
    loadfile = strcat('D:\Desktop\work\SO&ITF\data\',modelList{i},'\B.mat');
    load(loadfile,"Htrend","lat");
    eval(strcat('p',num2str(i),' = plot(lat,Htrend,"color","',colorList{i},'","lineWidth",2);'));
end
k = plot([-70 -30],[0 0],'k--',LineWidth=1);
xlim([-70 -30])
axis normal
lgdList = cell([1,length(modelList)+1]);
lgdList{end} = '';
for i = 1:length(modelList)
    lgdList{i} = modelList{i};
end
[~,~] = legend(lgdList,'FontSize',14,'NumColumns',1);
path = cd;
saveas(gcf,strcat(path,'/heatTrend.jpg'));
close;

%  淡水通量
hold on
figure(1)
set(gcf,'color','white')
set(gcf,'position',[100,100,1000,800])
for i = 1:length(modelList)
    loadfile = strcat('D:\Desktop\work\SO&ITF\data\',modelList{i},'\B.mat');
    load(loadfile,"Ftrend","lat");
    eval(strcat('p',num2str(i),' = plot(lat,Ftrend,"color","',colorList{i},'","lineWidth",2);'));
end
k = plot([-70 -30],[0 0],'k--',LineWidth=1);
xlim([-70 -30])
axis normal
lgdList = cell([1,length(modelList)+1]);
lgdList{end} = '';
for i = 1:length(modelList)
    lgdList{i} = modelList{i};
end
[~,lgd] = legend(lgdList,'FontSize',14,'NumColumns',1);
path = cd;
saveas(gcf,strcat(path,'/freshwaterTrend.jpg'));
close;