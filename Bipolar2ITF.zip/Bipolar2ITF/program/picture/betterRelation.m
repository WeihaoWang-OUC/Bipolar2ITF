clear
modelList = {'ACCESS-CM2','ACCESS-ESM1-5','CESM2','CESM2-WACCM','CIESM','CMCC-CM2-SR5','CMCC-ESM2','CanESM5','CanESM5-1','CanESM5-CanOE','EC-Earth3-CC','GISS-E2-1-G','HadGEM3-GC31-LL','HadGEM3-GC31-MM','IPSL-CM6A-LR','MPI-ESM1-2-HR','MRI-ESM2-0','NorESM2-LM','NorESM2-MM','UKESM1-0-LL','Multimodel Mean'};
colorList = {"#0072BD",	"#D95319","#EDB120","#7E2F8E","#77AC30","#4DBEEE","#A2142F"};

%% 读入数据
cd D:\Desktop\work\SO&ITF\data\
figure(1)
clf
set(gcf,'color','white')
set(gcf,'position',[-1200,50,1200,1200])
set(gcf, 'DefaultTextFontName', 'Times New Roman');
ax = axes('Position', [0.1, 0.1, 0.8, 0.8]);
set(gca,'Fontsize',16,'FontName','Times New Roman')
set(gca, 'XTick', -10:1:0, 'YTick', -10:1:0);
hold on

ITF = zeros([length(modelList),1]);
IND = zeros([length(modelList),1]);
error = zeros([length(modelList),1]);

plot([0,-12],[0,-12],'k--');
text(-8.75, -8.75, '100%', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize',20,'Rotation',atand(1));
plot([0,-12],0.5*[0,-12],'k--');
text(-5, -5*0.5, '150%', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize',20,'Rotation',atand(0.5));
plot(0.5*[0,-12],[0,-12],'k--');
text(-4.5, -8.75, '50%', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize',20,'Rotation',atand(2));
plot([0,-12],0.75*[0,-12],'k--');
text(-8.75, -8.75*0.75, '125%', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize',20,'Rotation',atand(0.75));
plot(0.75*[0,-12],[0,-12],'k--');
text(-8.75*0.75, -8.75, '75%', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize',20,'Rotation',atand(4/3));
plot([0,-12],0.25*[0,-12],'k--');
text(-5, -5*0.25, '175%', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize',20,'Rotation',atand(0.25));
plot(0.25*[0,-12],[0,-12],'k--');
text(-8.75*0.25, -8.75, '25%', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize',20,'Rotation',atand(4));

for i = 1:7
    load(strcat(modelList{i},'\T.mat'),"ITFk","PACk","INDk");
    IND(i) = INDk(end)-INDk(1);
    PAC(i) = PACk(end)-PACk(1);
    ITF(i) = ITFk(end)-ITFk(1);
    eval(strcat('s',num2str(i),' = scatter(-0.76*IND(i)+0.24*PAC(i),ITF(i),300,"filled","MarkerFaceColor","',colorList{i},'");'));
end

for i = 8:14
    load(strcat(modelList{i},'\T.mat'),"ITFk","PACk","INDk");
    IND(i) = INDk(end)-INDk(1);
    PAC(i) = PACk(end)-PACk(1);
    ITF(i) = ITFk(end)-ITFk(1);
    eval(strcat('s',num2str(i),' = scatter(-0.76*IND(i)+0.24*PAC(i),ITF(i),300,"filled","square","MarkerFaceColor","',colorList{i-7},'");'));
end

for i = 15:length(modelList)-1
    load(strcat(modelList{i},'\T.mat'),"ITFk","PACk","INDk");
    IND(i) = INDk(end)-INDk(1);
    PAC(i) = PACk(end)-PACk(1);
    ITF(i) = ITFk(end)-ITFk(1);
    eval(strcat('s',num2str(i),' = scatter(-0.76*IND(i)+0.24*PAC(i),ITF(i),300,"filled","^","MarkerFaceColor","',colorList{i-14},'");'));
end

ITF(end) = mean(ITF(1:end-1),"all");
IND(end) = mean(IND(1:end-1),"all");
PAC(end) = mean(PAC(1:end-1),"all");
s15 = scatter(-0.76*IND(end)+0.24*PAC(end),ITF(end),300,"filled","hexagram","MarkerFaceColor","black");

ax.TickDir = 'out';
xlim([-10 0])
ylim([-10 0])
xlabel('ITF changes due to wind & Indian volume convergences (Sv)','FontSize',30,'FontName','Times New Roman')
ylabel('ITF changes in models (Sv)','FontSize',30,'FontName','Times New Roman')

lgdList = cell([1,length(modelList)+7]);
for i = 1:7
    lgdList{i} = '';
end
for i = 1:length(modelList)
    lgdList{i+7} = modelList{i};
end
[~,lgd] = legend(lgdList,'FontSize',16,'NumColumns',1,'Location', 'northwest','FontName','Times New Roman');
for i = length(modelList)+1:2*length(modelList)
    lgd(i).Children.MarkerSize = 16;
end

xc = get(gca,'XColor');
yc = get(gca,'YColor');
unit = get(gca,'units');
ax = axes( 'Units', unit,...
'Position',get(gca,'Position'),...
'XAxisLocation','top',...
'YAxisLocation','right',...
'Color','none',...
'XColor',xc,...
'YColor',yc);
set(ax, 'linewidth',1,...
'XTick', [],...
'YTick', [],'Fontsize',12);
box on

%% 保存
cd D:\Desktop\work\SO&ITF\picture\total\
path = cd;
exportgraphics(gcf, strcat(path,'/IND&PACvsITF.jpg'));
close;