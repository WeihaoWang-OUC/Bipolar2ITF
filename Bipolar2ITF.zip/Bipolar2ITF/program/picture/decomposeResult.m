clear
figure(1)
clf
set(gcf,'color','white')
set(gcf,'position',[-100,-100,2400,1200])
set(gcf, 'DefaultTextFontName', 'Times New Roman');

%% (a)&(b)
%  读取数据
cd D:\Desktop\work\SO&ITF\data\RGM
filename1 = "control.txt";
filename2 = "SO_linear.txt";
filename3 = "NA_linear.txt";
filename4 = "SO&NA_linear.txt";
% filename2 = "SO.txt";
% filename3 = "NA.txt";
% filename4 = "SO&NA.txt";
control = load(filename1);
data_SO = load(filename2);
data_NA = load(filename3);
data_SO_NA = load(filename4);
varList = {"ATL","PAC","IND","ITF","hatl","hpac","hind"};
climatology = [11.1 12.4 -14.2 13.7 1227.24 1294.47 1298.52 788.78];
[n1,n2] = size(control);
t = (1:n1)/12;

%  贡献分解
len = 100*12;
data = data_SO_NA;
for i = [1,3]
    varName = varList{i};
    eval(strcat(varName," = data(1:len,i)-data(1,i);"));
end
% A = [1,-1;0.6703,1.9672];
% A = [1,-1;0.80,1.9672];
A = [1,-1;0.72,1.69];
k = 0.76*[0.72;1.69];
for n = 1:len
    b = [-ATL(n);IND(n)];
    x = A\b;
    frac(:,n) = -k(:).*x(:);
end
ITF = zeros([2,len]);
data = data_NA;
ITF(1,:) = data(1:len,4)-data(1,4);
data = data_SO;
ITF(2,:) = data(1:len,4)-data(1,4);

annotation('textbox', [0.1, 0.93, 0.34, 0.05], 'String', 'Reduced Gravity Model', ...
    'EdgeColor', 'none', 'FontName','Times New Roman','HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize',48);
annotation('textbox', [0.5, 0.93, 0.4, 0.05], 'String', 'CMIP6', ...
    'EdgeColor', 'none', 'FontName','Times New Roman','HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize',48);

%  画图(a)
ax1 = subplot('Position', [0.1, 0.54, 0.34, 0.36]);
set(gca,'Fontsize',16,'FontName','Times New Roman')
hold on

p1 = plot(t(1:len),frac(1,1:len),'LineWidth',2.5,'Color','#F09BA0');
p2 = plot(t(1:len),ITF(1,1:len),'LineWidth',2.5,'Color','#614099');
% text(20, -1.4, 'NA experiment', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize',24);

ax1.TickDir = 'out';
legend({'Decomposition','Model'},'FontSize',28,'FontName','Times New Roman')
ylabel('Transport change (Sv)','FontSize',30,'FontName','Times New Roman')
title('(a) NA contributions','FontSize',20,'FontName','Times New Roman')
ax = gca;
ax.TitleHorizontalAlignment = 'left';

xc = get(gca,'XColor');
yc = get(gca,'YColor');
unit = get(gca,'units');
ax = axes( 'Units', unit,...
'Position',get(gca,'Position'),...
'XAxisLocation','top',...
'YAxisLocation','right',...
'Color','none',...
'XColor',xc,...
'YColor',yc);
set(ax, 'linewidth',1,...
'XTick', [],...
'YTick', [],'Fontsize',12);
box on

%  画图(b)
ax2 = subplot('Position', [0.1, 0.1, 0.34, 0.36]);
set(gca,'Fontsize',16,'FontName','Times New Roman')
hold on

p1 = plot(t(1:len),frac(2,1:len),'LineWidth',2.5,'Color','#F09BA0');
p2 = plot(t(1:len),ITF(2,1:len),'LineWidth',2.5,'Color','#614099');
% text(20, -1.4, 'SO experiment', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize',24);

ax2.TickDir = 'out';
legend({'Decomposition','Model'},'FontSize',28,'FontName','Times New Roman')
xlabel('Time (year)','FontSize',30,'FontName','Times New Roman')
ylabel('Transport change (Sv)','FontSize',30,'FontName','Times New Roman')
title('(b) SO contributions','FontSize',20,'FontName','Times New Roman')
ax = gca;
ax.TitleHorizontalAlignment = 'left';

xc = get(gca,'XColor');
yc = get(gca,'YColor');
unit = get(gca,'units');
ax = axes( 'Units', unit,...
'Position',get(gca,'Position'),...
'XAxisLocation','top',...
'YAxisLocation','right',...
'Color','none',...
'XColor',xc,...
'YColor',yc);
set(ax, 'linewidth',1,...
'XTick', [],...
'YTick', [],'Fontsize',12);
box on

%% (c)
modelList = {'ACCESS-CM2','ACCESS-ESM1-5','CESM2','CESM2-WACCM','CIESM','CMCC-CM2-SR5','CMCC-ESM2','CanESM5','CanESM5-1','CanESM5-CanOE','EC-Earth3-CC','GISS-E2-1-G','HadGEM3-GC31-LL','HadGEM3-GC31-MM','IPSL-CM6A-LR','MPI-ESM1-2-HR','MRI-ESM2-0','NorESM2-LM','NorESM2-MM','UKESM1-0-LL','Multimodel Mean'};
colorList = {"#0072BD",	"#D95319","#EDB120","#7E2F8E","#77AC30","#4DBEEE","#A2142F"};
xLim = [0,1.2];
yLim = [-0.2,1];

%  读入数据
cd D:\Desktop\work\SO&ITF\data\
ax3 = subplot('Position', [0.50, 0.10, 0.4, 0.8]);
set(gca,'Fontsize',16,'FontName','Times New Roman')
set(gca, 'XTick', xLim(1):0.1:xLim(2), 'YTick', yLim(1):0.1:yLim(2));
hold on

NA = zeros(size([length(modelList),1]));
SO = zeros(size([length(modelList),1]));
error = zeros(size([length(modelList),1]));

plot([xLim(1),xLim(2)],[yLim(2),yLim(1)],'k--');
text(0.1, 0.9, '100%', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize',20,'Rotation',atand(-1));
plot([xLim(1),xLim(2)],[yLim(2)-0.2,yLim(1)-0.2],'k--');
text(0.1, 0.7, '80%', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize',20,'Rotation',atand(-1));
% plot([0.6,0],[0,0.6],'k--');
% text(0.1, 0.5, '60%', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize',20,'Rotation',atand(-1));
% plot([0.4,0],[0,0.4],'k--');
% text(0.1, 0.3, '40%', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize',20,'Rotation',atand(-1));
% plot([0.2,0],[0,0.2],'k--');
plot([1.2,0],[0,1.2],'k--');
text(0.3, 0.9, '120%', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize',20,'Rotation',atand(-1));
plot([1.4,0],[0,1.4],'k--');
text(0.5, 0.9, '140%', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize',20,'Rotation',atand(-1));
% plot([1.6,0],[0,1.6],'k--');
% plot([0.8,0],[0,0.8],Color=[.6 .6 .6],LineStyle="--");
% plot([1.2,0],[0,1.2],Color=[.6 .6 .6],LineStyle="--");

for i = 1:7
    load(strcat(modelList{i},'\T67.mat'),"ITFk","frac_k","ITFe","INDk","INDe");
    NAk = frac_k(1,end)-frac_k(1,1);
    SOk = frac_k(2,end)-frac_k(2,1);
    ITF = abs(ITFk(end)-ITFk(1));
    % IND = INDk(end)-INDk(1);
    % dITF = 4*ITFe(end);
    % dIND = 4*INDe(end);
    NA(i) = NAk/ITF;
    SO(i) = SOk/ITF;
    % upper(i) = 0.7*((IND+dIND)/(ITF-dITF)-IND/ITF);
    % lower(i) = 0.7*((IND-dIND)/(ITF+dITF)-IND/ITF);
    % error(i) = 0.7*(INDe(end)/ITF-IND*ITFe(end)/ITF^2-INDe(end)*ITFe(end)/ITF^2);
    eval(strcat('s',num2str(i),' = scatter(NA(i),SO(i),300,"filled","MarkerFaceColor","',colorList{i},'");'));
    % eval(strcat('p',num2str(i),' = plot([NA(i)+sqrt(2)/2*lower(i),NA(i)+sqrt(2)/2*upper(i)],[SO(i)+sqrt(2)/2*lower(i),SO(i)+sqrt(2)/2*upper(i)],"color","',colorList{i},'","linewidth",2);'));
end

for i = 8:14
    load(strcat(modelList{i},'\T67.mat'),"ITFk","frac_k","ITFe","INDk","INDe");
    NAk = frac_k(1,end)-frac_k(1,1);
    SOk = frac_k(2,end)-frac_k(2,1);
    ITF = abs(ITFk(end)-ITFk(1));
    % IND = INDk(end)-INDk(1);
    NA(i) = NAk/ITF;
    SO(i) = SOk/ITF;
    % error(i) = 0.7197*(INDe(end)/ITF-IND*ITFe(end)/ITF^2-INDe(end)*ITFe(end)/ITF^2);
    eval(strcat('s',num2str(i),' = scatter(NA(i),SO(i),300,"filled","square","MarkerFaceColor","',colorList{i-7},'");'));
    % eval(strcat('p',num2str(i),' = plot([NA(i)-sqrt(2)/2*error(i),NA(i)+sqrt(2)/2*error(i)],[SO(i)-sqrt(2)/2*error(i),SO(i)+sqrt(2)/2*error(i)],"color","',colorList{i-7},'","linewidth",2);'));
end

for i = 15:length(modelList)-1
    load(strcat(modelList{i},'\T67.mat'),"ITFk","frac_k","ITFe","INDk","INDe");
    NAk = frac_k(1,end)-frac_k(1,1);
    SOk = frac_k(2,end)-frac_k(2,1);
    ITF = abs(ITFk(end)-ITFk(1));
    % IND = INDk(end)-INDk(1);
    NA(i) = NAk/ITF;
    SO(i) = SOk/ITF;
    % error(i) = 0.7197*(INDe(end)/ITF-IND*ITFe(end)/ITF^2-INDe(end)*ITFe(end)/ITF^2);
    eval(strcat('s',num2str(i),' = scatter(NA(i),SO(i),300,"filled","^","MarkerFaceColor","',colorList{i-14},'");'));
    % eval(strcat('p',num2str(i),' = plot([NA(i)-sqrt(2)/2*error(i),NA(i)+sqrt(2)/2*error(i)],[SO(i)-sqrt(2)/2*error(i),SO(i)+sqrt(2)/2*error(i)],"color","',colorList{i-14},'","linewidth",2);'));
end

NA(end) = mean(NA(1:end-1),"all");
SO(end) = mean(SO(1:end-1),"all");
% error(end) = mean(error(1:end-1),"all");
send = scatter(NA(end),SO(end),300,"filled","hexagram","MarkerFaceColor","black");
% pend = plot([NA(end)-sqrt(2)/2*error(end),NA(end)+sqrt(2)/2*error(end)],[SO(end)-sqrt(2)/2*error(end),SO(end)+sqrt(2)/2*error(end)],"color","black","linewidth",2);

ax3.TickDir = 'out';
xlim(xLim)
ylim(yLim)
xlabel('North Atlantic contribution','FontSize',30,'FontName','Times New Roman')
ylabel('Southern Ocean contribution','FontSize',30,'FontName','Times New Roman')

lgdList = cell([1,length(modelList)+4]);
for i = 1:4
    lgdList{i} = '';
end
for i = 1:length(modelList)
    lgdList{i+4} = modelList{i};
    % lgdList{2*i+4} = '';
end
[~,lgd] = legend(lgdList,'FontSize',16,'NumColumns',1,'Location', 'southwest','FontName','Times New Roman');
for i = length(modelList)+1:2*length(modelList)
    lgd(i).Children.MarkerSize = 16;
end

title('(c)','FontSize',20,'FontName','Times New Roman')
ax = gca;
ax.TitleHorizontalAlignment = 'left';

xc = get(gca,'XColor');
yc = get(gca,'YColor');
unit = get(gca,'units');
ax = axes( 'Units', unit,...
'Position',get(gca,'Position'),...
'XAxisLocation','top',...
'YAxisLocation','right',...
'Color','none',...
'XColor',xc,...
'YColor',yc);
set(ax, 'linewidth',1,...
'XTick', [],...
'YTick', [],'Fontsize',12);
box on

%% 保存
% cd ../picture/total
% path = cd;
% exportgraphics(gcf, strcat(path,'\decomposeResult80.jpg'));
% close;