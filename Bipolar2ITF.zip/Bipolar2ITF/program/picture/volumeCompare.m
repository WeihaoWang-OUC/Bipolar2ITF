function[] = volumeCompare(dataname)
indRange = [31.5,115.5];
pacRange = [153.5,287.5];

%%  读取
foldname = strcat('D:\Desktop\work\SO&ITF\data\',dataname,'\sigma');
Files = dir(foldname);                                                      %用结构体读取文件夹中全部nc文件
folder = Files.folder;

cd(folder)
name = Files(3).name;

%  经纬度
try
    x = ncread(name,'longitude');
    y = ncread(name,'latitude');
catch
    try
        x = ncread(name,'nav_lon');
        y = ncread(name,'nav_lat');
    catch
        x = ncread(name,'lon');
        y = ncread(name,'lat');
    end
end

%  深度
try
    lev = ncread(name,'level');
catch
    try
        lev = ncread(name,'lev');
    catch
        try
            lev = ncread(name,'depth');
        catch
            lev = ncread(name,'olevel');
        end
    end
end
if lev(end)>=10000
    lev = lev./100;  %CESM2的深度单位为cm
end

%  将经度转化为0~360
if max(x,[],"all")<=180
    inx = find(x<0);
    x(inx) = x(inx)+360;
end

%  确定范围
k_inx = find(lev<=3000);
[nx,ny] = size(x);
nz = length(k_inx);
z = lev(k_inx);
clear lev

%  截取位密
data = ncread(name,'sigma1',[1,1,1,1],[nx,ny,nz,1032]);
sigma = NaN([nx,ny,nz,86]);
for t = 1:86
    sigma(:,:,:,t) = mean(data(:,:,:,12*t-11:12*t),4,"includemissing");
end
clear data

%  读取面积
foldname = strcat('D:\Desktop\work\SO&ITF\data\',dataname,'\areacello');
Files = dir(foldname);                                                      %用结构体读取文件夹中全部nc文件
folder = Files.folder;
cd(folder)
name = Files(3).name;

areacello = ncread(name,'areacello');

%% 赋值
%  确定范围
i_inx_pac = x>=pacRange(1) & x<=pacRange(2);
i_inx_ind = x>=indRange(1) & x<=indRange(2);
j_inx = y>=-30 & y<=70;

%  截取平面
target = 1000;
[~,inx] = min(abs(z-target));
ref = mean(sigma(:,:,inx,1:10),"all","omitmissing");
vol_pac = zeros([nx,ny,86]);
vol_ind = zeros([nx,ny,86]);
for i = 1:nx
    for j = 1:ny
        if i_inx_pac(i,j) && j_inx(i,j)
            for t = 1:86
                k = nz-1;
                while k>=1
                    if sigma(i,j,nz,t)<ref
                        disp(1)
                    end
                    if sigma(i,j,k,t)<=ref && sigma(i,j,k+1,t)>=ref
                        h = interp1(squeeze(sigma(i,j,k:k+1,t)),squeeze(z(k:k+1)),ref);
                        vol_pac(i,j,t) = areacello(i,j).*h;
                        break
                    end
                    k = k-1;
                end
            end
        end
        if i_inx_ind(i,j) && j_inx(i,j)
            for t = 1:86
                k = nz-1;
                while k>=1
                    if sigma(i,j,nz,t)<ref
                        disp(1)
                    end
                    if sigma(i,j,k,t)<=ref && sigma(i,j,k+1,t)>=ref
                        h = interp1(squeeze(sigma(i,j,k:k+1,t)),squeeze(z(k:k+1)),ref);
                        vol_ind(i,j,t) = areacello(i,j).*h;
                        break
                    end
                    k = k-1;
                end
            end
        end
    end
end
clear sigma

%% 计算
%  体积
Vpac = squeeze(sum(vol_pac,[1,2],"omitmissing"));
Vind = squeeze(sum(vol_ind,[1,2],"omitmissing"));

%  面积
Spac = squeeze(sum(areacello.*i_inx_pac.*j_inx,"all","omitmissing"));
Sind = squeeze(sum(areacello.*i_inx_ind.*j_inx,"all","omitmissing"));

%  厚度
Hpac = Vpac./Spac;
Hind = Vind./Sind;

%  时间导数
dHpac = diff(Hpac,1,1)/3600/24/360;
dHind = diff(Hind,1,1)/3600/24/360;

%  趋势
t = 1:85;
[p,S] = polyfit(t,dHpac,1);                                                  %数据线性拟合重构
[Ptrend,~] = polyval(p,t,S);
kP = (Ptrend(end)-Ptrend(1))/84;

[p,S] = polyfit(t,dHind,1);                                                  %数据线性拟合重构
[Itrend,~] = polyval(p,t,S);
kI = (Itrend(end)-Itrend(1))/84;

%% 画图
colorList = {"#0072BD",	"#D95319","#EDB120"};
foldname = strcat('D:\Desktop\work\SO&ITF\picture\',dataname);
if ~exist(foldname,"dir")
    mkdir(foldname)
end
cd(foldname)

figure(1)
clf
hold on
box on
set(gcf,'color','white')
set(gcf,'position',[100,100,1000,800])
p1 = plot(dHpac,LineWidth=2,Color=colorList{1});
p2 = plot(dHind,LineWidth=2,Color=colorList{2});
k1 = plot(Ptrend,LineWidth=1,LineStyle="--",Color=colorList{1});
k2 = plot(Itrend,LineWidth=1,LineStyle="--",Color=colorList{2});
% legend(strcat('PAC(',num2str(kP),')'),strcat('IND(',num2str(kI),')'),'','','fontsize',14)
legend('PAC','IND','','','fontsize',16)
set(gca,'yDir','reverse')
xlim([1 85])
% ylim([-20 90])
xlabel("time(year)","FontSize",20)
ylabel("depth tendency(m/s)","FontSize",20)
xticks(0:5:85)
xticklabels(2015:5:2100)

path = cd;
saveas(gcf,strcat(path,'/depth.jpg'));
close;