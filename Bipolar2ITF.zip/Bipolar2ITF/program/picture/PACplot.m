clear
modelList = {'ACCESS-CM2','CESM2','CIESM','CMCC-ESM2','CanESM5-1','HadGEM3-GC31-MM','IPSL-CM6A-LR','NorESM2-MM','UKESM1-0-LL'};
t = 2015:2100;
colorstyle = {"#B7F5DE","#FABB6E","#B7B7EB"};
letter = {'(a) ','(b) ','(c) ','(d) ','(e) ','(f) ','(g) ','(h) ','(i) '};

figure(1)
clf
set(gcf,'color','white')
set(gcf,'position',[-1200,-100,1800,1600])
set(gcf, 'DefaultTextFontName', 'Times New Roman');

len = 0.28;
width = 0.23;
x1 = 0.04;
x2 = 0.37;
x3 = 0.70;
y1 = 0.63;
y2 = 0.34;
y3 = 0.05;
pos1 = [x1 y1 len width];
pos2 = [x2 y1 len width];
pos3 = [x3 y1 len width];
pos4 = [x1 y2 len width];
pos5 = [x2 y2 len width];
pos6 = [x3 y2 len width];
pos7 = [x1 y3 len width];
pos8 = [x2 y3 len width];
pos9 = [x3 y3 len width];

for i = 1:9
    cd D:\Desktop\SO&ITF\data\
    cd(modelList{i})
    %%%%
    load("PAC.mat")
    %%%%
    eval(strcat("subplot('Position',pos",num2str(i),");"))
    set(gca,'Fontsize',16,'FontName','Times New Roman')
    hold on
    p1 = plot(t,T1,'Color',colorstyle{1},'LineWidth',2.5);
    p2 = plot(t,T2,'Color',colorstyle{2},'LineWidth',2.5);
    p3 = plot(t,T3,'Color',colorstyle{3},'LineWidth',2.5);
    xlim([2015,2100])
    if i == 7 || i == 8 || i == 9
        xlabel('Time (year)','FontSize',30,'FontName','Times New Roman')
    end
    if i == 1 || i == 4 || i == 7 
        ylabel('Transport change (Sv)','FontSize',30,'FontName','Times New Roman')
    end
    title(strcat(letter(i),modelList{i}),'FontSize',28,'FontName','Times New Roman');

    ax = gca;
    ax.TitleHorizontalAlignment = 'left';
    ax.TickDir = 'out';

    xc = get(gca,'XColor');
    yc = get(gca,'YColor');
    unit = get(gca,'units');
    ax = axes( 'Units', unit,...
        'Position',get(gca,'Position'),...
        'XAxisLocation','top',...
        'YAxisLocation','right',...
        'Color','none',...
        'XColor',xc,...
        'YColor',yc);
    set(ax, 'linewidth',1,...
        'XTick', [],...
        'YTick', [],'Fontsize',12);
    box on
end

ax = findobj(gcf, 'Type', 'axes');
h = [];
for i = 1:length(ax)
    h = [h; findobj(ax(i), 'Type', 'line')];
end
legend(h, {'1000m','1500m','2000m'},'Position', [0.26, 0.87, 0.5, 0.1], 'Orientation', 'horizontal','FontSize',36,'FontName','Times New Roman');

%% 保存
cd D:\Desktop\SO&ITF\picture\total\
path = cd;
%%%%
exportgraphics(gcf, strcat(path,'/PAC.jpg'));
%%%%
close;