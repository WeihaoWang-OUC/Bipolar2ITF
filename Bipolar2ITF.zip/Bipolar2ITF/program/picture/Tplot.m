function[] = Tplot(dataname)
loadfile = strcat('D:\Desktop\work\SO&ITF\data\',dataname,'\T.mat');
foldname = strcat('D:\Desktop\work\SO&ITF\picture\',dataname);
varList = {"ATL","PAC","IND","ITF"};
colorstyle = {"#0072BD","#A2142F","#EDB120","#7E2F8E","#77AC30","#4DBEEE"};
load(loadfile)
if ~exist(foldname,"dir")
    mkdir(foldname)
end
cd(foldname)
t = 1:length(ATLa);

%% 流量异常图
figure(1)
set(gcf,'color','white')
set(gcf,'position',[100,100,1000,800])
clf
hold on
box on
for i = 1:4
    eval(strcat("p",num2str(i)," = plot(t,",varList{i},"a,'color','",colorstyle{i},"','lineWidth',1.5);")) ;
    eval(strcat("l",num2str(i)," = plot(t,",varList{i},"k,'--','color','",colorstyle{i},"','lineWidth',2.5);")) ;
end
plot([0 t(end)],[0 0],'k--','LineWidth',1)
legend([p1 p2 p3 p4],varList)
xlim([1 t(end)])
% ylim([-2 5]);
xlabel("time(year)","FontSize",20)
xticks(0:5:86)
xticklabels(2015:5:2100)
path = cd;
saveas(gcf,strcat(path,'/transportAnomaly.jpg'));
close;

%% 分流图
figure(1)
set(gcf,'color','white')
clf
hold on
p1 = plot(t,INDa,'Color',colorstyle{3},'LineWidth',1.5);
p2 = plot(t,ITFa,'Color',colorstyle{4},'LineWidth',1.5);
l1 = plot(t,INDk,'--','Color',colorstyle{3},'LineWidth',1);
l2 = plot(t,ITFk,'--','Color',colorstyle{4},'LineWidth',1);
legend([p1 p2],{'IND','ITF'})
xlim([0 t(end)])
xlabel("time(year)","FontSize",20)
xticks(0:5:86)
xticklabels(2015:5:2100)
path = cd;
saveas(gcf,strcat(path,'/NA&SO.jpg'));
close;

%% 对比
figure(1)
set(gcf,'color','white')
clf
hold on
p1 = plot(t,-sum(frac,1),'Color',colorstyle{1},'LineWidth',1.5);
p2 = plot(t,ITFa,'Color',colorstyle{2},'LineWidth',1.5);
l1 = plot(t,-sum(frac_k,1),'--','Color',colorstyle{1},'LineWidth',1);
l2 = plot(t,ITFk,'--','Color',colorstyle{2},'LineWidth',1);
legend([p1 p2],{'by NA&SO','real'})
xlim([0 t(end)])
xlabel("time(year)","FontSize",20)
xticks(0:5:86)
xticklabels(2015:5:2100)
path = cd;
saveas(gcf,strcat(path,'/contrast.jpg'));
close;