clear
modelList = {'ACCESS-CM2','ACCESS-ESM1-5','CESM2','CESM2-WACCM','CIESM','CanESM5','CanESM5-CanOE','HadGEM3-GC31-LL','HadGEM3-GC31-MM','IPSL-CM6A-LR','MRI-ESM2-0','NorESM2-LM','NorESM2-MM','UKESM1-0-LL'};
colorList = {"#0072BD",	"#D95319","#EDB120","#7E2F8E","#77AC30","#4DBEEE","#A2142F"};

%% 读入数据
cd D:\Desktop\work\SO&ITF\data\
figure(1)
clf
set(gcf,'color','white')
set(gcf,'Position',[50,50,1100,1100])
set(gca,'Fontsize',24)
% set(gca, 'XTick', -10:1:-1, 'YTick', -10:1:-1);
hold on
grid on
box on

% plot([-12,0],-1*[-12,0],'k--');
% text(-9, -9, '100%', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize',20,'Rotation',atand(1));
plot([0,12],0.8*[0,12],'k--');
text(10, 10*0.8, '80%', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'top','FontSize',20,'Rotation',atand(0.8));
plot([0,12],1.2*[0,12],'k--');
text(10, 12, '120%', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'top','FontSize',20,'Rotation',atand(1.2));
plot([0,12],1.6*[0,12],'k--');
text(12/1.6, 12, '160%', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'top','FontSize',20,'Rotation',atand(1.6));
plot([0,12],2*[0,12],'k--');
text(6, 12, '200%', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'top','FontSize',20,'Rotation',atand(2));
plot([0,12],2.4*[0,12],'k--');
text(12/2.4, 12, '240%', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'top','FontSize',20,'Rotation',atand(2.4));
% plot([-12,0],-2.8*[-12,0],'k--');
% text(-9*0.25, -9, '25%', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize',20,'Rotation',atand(4));

for i = 1:7
    load(strcat(modelList{i},'\T.mat'),"INDk","ATLk","PACk");
    IND = INDk(end)-INDk(1);
    ATL = ATLk(end)-ATLk(1);
    PAC = PACk(end)-PACk(1);
    eval(strcat('s',num2str(i),' = scatter(-ATL,IND,300,"filled","MarkerFaceColor","',colorList{i},'");'));
    eval(strcat('p',num2str(i),' = plot([-ATL,-ATL],[IND,IND+PAC],"color","',colorList{i},'","linewidth",2);'));
end

for i = 8:length(modelList)
    load(strcat(modelList{i},'\T.mat'),"INDk","ATLk","PACk");
    IND = INDk(end)-INDk(1);
    ATL = ATLk(end)-ATLk(1);
    PAC = PACk(end)-PACk(1);
    eval(strcat('s',num2str(i),' = scatter(-ATL,IND,300,"filled","square","MarkerFaceColor","',colorList{i-7},'");'));
    eval(strcat('p',num2str(i),' = plot([-ATL,-ATL],[IND,IND+PAC],"color","',colorList{i-7},'","linewidth",2);'));
end

% axis equal
xlim([0 12])
ylim([0 14])
xlabel('Atlantic transport change (Sv)','FontSize',36)
ylabel('Interbasin transport change (Sv)','FontSize',36)

lgdList = cell([1,2*length(modelList)+5]);
for i = 1:5
    lgdList{i} = '';
end
% lgdList{2} = '';
% lgdList{3} = '';
for i = 1:length(modelList)
    lgdList{2*i+4} = modelList{i};
    lgdList{2*i+5} = '';
end
[~,lgd] = legend(lgdList,'FontSize',16,'NumColumns',1,'Location', 'southeast');
for i = length(modelList)+1:2*length(modelList)
    lgd(i).Children.MarkerSize = 16;
end

%% 保存
cd D:\Desktop\work\SO&ITF\picture\total\
path = cd;
saveas(gcf,strcat(path,'/AMOCvsITF.jpg'));
close;