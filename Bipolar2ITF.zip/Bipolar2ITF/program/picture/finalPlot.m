clear
modelList = {'ACCESS-CM2','ACCESS-ESM1-5','CESM2','CESM2-WACCM','CIESM','CMCC-CM2-SR5','CMCC-ESM2','CanESM5','CanESM5-1','CanESM5-CanOE','EC-Earth3-CC','GISS-E2-1-G','HadGEM3-GC31-LL','HadGEM3-GC31-MM','IPSL-CM6A-LR','MPI-ESM1-2-HR','MRI-ESM2-0','NorESM2-LM','NorESM2-MM','UKESM1-0-LL','Multimodel Mean'};

%% 读入数据
cd D:\Desktop\SO&ITF\data\

for i = 1:length(modelList)-1
    load(strcat(modelList{i},'\T.mat'),"ITFk","frac_k","PACk");
    ITF(i) = -abs(ITFk(end)-ITFk(1));
    NA(i) = -frac_k(1,end)+frac_k(1,1);
    SO(i) = -frac_k(2,end)+frac_k(2,1);
    wind(i) = PACk(end)-PACk(1);
    data(i,:) = [ITF(i),NA(i)+SO(i)+wind(i),NA(i)+SO(i),NA(i),SO(i),wind(i)];
end
ITFend = mean(ITF,"all");
NAend = mean(NA,"all");
SOend = mean(SO,"all");
windend = mean(wind,"all");
data(length(modelList),:) = [ITFend,NAend+SOend+windend,NAend+SOend,NAend,SOend,windend];
[~,inx] = sort(data(:,end)./data(:,1));
data0 = data;
modelList0 = modelList;
for i = 1:length(inx)
    data(i,:) = data0(inx(i),:);
    modelList{i} = modelList0{inx(i)};
end
save('D:\Desktop\SO&ITF\data\inx.mat',"modelList")

%%  画图
cd D:\Desktop\SO&ITF\picture\total\
figure(1)
set(gcf,'color','white')
set(gcf,'position',[-900,800,2000,1500])
set(gcf, 'DefaultTextFontName', 'Times New Roman');
clf
hold on

%  (a)
colorstyle = {"#614099","#B3C4D4","#2D8875"};
ax1 = subplot('Position', [0.05, 0.57, 0.93, 0.36]);
set(gca,'Fontsize',16,'FontName','Times New Roman')
hold on
set(gca, 'ydir', 'reverse')
ax1.XAxis.FontSize = 24;
ax1.XTickLabel = [];
b1 = bar(1:length(modelList),data(:,1:3),'grouped');

for k = 1:length(b1)
    b1(k).EdgeColor = 'none'; % 将每个条形的边框颜色设置为无
    b1(k).FaceColor = colorstyle{k}; % 为每一组数据设置颜色
end

ax = gca;
ax.TickDir = 'out';
ax.XAxis.FontSize = 24;
ylabel('ITF changes (Sv)',"FontSize",30,'FontName','Times New Roman')
legend(b1, {'CMIP6 models', 'Bipolar + wind', 'Bipolar'}, 'Location', 'best','FontSize',28,'FontName','Times New Roman'); % 添加图例，并指定位置
title('(a)','FontSize',28,'FontName','Times New Roman')
ax = gca;
ax.TitleHorizontalAlignment = 'left';

xc = get(gca,'XColor');
yc = get(gca,'YColor');
unit = get(gca,'units');
ax = axes( 'Units', unit,...
'Position',get(gca,'Position'),...
'XAxisLocation','top',...
'YAxisLocation','right',...
'Color','none',...
'XColor',xc,...
'YColor',yc);
set(ax, 'linewidth',1,...
'XTick', [],...
'YTick', [],'Fontsize',12);
box on

%  (b)
colorstyle = {"#AD6800","#FFE494","#BD7795"};

ax2 = subplot('Position', [0.05, 0.15, 0.93, 0.36]);
set(gca,'Fontsize',16,'FontName','Times New Roman')
hold on

b2 = bar(modelList,data(:,4:6),'grouped');
set(gca, 'ydir', 'reverse')
ax2.XAxis.FontSize = 24;
for k = 1:length(b2)
    b2(k).EdgeColor = 'none'; % 将每个条形的边框颜色设置为无
    b2(k).FaceColor = colorstyle{k}; % 为每一组数据设置颜色
end

ax = gca;
ax.TickDir = 'out';
ylabel('Contribution to ITF changes (Sv)',"FontSize",30,'FontName','Times New Roman')
legend(b2, {'North Atlantic', 'Southern Ocean', 'Wind'}, 'Location', 'best','FontSize',28,'FontName','Times New Roman','Interpreter','latex'); % 添加图例，并指定位置
% legend(b, {'$\delta\textit{T}_\mathrm{ITF}$', '$\delta\textit{\tilde{T}}_\mathrm{ITF}$', '$\delta\textit{T}_\mathrm{ITF}^\mathrm{\hspace{2pt}N}+\delta\textit{T}_\mathrm{ITF}^\mathrm{\hspace{2pt}S}$'},'FontSize',28,'FontName','Times New Roman','Interpreter','latex'); % 添加图例，并指定位置
title('(b)','FontSize',28,'FontName','Times New Roman')
ax = gca;
ax.TitleHorizontalAlignment = 'left';

xc = get(gca,'XColor');
yc = get(gca,'YColor');
unit = get(gca,'units');
ax = axes( 'Units', unit,...
'Position',get(gca,'Position'),...
'XAxisLocation','top',...
'YAxisLocation','right',...
'Color','none',...
'XColor',xc,...
'YColor',yc);
set(ax, 'linewidth',1,...
'XTick', [],...
'YTick', [],'Fontsize',12);
box on

%% 保存
path = cd;
exportgraphics(gcf, strcat(path,'/contrast.jpg'));
close;