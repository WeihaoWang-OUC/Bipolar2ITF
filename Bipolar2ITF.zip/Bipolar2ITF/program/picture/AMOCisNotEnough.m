clear
cd D:\Desktop\SO&ITF\picture\RGM
figure(1)
clf
set(gcf,'color','white')
set(gcf,'position',[-1200,700,1000,1600])
set(gcf, 'DefaultTextFontName', 'Times New Roman');

%% (a)
modelList = {'ACCESS-CM2','ACCESS-ESM1-5','CESM2','CESM2-WACCM','CIESM','CMCC-CM2-SR5','CMCC-ESM2','CanESM5','CanESM5-1','CanESM5-CanOE','EC-Earth3-CC','GISS-E2-1-G','HadGEM3-GC31-LL','HadGEM3-GC31-MM','IPSL-CM6A-LR','MPI-ESM1-2-HR','MRI-ESM2-0','NorESM2-LM','NorESM2-MM','UKESM1-0-LL','Multimodel Mean'};
colorList = {"#0072BD",	"#D95319","#EDB120","#7E2F8E","#77AC30","#4DBEEE","#A2142F"};

% 读入数据
cd D:\Desktop\SO&ITF\data\
ax1 = subplot('Position', [0.12, 0.5, 0.72, 0.45]); 
set(gca,'Fontsize',16,'FontName','Times New Roman')
set(gca, 'XTick', -10:1:-1, 'YTick', -10:1:-1);
hold on

ITF = zeros([length(modelList),1]);
T = zeros([length(modelList),1]);
error = zeros([length(modelList),1]);

plot([-10,0],[-10,0],'k--');
text(-8.75, -8.75, '100%', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize',20,'Rotation',atand(1));
plot([-10,0],0.5*[-10,0],'k--');
text(-5, -5*0.5, '150%', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize',20,'Rotation',atand(0.5));
plot(0.5*[-10,0],[-10,0],'k--');
text(-4.5, -8.75, '50%', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize',20,'Rotation',atand(2));
plot([-10,0],0.75*[-10,0],'k--');
text(-5, -5*0.75, '125%', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize',20,'Rotation',atand(0.75));
plot(0.75*[-10,0],[-10,0],'k--');
text(-8.75*0.75, -8.75, '75%', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize',20,'Rotation',atand(4/3));
plot([-10,0],0.25*[-10,0],'k--');
text(-5, -5*0.25, '175%', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize',20,'Rotation',atand(0.25));
plot(0.25*[-10,0],[-10,0],'k--');
text(-8.75*0.25, -8.75, '25%', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize',20,'Rotation',atand(4));

for i = 1:7
    load(strcat(modelList{i},'\T.mat'),"ITFk","PACk","ATLk");
    ITF(i) = -abs(ITFk(end)-ITFk(1));
    PAC = PACk(end)-PACk(1);
    ATL = ATLk(end)-ATLk(1);
    T(i) = 0.56*ATL+PAC;
    % error(i) = PAC;
    eval(strcat('s',num2str(i),' = scatter(T(i),ITF(i),300,"filled","MarkerFaceColor","',colorList{i},'");'));
    % eval(strcat('q',num2str(i),' = quiver(T(i),ITF(i),error(i),0,"color","',colorList{i},'","linewidth",3,"MaxHeadSize", 0.7);'));
end

for i = 8:14
    load(strcat(modelList{i},'\T.mat'),"ITFk","PACk","ATLk");
    ITF(i) = -abs(ITFk(end)-ITFk(1));
    PAC = PACk(end)-PACk(1);
    ATL = ATLk(end)-ATLk(1);
    T(i) = 0.56*ATL+PAC;
    % error(i) = PAC;
    eval(strcat('s',num2str(i),' = scatter(T(i),ITF(i),300,"filled","square","MarkerFaceColor","',colorList{i-7},'");'));
    % eval(strcat('q',num2str(i),' = quiver(T(i),ITF(i),error(i),0,"color","',colorList{i-7},'","linewidth",3,"MaxHeadSize", 0.7);'));
end

for i = 15:length(modelList)-1
    load(strcat(modelList{i},'\T.mat'),"ITFk","PACk","ATLk");
    ITF(i) = -abs(ITFk(end)-ITFk(1));
    PAC = PACk(end)-PACk(1);
    ATL = ATLk(end)-ATLk(1);
    T(i) = 0.56*ATL+PAC;
    % error(i) = PAC;
    eval(strcat('s',num2str(i),' = scatter(T(i),ITF(i),300,"filled","^","MarkerFaceColor","',colorList{i-14},'");'));
    % eval(strcat('q',num2str(i),' = quiver(T(i),ITF(i),error(i),0,"color","',colorList{i-14},'","linewidth",3,"MaxHeadSize", 0.7);'));
end

ITF(end) = mean(ITF(1:end-1),"all");
T(end) = mean(T(1:end-1),"all");
% error(end) = mean(error(1:end-1),"all");
se = scatter(T(end),ITF(end),300,"filled","hexagram","MarkerFaceColor","black");
% qe = quiver(T(end),ITF(end),error(end),0,"color","black","linewidth",3,"MaxHeadSize", 0.7);

ax1.TickDir = 'out';
xlim([-10 0])
ylim([-10 0])
% xlabel('\fontname{Cambria Math}\delta\itT_{\fontsize{18}\rmITF}\fontname{Times New Roman}\rm due to wind & AMOC (Sv)','FontSize',30,'FontName','Times New Roman')
% ylabel('\fontname{Cambria Math}\delta\itT_{\fontsize{18}\rmITF}\fontname{Times New Roman}\rm in models (Sv)','FontSize',30,'FontName','Times New Roman')
xlabel('ITF changes due to wind & AMOC (Sv)','FontSize',30,'FontName','Times New Roman')
ylabel('ITF changes in models (Sv)','FontSize',30,'FontName','Times New Roman')

lgdList = cell([1,length(modelList)+7]);
for i = 1:7
    lgdList{i} = '';
end
% lgdList{2} = '';
% lgdList{3} = '';
for i = 1:length(modelList)
    lgdList{i+7} = modelList{i};
    % lgdList{2*i+7} = '';
end
[~,lgd] = legend(lgdList,'FontSize',16,'NumColumns',1,'Location', 'northwest','FontName','Times New Roman');
for i = length(modelList)+1:2*length(modelList)
    lgd(i).Children.MarkerSize = 16;
end
title('(a)','FontSize',28,'FontName','Times New Roman');
ax = gca;
ax.TitleHorizontalAlignment = 'left';

xc = get(gca,'XColor');
yc = get(gca,'YColor');
unit = get(gca,'units');
ax = axes( 'Units', unit,...
'Position',get(gca,'Position'),...
'XAxisLocation','top',...
'YAxisLocation','right',...
'Color','none',...
'XColor',xc,...
'YColor',yc);
set(ax, 'linewidth',1,...
'XTick', [],...
'YTick', [],'Fontsize',12);
box on

%% (b)
% 读取数据
cd D:\Desktop\data\argo\
name = 'RG-Argo_sigma_200401-202411_mon.nc';
x = ncread(name,'longitude');
y = ncread(name,'latitude');
p = ncread(name,'pressure');
rho = ncread(name,'sigma1');
sigma = mean(rho,4,"omitmissing");
[nx,ny,np] = size(sigma);
pp = nan([nx,ny]);

% 估算深度
target = 31.8;
for i = 1:nx
    for j = 1:ny
        tmp = squeeze(sigma(i,j,:));
        for k = 2:np
            if tmp(k)>=target || k == np
                k_inx = [k-1,k];
                break
            end
        end
        if isnan(tmp(k_inx(1)))
            pp(i,j) = nan;
        elseif tmp(k_inx(1))>target
            pp(i,j) = 0;
        elseif tmp(k_inx(2))<target
            pp(i,j) = p(end);
        else
            pp(i,j) = interp1(tmp(k_inx),p(k_inx),target);
        end
    end
end

%  地形
[elev,~,~]=m_elev([0.5 359.5 -64.5 79.5]);
lon = 0.5:359.5;
lat = -64.5:79.5;

% 画图
ax2 = subplot('Position', [0.12, 0.16, 0.778, 0.25]);
hold on
set(gca,'Fontsize',16,'FontName','Times New Roman')
[~,h] = contourf(lon,lat,elev,[0 0],'k-','LineWidth',0.5);
h.FaceColor = .75*[1 1 1];

contourf(x,y,pp,0:200:1400,'LineStyle','none')
colormap(ax2,cmocean('haline',7))
clim([0 1400])

%  island rule
colorstyle = "#BD7795";
annotation('arrow',[0.6725 0.5],...
    [0.27 0.27],...
    'LineStyle','-',...
    'Color',colorstyle,...
    'LineWidth',2,...
    'HeadWidth',15,...
    'HeadLength',15);

annotation('line', [0.51, 0.375], [0.27, 0.27], ...
           'LineStyle', '-', ... 
           'LineWidth', 2, ...       
           'Color', colorstyle);  
annotation('line', [0.375, 0.375], [0.27, 0.255], ...
           'LineStyle', '-', ... 
           'LineWidth', 2, ...       
           'Color', colorstyle); 
annotation('line', [0.375, 0.34], [0.255, 0.23], ...
           'LineStyle', '-', ... 
           'LineWidth', 2, ...       
           'Color', colorstyle); 
annotation('line', [0.34, 0.35], [0.23, 0.2075], ...
           'LineStyle', '-', ... 
           'LineWidth', 2, ...       
           'Color', colorstyle);
annotation('line', [0.38, 0.35], [0.215, 0.2075], ...
           'LineStyle', '-', ... 
           'LineWidth', 2, ...       
           'Color', colorstyle);
annotation('line', [0.38, 0.41], [0.215, 0.20], ...
           'LineStyle', '-', ... 
           'LineWidth', 2, ...       
           'Color', colorstyle);
annotation('line', [0.4275, 0.41], [0.215, 0.20], ...
           'LineStyle', '-', ... 
           'LineWidth', 2, ...       
           'Color', colorstyle);
annotation('line', [0.4275, 0.69], [0.215, 0.215], ...
           'LineStyle', '-', ... 
           'LineWidth', 2, ...       
           'Color', colorstyle); 
annotation('line', [0.695, 0.69], [0.235, 0.215], ...
           'LineStyle', '-', ... 
           'LineWidth', 2, ...       
           'Color', colorstyle); 
annotation('line', [0.695, 0.6725], [0.235, 0.255], ...
           'LineStyle', '-', ... 
           'LineWidth', 2, ...       
           'Color', colorstyle); 
annotation('line', [0.6725, 0.6725], [0.255, 0.27], ...
           'LineStyle', '-', ... 
           'LineWidth', 2, ...       
           'Color', colorstyle); 

%  transport
text(340, -22.5, '$T_\mathrm{A}$', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle', 'Color', '#B9181A','FontSize', 24,'Interpreter','latex');
plot([0,15],[-30,-30],'--','Color','#B9181A','LineWidth',2)
plot([312,360],[-30,-30],'--','Color','#B9181A','LineWidth',2)

text(70, -22.5, '$T_\mathrm{I}$', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle', 'Color', '#369F2D','FontSize', 24,'Interpreter','latex');
plot([33,113],[-30,-30],'--','Color','#369F2D','LineWidth',2)

text(225, -22.5, '$T_\mathrm{P}$', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle', 'Color', '#FABB6E','FontSize', 24,'Interpreter','latex');
plot([155,287],[-30,-30],'--','Color','#FABB6E','LineWidth',2)

text(95, -12, '$T_\mathrm{ITF}$', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle', 'Color', '#614099','FontSize', 24,'Interpreter','latex');
plot([113,120],[-8,-20],'--','Color','#614099','LineWidth',2)

shading interp
cb = colorbar;
ax2.TickDir = 'out';
cb.Label.String = 'Pressure (dbar)';
cb.Label.FontSize = 30;
cb.Label.FontName = 'Times New Roman';
xlabel("Longitude (deg)","FontSize",30,'FontName','Times New Roman')
ylabel("Latitude (deg)","FontSize",30,'FontName','Times New Roman')

title('(b)','FontSize',28,'FontName','Times New Roman');
ax = gca;
ax.TitleHorizontalAlignment = 'left';

xc = get(gca,'XColor');
yc = get(gca,'YColor');
unit = get(gca,'units');
ax = axes( 'Units', unit,...
'Position',get(gca,'Position'),...
'XAxisLocation','top',...
'YAxisLocation','right',...
'Color','none',...
'XColor',xc,...
'YColor',yc);
set(ax, 'linewidth',1,...
'XTick', [],...
'YTick', [],'Fontsize',12);
box on

%% 保存
cd D:\Desktop\SO&ITF\picture\total\
path = cd;
exportgraphics(gcf, strcat(path,'/AMOCisNotEnough.jpg'));
close;