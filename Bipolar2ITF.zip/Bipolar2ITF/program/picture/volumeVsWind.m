clear
cd D:\Desktop\work\SO&ITF\picture\RGM
figure(1)
clf
set(gcf,'color','white')
set(gcf,'position',[-1200,-100,1000,2000])
set(gcf, 'DefaultTextFontName', 'Times New Roman');

%% (a)
modelList = {'ACCESS-CM2','ACCESS-ESM1-5','CESM2','CESM2-WACCM','CIESM','CMCC-CM2-SR5','CMCC-ESM2','CanESM5','CanESM5-1','CanESM5-CanOE','EC-Earth3-CC','GISS-E2-1-G','HadGEM3-GC31-LL','HadGEM3-GC31-MM','IPSL-CM6A-LR','MPI-ESM1-2-HR','MRI-ESM2-0','NorESM2-LM','NorESM2-MM','UKESM1-0-LL','Multimodel Mean'};
colorList = {"#0072BD",	"#D95319","#EDB120","#7E2F8E","#77AC30","#4DBEEE","#A2142F"};

% 读入数据
cd D:\Desktop\work\SO&ITF\data\
ax1 = subplot('Position', [0.1, 0.68, 0.80, 0.3]); 
set(gca,'Fontsize',16,'FontName','Times New Roman')
hold on

IP = zeros([length(modelList),1]);
wind = zeros([length(modelList),1]);

plot([0.4,2],[0.6,-1],'--','LineWidth',1.5,'Color',.6*[1 1 1]);
text(1.4, -0.4, '100%', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize',20,'Rotation',-45);
plot([0.4,2],[0.8,-0.8],'--','LineWidth',1.5,'Color',.6*[1 1 1]);
text(1.6, -0.4, '120%', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize',20,'Rotation',-45);
plot([0.4,2],[0.4,-1.2],'--','LineWidth',1.5,'Color',.6*[1 1 1]);
text(1.2, -0.4, '80%', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize',20,'Rotation',-45);
plot([0.4,2],[1,-0.6],'--','LineWidth',1.5,'Color',.6*[1 1 1]);
text(1.8, -0.4, '140%', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize',20,'Rotation',-45);

for i = 1:7
    load(strcat(modelList{i},'\T.mat'),"ITFk","PACk","INDk","BSTk");
    ITF = -abs(ITFk(end)-ITFk(1));
    PAC = PACk(end)-PACk(1);
    BST = 0;%BSTk(end)-BSTk(1);
    IND = INDk(end)-INDk(1);
    IP(i) = -0.77*(PAC+IND-BST)/ITF;
    wind(i) = (PAC-BST)/ITF;
    eval(strcat('s',num2str(i),' = scatter(IP(i),wind(i),300,"filled","MarkerFaceColor","',colorList{i},'");'));
    % eval(strcat('s',num2str(i),' = scatter(PAC,BST,300,"filled","MarkerFaceColor","',colorList{i},'");'));
end

for i = 8:14
    load(strcat(modelList{i},'\T.mat'),"ITFk","PACk","INDk","BSTk");
    ITF = -abs(ITFk(end)-ITFk(1));
    PAC = PACk(end)-PACk(1);
    BST = 0;%BSTk(end)-BSTk(1);
    IND = INDk(end)-INDk(1);
    IP(i) = -0.77*(PAC+IND-BST)/ITF;
    wind(i) = (PAC-BST)/ITF;
    eval(strcat('s',num2str(i),' = scatter(IP(i),wind(i),300,"filled","square","MarkerFaceColor","',colorList{i-7},'");'));
    % eval(strcat('s',num2str(i),' = scatter(PAC,BST,300,"filled","square","MarkerFaceColor","',colorList{i-7},'");'));
end

for i = 15:length(modelList)-1
    load(strcat(modelList{i},'\T.mat'),"ITFk","PACk","INDk","BSTk");
    ITF = -abs(ITFk(end)-ITFk(1));
    PAC = PACk(end)-PACk(1);
    BST = 0;%BSTk(end)-BSTk(1);
    IND = INDk(end)-INDk(1);
    IP(i) = -0.77*(PAC+IND-BST)/ITF;
    wind(i) = (PAC-BST)/ITF;
    eval(strcat('s',num2str(i),' = scatter(IP(i),wind(i),300,"filled","^","MarkerFaceColor","',colorList{i-14},'");'));
    % eval(strcat('s',num2str(i),' = scatter(PAC,BST,300,"filled","^","MarkerFaceColor","',colorList{i-14},'");'));
end

IP(end) = mean(IP(1:end-1),"all");
wind(end) = mean(wind(1:end-1),"all");
se = scatter(IP(end),wind(end),300,"filled","hexagram","MarkerFaceColor","black");

ax1.TickDir = 'out';
xlim([0.4 2])
ylim([-0.6 0.6])
xlabel('Volume convergence vs. ITF decline','FontSize',30,'FontName','Times New Roman')
ylabel('Wind stress change vs. ITF decline','FontSize',30,'FontName','Times New Roman')
% xlabel('\fontname{Cambria Math}\delta\itT_{\fontsize{18}\rm ITF}^{\fontsize{18}\rm IP}/\fontname{Cambria Math}\delta\itT_{\fontsize{18}\rmITF}','FontSize',30,'FontName','Times New Roman')
% ylabel('\fontname{Cambria Math}\delta\itT_{\fontsize{18}\rmITF}^{\fontsize{18}\rmwind}/\fontname{Cambria Math}\delta\itT_{\fontsize{18}\rmITF}','FontSize',30,'FontName','Times New Roman')

title('(a)','FontSize',28,'FontName','Times New Roman');
ax = gca;
ax.TitleHorizontalAlignment = 'left';

xc = get(gca,'XColor');
yc = get(gca,'YColor');
unit = get(gca,'units');
ax = axes( 'Units', unit,...
'Position',get(gca,'Position'),...
'XAxisLocation','top',...
'YAxisLocation','right',...
'Color','none',...
'XColor',xc,...
'YColor',yc);
set(ax, 'linewidth',1,...
'XTick', [],...
'YTick', [],'Fontsize',12);
box on

%% (b)
modelList = {'ACCESS-CM2','ACCESS-ESM1-5','CESM2','CESM2-WACCM','CIESM','CMCC-CM2-SR5','CMCC-ESM2','CanESM5','CanESM5-1','CanESM5-CanOE','EC-Earth3-CC','GISS-E2-1-G','HadGEM3-GC31-LL','HadGEM3-GC31-MM','IPSL-CM6A-LR','MPI-ESM1-2-HR','MRI-ESM2-0','NorESM2-LM','NorESM2-MM','UKESM1-0-LL','Multimodel Mean'};
colorList = {"#0072BD",	"#D95319","#EDB120","#7E2F8E","#77AC30","#4DBEEE","#A2142F"};

% 读入数据
cd D:\Desktop\work\SO&ITF\data\
ax2 = subplot('Position', [0.1, 0.365, 0.8, 0.25]); 
set(gca,'Fontsize',16,'FontName','Times New Roman')
set(gca, 'XTick', 1:21, 'YTick', 0.6:0.2:2);
hold on

r = zeros([length(modelList),1]);

for i = 1:7
    load(strcat(modelList{i},'\T.mat'),"ATLk","PACk","INDk");
    ATL = ATLk(end)-ATLk(1);
    PAC = PACk(end)-PACk(1);
    IND = INDk(end)-INDk(1);
    r(i) = -(PAC+IND)/ATL;
    eval(strcat('s',num2str(i),' = scatter(i,r(i),300,"filled","MarkerFaceColor","',colorList{i},'");'));
end

for i = 8:14
    load(strcat(modelList{i},'\T.mat'),"ATLk","PACk","INDk");
    ATL = ATLk(end)-ATLk(1);
    PAC = PACk(end)-PACk(1);
    IND = INDk(end)-INDk(1);
    r(i) = -(PAC+IND)/ATL;
    eval(strcat('s',num2str(i),' = scatter(i,r(i),300,"filled","square","MarkerFaceColor","',colorList{i-7},'");'));
end

for i = 15:length(modelList)-1
    load(strcat(modelList{i},'\T.mat'),"ATLk","PACk","INDk");
    ATL = ATLk(end)-ATLk(1);
    PAC = PACk(end)-PACk(1);
    IND = INDk(end)-INDk(1);
    r(i) = -(PAC+IND)/ATL;
    eval(strcat('s',num2str(i),' = scatter(i,r(i),300,"filled","^","MarkerFaceColor","',colorList{i-14},'");'));
end

r(end) = mean(r(1:end-1),"all");
send = scatter(21,r(end),300,"filled","hexagram","MarkerFaceColor","black");
p = plot([0,22],[0.8,0.8],'--','LineWidth',1.5,'Color',.6*[1 1 1]);

ax2.TickDir = 'out';
xlim([0 22])
ylim([0.6 2])
% ylabel('\fontname{Cambria Math}-(\delta\itT_{\fontsize{18}\rmI}+\delta\itT_{\fontsize{18}\rmP})/\fontname{Cambria Math}\delta\itT_{\fontsize{18}\rmA}','FontSize',30,'FontName','Times New Roman')
ylabel('Interbasin compensation ratio','FontSize',30,'FontName','Times New Roman')
xticklabels(modelList)

title('(b)','FontSize',28,'FontName','Times New Roman');
ax = gca;
ax.TitleHorizontalAlignment = 'left';

xc = get(gca,'XColor');
yc = get(gca,'YColor');
unit = get(gca,'units');
ax = axes( 'Units', unit,...
'Position',get(gca,'Position'),...
'XAxisLocation','top',...
'YAxisLocation','right',...
'Color','none',...
'XColor',xc,...
'YColor',yc);
set(ax, 'linewidth',1,...
'XTick', [],...
'YTick', [],'Fontsize',12);
box on

%% (c)
% 读取数据
cd D:\Desktop\work\SO&ITF\data\argo\
name = 'RG-Argo_sigma_200401-202411_mon.nc';
x = ncread(name,'longitude');
y = ncread(name,'latitude');
p = ncread(name,'pressure');
rho = ncread(name,'sigma1');
sigma = mean(rho,4,"omitmissing");
[nx,ny,np] = size(sigma);
pp = zeros([nx,ny]);

% 估算深度
target = 31.8;
for i = 1:nx
    for j = 1:ny
        tmp = squeeze(sigma(i,j,:));
        for k = 2:np
            if tmp(k)>=target || k == np
                k_inx = [k-1,k];
                break
            end
        end
        if isnan(tmp(k_inx(1)))
            pp(i,j) = nan;
        elseif tmp(k_inx(1))>target
            pp(i,j) = 0;
        elseif tmp(k_inx(2))<target
            pp(i,j) = p(end);
        else
            pp(i,j) = interp1(tmp(k_inx),p(k_inx),target);
        end
    end
end

% 画图
ax3 = subplot('Position', [0.1, 0.045, 0.775, 0.215]);
hold on
set(gca,'Fontsize',16,'FontName','Times New Roman')
contourf(x,y,pp,0:200:1200)
colormap(cmocean('dense',6))
clim([0,1200])
shading interp
cb = colorbar;
ax3.TickDir = 'out';
cb.Label.String = 'Pressure (dbar)';
cb.Label.FontSize = 30;
cb.Label.FontName = 'Times New Roman';
xlabel("Longitude (deg)","FontSize",30,'FontName','Times New Roman')
ylabel("Latitude (deg)","FontSize",30,'FontName','Times New Roman')

title('(c)','FontSize',28,'FontName','Times New Roman');
ax = gca;
ax.TitleHorizontalAlignment = 'left';

xc = get(gca,'XColor');
yc = get(gca,'YColor');
unit = get(gca,'units');
ax = axes( 'Units', unit,...
'Position',get(gca,'Position'),...
'XAxisLocation','top',...
'YAxisLocation','right',...
'Color','none',...
'XColor',xc,...
'YColor',yc);
set(ax, 'linewidth',1,...
'XTick', [],...
'YTick', [],'Fontsize',12);
box on

%% 保存
cd D:\Desktop\work\SO&ITF\picture\total\
% path = cd;
% exportgraphics(gcf, strcat(path,'/perviousIsNotEnough.jpg'));
% close;