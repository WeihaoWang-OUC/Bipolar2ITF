clear
modelList = {'ACCESS-CM2','ACCESS-ESM1-5','CESM2','CESM2-WACCM','CIESM','CMCC-CM2-SR5','CMCC-ESM2','CanESM5','CanESM5-1','CanESM5-CanOE','EC-Earth3-CC','GISS-E2-1-G','HadGEM3-GC31-LL','HadGEM3-GC31-MM','IPSL-CM6A-LR','MPI-ESM1-2-HR','MRI-ESM2-0','NorESM2-LM','NorESM2-MM','UKESM1-0-LL','Multimodel Mean'};
colorList = {"#0072BD",	"#D95319","#EDB120","#7E2F8E","#77AC30","#4DBEEE","#A2142F"};

%% 读入数据
cd D:\Desktop\work\SO&ITF\data\
figure(1)
clf
set(gcf,'color','white')
set(gcf,'Position',[50,50,1100,1100])
set(gca,'Fontsize',20)
set(gca, 'XTick', 0:0.1:1, 'YTick', 0:0.1:1);
hold on
box on
grid on

NA = zeros(size([length(modelList),1]));
SO = zeros(size([length(modelList),1]));
error = zeros(size([length(modelList),1]));

plot([1,0],[0,1],'k--');
text(0.1, 0.9, '100%', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize',20,'Rotation',atand(-1));
plot([0.8,0],[0,0.8],'k--');
text(0.1, 0.7, '80%', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize',20,'Rotation',atand(-1));
% plot([0.6,0],[0,0.6],'k--');
% text(0.1, 0.5, '60%', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize',20,'Rotation',atand(-1));
% plot([0.4,0],[0,0.4],'k--');
% text(0.1, 0.3, '40%', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize',20,'Rotation',atand(-1));
% plot([0.2,0],[0,0.2],'k--');
plot([1.2,0],[0,1.2],'k--');
text(0.3, 0.9, '120%', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize',20,'Rotation',atand(-1));
plot([1.4,0],[0,1.4],'k--');
text(0.5, 0.9, '140%', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize',20,'Rotation',atand(-1));
% plot([1.6,0],[0,1.6],'k--');
% plot([0.8,0],[0,0.8],Color=[.6 .6 .6],LineStyle="--");
% plot([1.2,0],[0,1.2],Color=[.6 .6 .6],LineStyle="--");

for i = 1:7
    load(strcat(modelList{i},'\T.mat'),"ITFk","frac_k","ITFe","INDk","INDe");
    NAk = frac_k(1,end)-frac_k(1,1);
    SOk = frac_k(2,end)-frac_k(2,1);
    ITF = abs(ITFk(end)-ITFk(1));
    IND = INDk(end)-INDk(1);
    NA(i) = NAk/ITF;
    SO(i) = SOk/ITF;
    error(i) = 0.7197*(INDe(end)/ITF-IND*ITFe(end)/ITF^2-INDe(end)*ITFe(end)/ITF^2);
    eval(strcat('s',num2str(i),' = scatter(NA(i),SO(i),300,"filled","MarkerFaceColor","',colorList{i},'");'));
    eval(strcat('p',num2str(i),' = plot([NA(i)-sqrt(2)/2*error(i),NA(i)+sqrt(2)/2*error(i)],[SO(i)-sqrt(2)/2*error(i),SO(i)+sqrt(2)/2*error(i)],"color","',colorList{i},'","linewidth",2);'));
end

for i = 8:length(modelList)-1
    load(strcat(modelList{i},'\T.mat'),"ITFk","frac_k","ITFe","INDk","INDe");
    NAk = frac_k(1,end)-frac_k(1,1);
    SOk = frac_k(2,end)-frac_k(2,1);
    ITF = abs(ITFk(end)-ITFk(1));
    IND = INDk(end)-INDk(1);
    NA(i) = NAk/ITF;
    SO(i) = SOk/ITF;
    error(i) = 0.7197*(INDe(end)/ITF-IND*ITFe(end)/ITF^2-INDe(end)*ITFe(end)/ITF^2);
    eval(strcat('s',num2str(i),' = scatter(NA(i),SO(i),300,"filled","square","MarkerFaceColor","',colorList{i-7},'");'));
    eval(strcat('p',num2str(i),' = plot([NA(i)-sqrt(2)/2*error(i),NA(i)+sqrt(2)/2*error(i)],[SO(i)-sqrt(2)/2*error(i),SO(i)+sqrt(2)/2*error(i)],"color","',colorList{i-7},'","linewidth",2);'));
end

NA(end) = mean(NA(1:end-1),"all");
SO(end) = mean(SO(1:end-1),"all");
error(end) = mean(error(1:end-1),"all");
s15 = scatter(NA(end),SO(end),300,"filled","^","MarkerFaceColor","black");
p15 = plot([NA(end)-sqrt(2)/2*error(end),NA(end)+sqrt(2)/2*error(end)],[SO(end)-sqrt(2)/2*error(end),SO(end)+sqrt(2)/2*error(end)],"color","black","linewidth",2);

axis equal
xlim([0 1])
ylim([0 1])
xlabel('North Atlantic contribution','FontSize',36)
ylabel('Southern Ocean contribution','FontSize',36)

lgdList = cell([1,2*length(modelList)+4]);
for i = 1:4
    lgdList{i} = '';
end
for i = 1:length(modelList)
    lgdList{2*i+3} = modelList{i};
    lgdList{2*i+4} = '';
end
[~,lgd] = legend(lgdList,'FontSize',16,'NumColumns',1,'Location', 'southwest');
for i = length(modelList)+1:2*length(modelList)
    lgd(i).Children.MarkerSize = 16;
end

%% 保存
cd D:\Desktop\work\SO&ITF\picture\total\
path = cd;
saveas(gcf,strcat(path,'/contribution.jpg'));
close;