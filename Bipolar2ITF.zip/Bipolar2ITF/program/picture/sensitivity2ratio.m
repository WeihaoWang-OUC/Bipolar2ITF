clear

%% 读入数据
cd D:\Desktop\work\SO&ITF\data\
load("ACCESS-CM2\T.mat","ATLk","INDk","PACk")
A = ATLk(end)-ATLk(1);
I = INDk(end)-INDk(1);
P = PACk(end)-PACk(1);

Nskip = 0.01;
Sskip = 0.01;
rN = 0.6:Nskip:0.9;
rS = 1:Sskip:2.8;

NA = 0.62;
SO = 2.78;
figure(1)
clf
set(gcf,'color','white')
set(gcf,'position',[-1200,50,2000,1200])
set(gcf, 'DefaultTextFontName', 'Times New Roman');

colorstyle = {"#DCA7EB","#A7C0DF"};

%% (a)
ax1 = subplot('Position', [0.05, 0.1, 0.40, 0.60]);
set(gca,'Fontsize',16,'FontName','Times New Roman')
hold on

contribution = zeros([2,length(rN)]);
for i = 1:length(rN)
    a = rN(i);
    tmp = [a,SO];
    K = [1,-1;tmp];
    k = 0.7*(tmp);
    c = [-A;I+P];
    x = K\c;
    frac = k(:).*x(:);
    contribution(:,i) = frac(:);
end

plot(rN,contribution(1,:),"Color",colorstyle{1},"LineWidth",3)
plot(rN,contribution(2,:),"Color",colorstyle{2},"LineWidth",3)
plot([NA NA],[0.5 3.5],'--','Color',.6*[1 1 1],'LineWidth',2)
xlim([0.6,0.9])
xlabel("\fontname{Cambria Math} \it r^{\rm N}","FontSize",30,'FontName','Times New Roman')
ylabel("ITF decline contribution","FontSize",30,'FontName','Times New Roman')
ax1.TickDir = 'out';
title('(a)','FontSize',28,'FontName','Times New Roman')
ax = gca;
ax.TitleHorizontalAlignment = 'left';

ax.TickDir = 'out';

xc = get(gca,'XColor');
yc = get(gca,'YColor');
unit = get(gca,'units');
ax = axes( 'Units', unit,...
'Position',get(gca,'Position'),...
'XAxisLocation','top',...
'YAxisLocation','right',...
'Color','none',...
'XColor',xc,...
'YColor',yc);
set(ax, 'linewidth',1,...
'XTick', [],...
'YTick', [],'Fontsize',12);
box on

%% (b)
ax2 = subplot('Position', [0.50, 0.1, 0.40, 0.6]);
set(gca,'Fontsize',16,'FontName','Times New Roman')
hold on

contribution = zeros([2,length(rS)]);
for j = 1:length(rS)
    b = rS(j);
    tmp = [NA,b];
    K = [1,-1;tmp];
    k = 0.7*(tmp);
    c = [-A;I+P];
    x = K\c;
    frac = k(:).*x(:);
    contribution(:,j) = frac(:);
end

l1 = plot(rS,contribution(1,:),"Color",colorstyle{1},"LineWidth",3);
l2 = plot(rS,contribution(2,:),"Color",colorstyle{2},"LineWidth",3);
plot([SO SO],[1.2 3],'--','Color',.6*[1 1 1],'LineWidth',2)
xlim([1,2.8])
xlabel("\fontname{Cambria Math} \it r^{\rm S}","FontSize",30,'FontName','Times New Roman')
ax2.TickDir = 'out';
title('(b)','FontSize',28,'FontName','Times New Roman')
ax = gca;
ax.TitleHorizontalAlignment = 'left';

ax.TickDir = 'out';

xc = get(gca,'XColor');
yc = get(gca,'YColor');
unit = get(gca,'units');
ax = axes( 'Units', unit,...
'Position',get(gca,'Position'),...
'XAxisLocation','top',...
'YAxisLocation','right',...
'Color','none',...
'XColor',xc,...
'YColor',yc);
set(ax, 'linewidth',1,...
'XTick', [],...
'YTick', [],'Fontsize',12);
box on

%% legend
legend([l1,l2],{'North Atlantic process','Southern Ocean process'},'Position', [0.05, 0.525, 0.85, 0.5], 'Orientation', 'horizontal','FontSize',36,'FontName','Times New Roman');

%% 保存
cd D:\Desktop\work\SO&ITF\picture\ACCESS-CM2\
path = cd;
exportgraphics(gcf, strcat(path,'/sensivitity2ratio.jpg'));
close;