clear
modelList = {'ACCESS-CM2','ACCESS-ESM1-5','CESM2','CESM2-WACCM','CIESM','CanESM5','CanESM5-CanOE','HadGEM3-GC31-LL','HadGEM3-GC31-MM','IPSL-CM6A-LR','MRI-ESM2-0','NorESM2-LM','NorESM2-MM','UKESM1-0-LL'};
colorList = {"#0072BD",	"#D95319","#EDB120","#7E2F8E","#77AC30","#4DBEEE","#A2142F"};
t = 1:86;
NA = zeros([length(modelList) 1]);
SO = zeros([length(modelList) 1]);

%% 读取数据
for i = 1:length(modelList)
    dataname = modelList{i};
    varname = 'msftmz';
    cd(strcat('D:\Desktop\work\SO&ITF\data\',dataname))
    if exist(".\msftmz\","dir")==7
        varname = 'msftmz';
    elseif exist(".\msftmz\","dir")==0
        varname = 'msftyz';
    end
    foldname = strcat('D:\Desktop\work\SO&ITF\data\',dataname,'\',varname);
    addpath(foldname)

    Files = dir(foldname);                                                      %用结构体读取文件夹中全部nc文件
    msftyz = [];                                                                %建立空矩阵
    for j = 3:length(Files)                                                     %前两个为上下级，忽略掉向后两个读取
        name = Files(j).name;                                                   %读取nc文件名
        folder = Files(j).folder;                                               %读取文件夹名称
        cd(folder)                                                              %更改matlab路径
        T = ncread(name,varname);                                            %读取变量
        T = squeeze(T);
        % data = permute(data,[2,1,3,4]);                                       %把矩阵转置和xy对应
        msftyz = cat(4,msftyz,T);
    end

    try
        lat = ncread(Files(3).name,'lat');
    catch
        try
            lat = ncread(Files(3).name,'rlat');
        catch
            lat = ncread(Files(3).name,'nav_lat');
        end
    end

    try
        str = ncread(Files(3).name,'sector');
        for j = 1:size(str,2)
            if strcmpi(str(1,j),'a')
                sector1 = j;
            end
            if strcmpi(str(1,j),'g')
                sector2 = j;
            end
            if strcmpi(str(1,j),'i')
                sector3 = j;
            end
        end
    catch
        try
            str = ncread(Files(3).name,'basin');
            sector1 = 1;
            sector2 = 3;
            sector3 = 2;
        catch
            sector1 = 2;
            sector2 = 1;
            sector3 = 3;
        end
    end

    %  北大西洋
    j_inx = lat>=0 & lat<=55;
    fai = msftyz(j_inx,:,sector1,:)./1025./10^6;
    T = max(fai,[],[1 2],"omitmissing");                                            %寻找全深度流函数最大值作为AMOC强度
    T = squeeze(T);                                                             %降维
    data = zeros([t(end) 1]);
    for j = 1:t(end)
        data(j) = mean(T(12*j-11:12*j),"all","omitmissing");            %年平均
    end
    anom = data-mean(data(1:10));
    [p,S] = polyfit(t,anom,1);                                                  %数据线性拟合重构
    [trend,error] = polyval(p,t,S);
    NA(i) = trend(end)-trend(1);

    %  南大洋
    j_inx = lat>=-30 & lat<=-29;
    fai = msftyz(j_inx,:,sector2,:)./1025./10^6;
    T = max(fai,[],[1 2],"omitmissing");                                            %寻找全深度流函数最大值作为AMOC强度
    T = squeeze(T);
    data = zeros([t(end) 1]);
    for j = 1:t(end)
        data(j) = mean(T(12*j-11:12*j),"all","omitmissing");            %年平均
    end
    anom = data-mean(data(1:10));
    [p,S] = polyfit(t,anom,1);                                                  %数据线性拟合重构
    [trend,error] = polyval(p,t,S);
    SO(i) = trend(end)-trend(1);

    j_inx = lat>=-30 & lat<=-29;
    fai = msftyz(j_inx,:,sector1,:)./1025./10^6;
    T = max(fai,[],[1 2],"omitmissing");                                            %寻找全深度流函数最大值作为AMOC强度
    T = squeeze(T);
    data = zeros([t(end) 1]);
    for j = 1:t(end)
        data(j) = mean(T(12*j-11:12*j),"all","omitmissing");            %年平均
    end
    anom = data-mean(data(1:10));
    [p,S] = polyfit(t,anom,1);                                                  %数据线性拟合重构
    [trend,error] = polyval(p,t,S);
    ATL(i) = trend(end)-trend(1);

    j_inx = lat>=-30 & lat<=-29;
    fai = msftyz(j_inx,:,sector3,:)./1025./10^6;
    T = min(fai,[],[1 2],"omitmissing");                                            %寻找全深度流函数最大值作为AMOC强度
    T = squeeze(T);
    data = zeros([t(end) 1]);
    for j = 1:t(end)
        data(j) = mean(T(12*j-11:12*j),"all","omitmissing");            %年平均
    end
    anom = data-mean(data(1:10));
    [p,S] = polyfit(t,anom,1);                                                  %数据线性拟合重构
    [trend,error] = polyval(p,t,S);
    IP(i) = trend(end)-trend(1);
end

%% 画图
%  绝对
hold on
cd D:\Desktop\work\SO&ITF\picture\total\
figure(1)
set(gcf,'color','white')
set(gcf,'Position',[50,50,1100,1200])
% set(gcf,'position',[100,100,800,600])
clf
hold on
for i = 1:7
    eval(strcat('s',num2str(i),' = scatter(NA(i),SO(i),200,"filled","MarkerFaceColor","',colorList{i},'");'));
end

for i = 8:length(modelList)
    eval(strcat('s',num2str(i),' = scatter(NA(i),SO(i),200,"filled","square","MarkerFaceColor","',colorList{i-7},'");'));
end

% axis equal
xlabel('North Atlantic','FontSize',36)
ylabel('Southern Ocean','FontSize',36)
% xlim([-11 -2])
% ylim([1 6])

[~,lgd] = legend(modelList,'FontSize',16,'Location','eastoutside');
for i = length(modelList)+1:2*length(modelList)
    lgd(i).Children.MarkerSize = 16;
end
% set(lgd,'NumColumns',2)
path = cd;
saveas(gcf,strcat(path,'/strengthAbsolute.jpg'));
% close;

%  归一化
load D:/Desktop/work/SO&ITF/data/inx.mat
hold on
cd D:\Desktop\work\SO&ITF\picture\total\
figure(1)
set(gcf,'color','white')
set(gcf,'position',[100,100,800,600])
clf
hold on
data = zeros([length(inx) 1]);
for i = 1:length(inx)
    data(i) = -SO(inx(i))/NA(inx(i));
end
b = bar(modelList,data,'grouped');
for k = 1:length(b)
    b(k).EdgeColor = 'none'; % 将每个条形的边框颜色设置为无
end
ylabel('Strength(Sv)',"FontSize",20)
path = cd;
saveas(gcf,strcat(path,'/strengthNormal.jpg'));
close;