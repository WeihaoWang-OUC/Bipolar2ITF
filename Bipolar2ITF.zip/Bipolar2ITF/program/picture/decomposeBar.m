clear
figure(1)
clf
set(gcf,'color','white')
set(gcf,'position',[-500,500,2400,1200])
set(gcf, 'DefaultTextFontName', 'Times New Roman');

%% (a)&(b)
%  读取数据
cd D:\Desktop\SO&ITF\data\RGM
filename1 = "control.txt";
filename2 = "SO_linear.txt";
filename3 = "NA_linear.txt";
filename4 = "SO&NA_linear.txt";
% filename2 = "SO.txt";
% filename3 = "NA.txt";
% filename4 = "SO&NA.txt";
control = load(filename1);
data_SO = load(filename2);
data_NA = load(filename3);
data_SO_NA = load(filename4);
varList = {"ATL","PAC","IND","ITF","hatl","hpac","hind"};
climatology = [11.1 12.4 -14.2 13.7 1227.24 1294.47 1298.52 788.78];
[n1,n2] = size(control);
t = (1:n1)/12;

%  贡献分解
len = 100*12;
data = data_SO_NA;
for i = [1,3]
    varName = varList{i};
    eval(strcat(varName," = data(1:len,i)-data(1,i);"));
end
% A = [1,-1;0.6703,1.9672];
A = [1,-1;0.67,1.9672];
k = 0.76*[0.67;1.9672];
for n = 1:len
    b = [-ATL(n);IND(n)];
    x = A\b;
    frac(:,n) = -k(:).*x(:);
end
ITF = zeros([2,len]);
data = data_NA;
ITF(1,:) = data(1:len,4)-data(1,4);
data = data_SO;
ITF(2,:) = data(1:len,4)-data(1,4);

    annotation('textbox', [0.0, 0.92, 0.4, 0.05], 'String', 'Reduced Gravity Model', ...
        'EdgeColor', 'none', 'FontName','Times New Roman','HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize',48);
annotation('textbox', [0.4, 0.92, 0.6, 0.05], 'String', 'CMIP6', ...
    'EdgeColor', 'none', 'FontName','Times New Roman','HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize',48);

%  画图(a)
ax1 = subplot('Position', [0.05, 0.515, 0.30, 0.36]);
set(gca,'Fontsize',16,'FontName','Times New Roman')
hold on

p1 = plot(t(1:len),frac(1,1:len),'LineWidth',2.5,'Color','#F09BA0');
p2 = plot(t(1:len),ITF(1,1:len),'LineWidth',2.5,'Color','#614099');
% text(20, -1.4, 'NA experiment', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize',24);

ax1.TickDir = 'out';
legend({'Decomposition','Model'},'FontSize',28,'FontName','Times New Roman')
ylabel('ITF changes (Sv)','FontSize',30,'FontName','Times New Roman')
title('(a) NA contributions','FontSize',28,'FontName','Times New Roman')
ax = gca;
ax.TitleHorizontalAlignment = 'left';

xc = get(gca,'XColor');
yc = get(gca,'YColor');
unit = get(gca,'units');
ax = axes( 'Units', unit,...
'Position',get(gca,'Position'),...
'XAxisLocation','top',...
'YAxisLocation','right',...
'Color','none',...
'XColor',xc,...
'YColor',yc);
set(ax, 'linewidth',1,...
'XTick', [],...
'YTick', [],'Fontsize',12);
box on

%  画图(b)
ax2 = subplot('Position', [0.05, 0.075, 0.30, 0.36]);
set(gca,'Fontsize',16,'FontName','Times New Roman')
hold on

p1 = plot(t(1:len),frac(2,1:len),'LineWidth',2.5,'Color','#F09BA0');
p2 = plot(t(1:len),ITF(2,1:len),'LineWidth',2.5,'Color','#614099');
% text(20, -1.4, 'SO experiment', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize',24);

ax2.TickDir = 'out';
legend({'Decomposition','Model'},'FontSize',28,'FontName','Times New Roman')
xlabel('Time (year)','FontSize',30,'FontName','Times New Roman')
ylabel('ITF changes (Sv)','FontSize',30,'FontName','Times New Roman')
title('(b) SO contributions','FontSize',28,'FontName','Times New Roman')
ax = gca;
ax.TitleHorizontalAlignment = 'left';

xc = get(gca,'XColor');
yc = get(gca,'YColor');
unit = get(gca,'units');
ax = axes( 'Units', unit,...
'Position',get(gca,'Position'),...
'XAxisLocation','top',...
'YAxisLocation','right',...
'Color','none',...
'XColor',xc,...
'YColor',yc);
set(ax, 'linewidth',1,...
'XTick', [],...
'YTick', [],'Fontsize',12);
box on

%% (c)&(d)
clear
modelList = {'ACCESS-CM2','CESM2','CanESM5-1','HadGEM3-GC31-MM'};
colorstyle = {"#614099","#B3C4D4","#2D8875"};

%  读入数据
cd D:\Desktop\SO&ITF\data\

for i = 1:length(modelList)
    load(strcat(modelList{i},'\T.mat'),"ITFk","frac_k","PACk");
    ITF(i) = -abs(ITFk(end)-ITFk(1));
    NA(i) = -frac_k(1,end)+frac_k(1,1);
    SO(i) = -frac_k(2,end)+frac_k(2,1);
    wind(i) = PACk(end)-PACk(1);
    data(i,:) = [ITF(i),NA(i)+SO(i)+wind(i),NA(i)+SO(i)];
end
% ITFend = mean(ITF,"all");
% NAend = mean(NA,"all");
% SOend = mean(SO,"all");
% windend = mean(wind,"all");
% data(length(modelList),:) = [ITFend,NAend+SOend+windend,NAend,SOend,windend];
% [~,inx] = sort(data(:,4)./data(:,1));
% data0 = data;
% modelList0 = modelList;
% for i = 1:length(inx)
%     data(i,:) = data0(inx(i),:);
%     modelList{i} = modelList0{inx(i)};
% end
% save('D:\Desktop\work\SO&ITF\data\inx.mat',"modelList")

cd D:\Desktop\SO&ITF\picture\total\

%  (c)
ax3 = subplot('Position', [0.41, 0.515, 0.58, 0.36]);
set(gca,'Fontsize',16,'FontName','Times New Roman')
hold on

b1 = bar(modelList,data,'grouped');
set(gca, 'ydir', 'reverse')
ax3.XAxis.FontSize = 24;
ax3.XTickLabel = [];
for k = 1:length(b1)
    b1(k).EdgeColor = 'none'; % 将每个条形的边框颜色设置为无
    b1(k).FaceColor = colorstyle{k}; % 为每一组数据设置颜色
end

ax = gca;
ax.TickDir = 'out';
ylabel('ITF changes (Sv)',"FontSize",30,'FontName','Times New Roman')
legend(b1, {'CMIP6 models', 'Bipolar + wind', 'Bipolar'}, 'Position', [0.69, 0.75, 0.13, 0.1],'FontSize',28,'FontName','Times New Roman','Interpreter','latex'); % 添加图例，并指定位置
% legend(b, {'$\delta\textit{T}_\mathrm{ITF}$', '$\delta\textit{\tilde{T}}_\mathrm{ITF}$', '$\delta\textit{T}_\mathrm{ITF}^\mathrm{\hspace{2pt}N}+\delta\textit{T}_\mathrm{ITF}^\mathrm{\hspace{2pt}S}$'},'FontSize',28,'FontName','Times New Roman','Interpreter','latex'); % 添加图例，并指定位置
title('(c)','FontSize',28,'FontName','Times New Roman')
ax = gca;
ax.TitleHorizontalAlignment = 'left';

xc = get(gca,'XColor');
yc = get(gca,'YColor');
unit = get(gca,'units');
ax = axes( 'Units', unit,...
'Position',get(gca,'Position'),...
'XAxisLocation','top',...
'YAxisLocation','right',...
'Color','none',...
'XColor',xc,...
'YColor',yc);
set(ax, 'linewidth',1,...
'XTick', [],...
'YTick', [],'Fontsize',12);
box on

%  (d)
colorstyle = {"#AD6800","#FFE494","#BD7795"};
for i = 1:length(modelList)
    data(i,:) = [NA(i),SO(i),wind(i)];
end

ax4 = subplot('Position', [0.41, 0.075, 0.58, 0.36]);
set(gca,'Fontsize',16,'FontName','Times New Roman')
hold on

b2 = bar(modelList,data,'grouped');
set(gca, 'ydir', 'reverse')
ax4.XAxis.FontSize = 24;
for k = 1:length(b2)
    b2(k).EdgeColor = 'none'; % 将每个条形的边框颜色设置为无
    b2(k).FaceColor = colorstyle{k}; % 为每一组数据设置颜色
end

ax = gca;
ax.TickDir = 'out';
ylabel('Contribution to ITF changes (Sv)',"FontSize",30,'FontName','Times New Roman')
legend(b2, {'North Atlantic', 'Southern Ocean', 'Wind'}, 'Position', [0.69, 0.31, 0.13, 0.1],'FontSize',28,'FontName','Times New Roman','Interpreter','latex'); % 添加图例，并指定位置
% legend(b, {'$\delta\textit{T}_\mathrm{ITF}$', '$\delta\textit{\tilde{T}}_\mathrm{ITF}$', '$\delta\textit{T}_\mathrm{ITF}^\mathrm{\hspace{2pt}N}+\delta\textit{T}_\mathrm{ITF}^\mathrm{\hspace{2pt}S}$'},'FontSize',28,'FontName','Times New Roman','Interpreter','latex'); % 添加图例，并指定位置
title('(d)','FontSize',28,'FontName','Times New Roman')
ax = gca;
ax.TitleHorizontalAlignment = 'left';

xc = get(gca,'XColor');
yc = get(gca,'YColor');
unit = get(gca,'units');
ax = axes( 'Units', unit,...
'Position',get(gca,'Position'),...
'XAxisLocation','top',...
'YAxisLocation','right',...
'Color','none',...
'XColor',xc,...
'YColor',yc);
set(ax, 'linewidth',1,...
'XTick', [],...
'YTick', [],'Fontsize',12);
box on

%% 保存
path = cd;
exportgraphics(gcf, strcat(path,'\decomposeBar.jpg'));
close;