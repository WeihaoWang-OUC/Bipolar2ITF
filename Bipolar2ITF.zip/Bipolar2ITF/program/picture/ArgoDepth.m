clear
%% 读取数据
cd D:\Desktop\work\SO&ITF\data\argo\
name = 'RG-Argo_sigma_200401-202411_mon.nc';
x = ncread(name,'longitude');
y = ncread(name,'latitude');
p = ncread(name,'pressure');
rho = ncread(name,'sigma1');
sigma = mean(rho,4,"omitmissing");
[nx,ny,np] = size(sigma);
pp = zeros([nx,ny]);

%% 估算深度
target = 31.8;
for i = 1:nx
    for j = 1:ny
        tmp = squeeze(sigma(i,j,:));
        for k = 2:np
            if tmp(k)>=target || k == np
                k_inx = [k-1,k];
                break
            end
        end
        if isnan(tmp(k_inx(1)))
            pp(i,j) = nan;
        elseif tmp(k_inx(1))>target
            pp(i,j) = 0;
        elseif tmp(k_inx(2))<target
            pp(i,j) = p(end);
        else
            pp(i,j) = interp1(tmp(k_inx),p(k_inx),target);
        end
    end
end

%% 画图
foldname = 'D:\Desktop\work\SO&ITF\picture\argo';
if ~exist(foldname,"dir")
    mkdir(foldname)
end
cd(foldname)

hold on
figure(1)
set(gcf,'color','white')
set(gcf,'position',[100,100,1400,700])
m_proj('Robinson','lon',[0 360],'lat',[-65 80]);
m_contourf(x,y,pp)
colormap(cmocean('dense',6))
shading interp
cb = colorbar;
cb.Label.String = 'Pressure(dbar)';
cb.Label.FontSize = 36;
m_coast('patch',[.6 .6 .6],'edgecolor','k');%画出海岸线
m_grid;

path = cd;
saveas(gcf,strcat(path,'/interface.jpg'));
close;