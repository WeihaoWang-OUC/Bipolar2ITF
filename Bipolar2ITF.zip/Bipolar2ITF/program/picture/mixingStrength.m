clear
modelList = {'ACCESS-CM2','CMCC-ESM2','CanESM5','HadGEM3-GC31-LL'};
% colorstyle = {"#A5AEB7","#B55384","#CCCC99"};
colorstyle = {"#282973"};

figure(1)
clf
set(gcf,'color','white')
set(gcf,'position',[-1000,500,2000,1500])
set(gcf, 'DefaultTextFontName', 'Times New Roman');

%  (a)
ax1 = subplot('Position', [0.05, 0.50, 0.43, 0.36]);
set(gca,'Fontsize',16,'FontName','Times New Roman')
hold on

[T1,~,~] = dataRead(modelList{1});

k1 = solveTrend(T1,colorstyle{1});
% k2 = solveTrend(T2,colorstyle{2});
% k3 = solveTrend(T3,colorstyle{3});

xlim([2015,2100])
% ylim([-15,15])
ylabel("Upwelling transport (Sv)","FontSize",30,'FontName','Times New Roman')
title(['(a) ',modelList{1}],'FontSize',30,'FontName','Times New Roman')
ax = gca;
ax.TitleHorizontalAlignment = 'left';
ax.TickDir = 'out';

xc = get(gca,'XColor');
yc = get(gca,'YColor');
unit = get(gca,'units');
ax = axes( 'Units', unit,...
'Position',get(gca,'Position'),...
'XAxisLocation','top',...
'YAxisLocation','right',...
'Color','none',...
'XColor',xc,...
'YColor',yc);
set(ax, 'linewidth',1,...
'XTick', [],...
'YTick', [],'Fontsize',12);
box on

%  (b)
ax2 = subplot('Position', [0.535, 0.50, 0.43, 0.36]);
set(gca,'Fontsize',16,'FontName','Times New Roman')
hold on

[T1,~,~] = dataRead(modelList{2});

k1 = solveTrend(T1,colorstyle{1});
% k2 = solveTrend(T2,colorstyle{2});
% k3 = solveTrend(T3,colorstyle{3});

xlim([2015,2100])
% ylim([-15,15])
title(['(b) ',modelList{2}],'FontSize',30,'FontName','Times New Roman')
ax = gca;
ax.TitleHorizontalAlignment = 'left';
ax.TickDir = 'out';

xc = get(gca,'XColor');
yc = get(gca,'YColor');
unit = get(gca,'units');
ax = axes( 'Units', unit,...
'Position',get(gca,'Position'),...
'XAxisLocation','top',...
'YAxisLocation','right',...
'Color','none',...
'XColor',xc,...
'YColor',yc);
set(ax, 'linewidth',1,...
'XTick', [],...
'YTick', [],'Fontsize',12);
box on

%  (c)
ax3 = subplot('Position', [0.05, 0.06, 0.43, 0.36]);
set(gca,'Fontsize',16,'FontName','Times New Roman')
hold on

[T1,~,~] = dataRead(modelList{3});

k1 = solveTrend(T1,colorstyle{1});
% k2 = solveTrend(T2,colorstyle{2});
% k3 = solveTrend(T3,colorstyle{3});

xlim([2015,2100])
% ylim([-15,15])
xlabel("Time (year)","FontSize",30,'FontName','Times New Roman')
ylabel("Upwelling transport (Sv)","FontSize",30,'FontName','Times New Roman')
title(['(c) ',modelList{3}],'FontSize',30,'FontName','Times New Roman')
ax = gca;
ax.TitleHorizontalAlignment = 'left';
ax.TickDir = 'out';

xc = get(gca,'XColor');
yc = get(gca,'YColor');
unit = get(gca,'units');
ax = axes( 'Units', unit,...
'Position',get(gca,'Position'),...
'XAxisLocation','top',...
'YAxisLocation','right',...
'Color','none',...
'XColor',xc,...
'YColor',yc);
set(ax, 'linewidth',1,...
'XTick', [],...
'YTick', [],'Fontsize',12);
box on

%  (d)
ax4 = subplot('Position', [0.535, 0.06, 0.43, 0.36]);
set(gca,'Fontsize',16,'FontName','Times New Roman')
hold on

[T1,~,~] = dataRead(modelList{4});

k1 = solveTrend(T1,colorstyle{1});
% k2 = solveTrend(T2,colorstyle{2});
% k3 = solveTrend(T3,colorstyle{3});

xlim([2015,2100])
% ylim([-15,15])
xlabel("Time (year)","FontSize",30,'FontName','Times New Roman')
title(['(d) ',modelList{4}],'FontSize',30,'FontName','Times New Roman')
ax = gca;
ax.TitleHorizontalAlignment = 'left';
ax.TickDir = 'out';

xc = get(gca,'XColor');
yc = get(gca,'YColor');
unit = get(gca,'units');
ax = axes( 'Units', unit,...
'Position',get(gca,'Position'),...
'XAxisLocation','top',...
'YAxisLocation','right',...
'Color','none',...
'XColor',xc,...
'YColor',yc);
set(ax, 'linewidth',1,...
'XTick', [],...
'YTick', [],'Fontsize',12);
box on

%%
% legend([k1,k2,k3],{'1000m','1500m','2000m'},'Position', [0.36, 0.92, 0.28, 0.05], 'Orientation', 'horizontal','FontSize',36,'FontName','Times New Roman')

%% 保存
cd('D:\Desktop\SO&ITF\picture\total')
path = cd;
exportgraphics(gcf, strcat(path,'/upwelling.jpg'));
close;




function [T1,T2,T3] = dataRead(model)
varname = 'msftmz';
cd(strcat('D:\Desktop\data\CMIP6\',model))
if exist(".\msftmz\","dir")==7
    varname = 'msftmz';
elseif exist(".\msftmz\","dir")==0
    varname = 'msftyz';
end
foldname = strcat('D:\Desktop\data\CMIP6\',model,'\',varname);
addpath(foldname)

Files = dir(foldname);                                                      %用结构体读取文件夹中全部nc文件
msftmz = [];                                                                %建立空矩阵
for i = 3:length(Files)                                                     %前两个为上下级，忽略掉向后两个读取
    name = Files(i).name;                                                   %读取nc文件名
    folder = Files(i).folder;                                               %读取文件夹名称
    cd(folder)                                                              %更改matlab路径
    data = ncread(name,varname);                                            %读取变量
    data = squeeze(data);
    msftmz = cat(4,msftmz,data);
end

%  纬度
try
    lat = ncread(Files(3).name,'lat');
catch
    try
        lat = ncread(Files(3).name,'rlat');
    catch
        lat = ncread(Files(3).name,'nav_lat');
    end
end
latTarget = -29;
[~,j_inx] = min(abs(lat-latTarget));

%  密度
lev = ncread(name,'lev');

levTarget1 = 1000;
[~,k_inx1] = min(abs(lev-levTarget1));
levTarget2 = 1500;
[~,k_inx2] = min(abs(lev-levTarget2));
levTarget3 = 2000;
[~,k_inx3] = min(abs(lev-levTarget3));

%  确定海盆
try
    str = ncread(Files(3).name,'sector');
    for t = 1:size(str,2)
        if strcmpi(str(1,t),'i')
            sector = t;
        end
    end
catch
    try
        str = ncread(Files(3).name,'basin');
        sector = 1;
    catch
        sector = 2;
    end
end

fai1 = squeeze(msftmz(j_inx:end,k_inx1,sector,:)./1025./10^6);
fai2 = squeeze(msftmz(j_inx:end,k_inx2,sector,:)./1025./10^6);
fai3 = squeeze(msftmz(j_inx:end,k_inx3,sector,:)./1025./10^6);

%  转化
[ny,nt] = size(fai1);
T1 = zeros([nt,1]);
T2 = zeros([nt,1]);
T3 = zeros([nt,1]);
for t = 1:nt
    for j = 1:ny-1
        if isnan(fai1(j+1,t))&&~isnan(fai1(j,t))
            T1(t) = fai1(j,t)-fai1(1,t);
        end
        if isnan(fai2(j+1,t))&&~isnan(fai2(j,t))
            T2(t) = fai2(j,t)-fai2(1,t);
        end
        if isnan(fai3(j+1,t))&&~isnan(fai3(j,t))
            T3(t) = fai3(j,t)-fai3(1,t);
        end
    end
end
end

function [k] = solveTrend(T,colorstyle)
data = zeros([86,1]);
for t = 1:86
    data(t) = mean(T(t*12-11:t*12),"all","omitmissing");
end
climatology = mean(data(1:10),"all");
anomaly = data-climatology;
t = 2015:2100;
p = polyfit(t,anomaly,1);
trend = polyval(p,t);
plot(t,data,'--','Color',colorstyle,'LineWidth',2);
k = plot([2015 2024],[climatology,climatology],'Color',colorstyle,'LineWidth',3.5);
end