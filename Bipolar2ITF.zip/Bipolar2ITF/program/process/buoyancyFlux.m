function[] = buoyancyFlux(dataname)
addpath 'D:\Desktop\work\SO&ITF\program\process'
%% 定义常数
g = 10;
c_p = 4096;
rho_0 = 1025;

%% 热通量
foldname = strcat('D:\Desktop\work\SO&ITF\data\',dataname,'\hfds');
Files = dir(foldname);                                                      %用结构体读取文件夹中全部nc文件
folder = Files.folder;
cd(folder)

name = Files(3).name;

%  读取经纬度
try
    x = ncread(name,'longitude');
    y = ncread(name,'latitude');
catch
    try
        x = ncread(name,'nav_lon');
        y = ncread(name,'nav_lat');
    catch
        x = ncread(name,'lon');
        y = ncread(name,'lat');
    end
end

%  经纬度降维
inx = y<-29 & y>-81;
j_inx = find(inx(1,:));
lat = squeeze(mode(y,1));
lon = mode(x,2);
lat = lat(j_inx);
clear x y inx

%  数据调整顺序
[lon,i_inx] = sort(lon);

%  读取热通量
hfds = [];
parfor i = 3:length(Files)                                                %前两个为上下级，忽略掉向后两个读取
    name = Files(i).name;                                                 %读取nc文件名
    data = readnc(name,'hfds',i_inx,j_inx);                        %读取变量
    data = permute(data,[1,3,2]);                                       %矩阵转置
    hfds = [hfds,data];
end
hfds = permute(hfds,[1,3,2]);

%% 海表面温度
foldname = strcat('D:\Desktop\work\SO&ITF\data\',dataname,'\tos');
Files = dir(foldname);                                                      %用结构体读取文件夹中全部nc文件
folder = Files.folder;
cd(folder)

tos = [];
parfor i = 3:length(Files)                                                %前两个为上下级，忽略掉向后两个读取
    name = Files(i).name;                                                 %读取nc文件名
    data = readnc(name,'tos',i_inx,j_inx);                        %读取变量
    data = permute(data,[1,3,2]);                                       %矩阵转置
    tos = [tos,data];
end
tos = permute(tos,[1,3,2]);

%% 海表面盐度
foldname = strcat('D:\Desktop\work\SO&ITF\data\',dataname,'\sos');
Files = dir(foldname);                                                      %用结构体读取文件夹中全部nc文件
folder = Files.folder;
cd(folder)

sos = [];
parfor i = 3:length(Files)                                                %前两个为上下级，忽略掉向后两个读取
    name = Files(i).name;                                                 %读取nc文件名
    data = readnc(name,'sos',i_inx,j_inx);                        %读取变量
    data = permute(data,[1,3,2]);                                       %矩阵转置
    sos = [sos,data];
end
sos = permute(sos,[1,3,2]);

%% 海表面压强
[nx,ny,nt] = size(tos);
pso = zeros([nx,ny,nt]);

%% 淡水通量
foldname = strcat('D:\Desktop\work\SO&ITF\data\',dataname,'\wfo');
if ~exist(foldname,"dir")
    %  大气网格下
    foldname = strcat('D:\Desktop\work\SO&ITF\data\',dataname,'\evspsbl');
    Files = dir(foldname);                                                      %用结构体读取文件夹中全部nc文件
    folder = Files.folder;
    cd(folder)

    name = Files(3).name;

    %  读取经纬度
    try
        x = ncread(name,'longitude');
        y = ncread(name,'latitude');
    catch
        try
            x = ncread(name,'nav_lon');
            y = ncread(name,'nav_lat');
        catch
            x = ncread(name,'lon');
            y = ncread(name,'lat');
        end
    end

    %  经纬度降维
    i_inx = 1:length(x);
    j_inx = find(y<-29 & y>-81);
    latA = squeeze(y(j_inx))';
    lonA = x;
    clear x y

    %  读取蒸发
    evspsbl = [];
    parfor i = 3:length(Files)                                                %前两个为上下级，忽略掉向后两个读取
        name = Files(i).name;                                                 %读取nc文件名
        data = readnc(name,'evspsbl',i_inx,j_inx);                        %读取变量
        data = permute(data,[1,3,2]);                                       %矩阵转置
        evspsbl = [evspsbl,data];
    end
    evspsbl = permute(evspsbl,[1,3,2]);

    %  读取降水
    foldname = strcat('D:\Desktop\work\SO&ITF\data\',dataname,'\pr');
    Files = dir(foldname);                                                      %用结构体读取文件夹中全部nc文件
    folder = Files.folder;
    cd(folder)

    pr = [];
    parfor i = 3:length(Files)                                                %前两个为上下级，忽略掉向后两个读取
        name = Files(i).name;                                                 %读取nc文件名
        data = readnc(name,'pr',i_inx,j_inx);                        %读取变量
        data = permute(data,[1,3,2]);                                       %矩阵转置
        pr = [pr,data];
    end
    pr = permute(pr,[1,3,2]);

    %  插值
    [x0,y0] = meshgrid(lon,lat);
    [x,y] = meshgrid(lonA,latA);
    wfo = zeros([length(lon),length(lat),length(evspsbl)]);
    for t = 1:length(evspsbl)
        E = interp2(x,y,evspsbl(:,:,t)',x0,y0);
        P = interp2(x,y,pr(:,:,t)',x0,y0);
        for i = 1:length(lon)
            for j = 1:length(lat)
                wfo(i,j,t) = (P(j,i)-E(j,i))';
            end
        end
    end

    %  海冰网格下
    foldname = strcat('D:\Desktop\work\SO&ITF\data\',dataname,'\siflfwdrain');
    Files = dir(foldname);                                                      %用结构体读取文件夹中全部nc文件
    folder = Files.folder;
    cd(folder)

    name = Files(3).name;

    %  读取经纬度
    try
        x = ncread(name,'longitude');
        y = ncread(name,'latitude');
    catch
        try
            x = ncread(name,'nav_lon');
            y = ncread(name,'nav_lat');
        catch
            x = ncread(name,'lon');
            y = ncread(name,'lat');
        end
    end

    %  经纬度降维
    x(x>360) = nan;
    y(y>90) = nan;
    [nx,ny] = size(x);
    lonI = zeros([1 nx]);
    latI0 = zeros([1 ny]);
    for i = 1:nx
        j_inx = find(~isnan(x(i,:)));
        lonI(i) = x(i,j_inx(1));
    end
    for j = 1:ny
        i_inx = find(~isnan(y(:,j)));
        latI0(j) = y(i_inx(1),j);
    end
    j_inx = find(latI0<-29 & latI0>-81);
    latI = latI0(j_inx);
    clear x y

    %  数据调整顺序
    [lonI,i_inx] = sort(lonI);

    %  读取海冰融化
    siflfwdrain = [];
    parfor i = 3:length(Files)                                                %前两个为上下级，忽略掉向后两个读取
        name = Files(i).name;                                                 %读取nc文件名
        data = readnc(name,'siflfwdrain',i_inx,j_inx);                        %读取变量
        data = permute(data,[1,3,2]);                                       %矩阵转置
        siflfwdrain = [siflfwdrain,data];
    end
    siflfwdrain = permute(siflfwdrain,[1,3,2]);

    %  插值
    [x0,y0] = meshgrid(lon,lat);
    [x,y] = meshgrid(lonI,latI);
    for t = 1:size(evspsbl,3)
        I = interp2(x,y,siflfwdrain(:,:,t)',x0,y0);
        for i = 1:length(lon)
            for j = 1:length(lat)
                if isnan(I(j,i))
                    I(j,i) = 0;
                end
                wfo(i,j,t) = wfo(i,j,t)+I(j,i);
            end
        end
    end

else
    Files = dir(foldname);                                                      %用结构体读取文件夹中全部nc文件
    folder = Files.folder;
    cd(folder)

    wfo = [];
    parfor i = 3:length(Files)                                                %前两个为上下级，忽略掉向后两个读取
        name = Files(i).name;                                                 %读取nc文件名
        data = readnc(name,'wfo',i_inx,j_inx);                        %读取变量
        data = permute(data,[1,3,2]);                                       %矩阵转置
        wfo = [wfo,data];
    end
    wfo = permute(wfo,[1,3,2]);

end

%% 计算
%  用gsw计算系数
CT = gsw_CT_from_t(sos,tos,pso);
[nx,ny,nt] = size(pso);
SA = zeros([nx ny nt]);
for t = 1:nt
    SA(:,:,t) = gsw_SA_from_SP(sos(:,:,t),pso(:,:,t),lon(:),lat(:));
end
[~,alpha,beta] = gsw_rho_alpha_beta(SA,CT,pso);

%  计算浮力通量
buoyancy = g/rho_0*(alpha/c_p.*hfds+beta.*wfo.*SA);

%  计算趋势
time = 1:86;
nt = time(end);
varList = {'B','H','F'};
for n = 1:length(varList)
    eval(strcat(varList{n},'trend = zeros([1 length(lat)]);'))
end
for j = 1:ny
    for n = 1:length(varList)
        eval(strcat(lower(varList{n}),' = zeros([nt 1]);'))
    end
    for t = 1:nt
        b(t) = mean(buoyancy(:,j,12*t-11:12*t),"all","omitmissing");            %年平均
        h(t) = mean(hfds(:,j,12*t-11:12*t),"all","omitmissing");
        f(t) = mean(wfo(:,j,12*t-11:12*t),"all","omitmissing");
    end
    for n = 1:length(varList)
        eval(strcat('data = ',lower(varList{n}),';'))
        anom = data-mean(data(1:10));
        [p,S] = polyfit(time,anom,1);                                                  %数据线性拟合重构
        [trend,~] = polyval(p,time,S);
        eval(strcat(varList{n},'trend(j) = trend(end)-trend(1);'))
    end
end
B = mean(buoyancy(:,:,1:120),[1 3],"omitmissing");
H = mean(hfds(:,:,1:120),[1 3],"omitmissing");
F = mean(wfo(:,:,1:120),[1 3],"omitmissing" );

%% 储存数据
clear lonI lonA lat0 latI latI0 latA
savefile = strcat('D:\Desktop\work\SO&ITF\data\',dataname,'\B.mat');
save(savefile,'-regexp','^B','^H','^F','lon','lat','buoyancy')