function[T] = solveAMOC(dataname)
%% 读入数据
varname = 'msftmz';
cd(strcat('D:\Desktop\work\SO&ITF\data\',dataname))
if exist(".\msftmz\","dir")==7
    varname = 'msftmz';
elseif exist(".\msftmz\","dir")==0
    varname = 'msftyz';
end
foldname = strcat('D:\Desktop\work\SO&ITF\data\',dataname,'\',varname);
addpath(foldname)

Files = dir(foldname);                                                      %用结构体读取文件夹中全部nc文件
msftyz = [];                                                                %建立空矩阵
for i = 3:length(Files)                                                     %前两个为上下级，忽略掉向后两个读取
    name = Files(i).name;                                                   %读取nc文件名
    folder = Files(i).folder;                                               %读取文件夹名称
    cd(folder)                                                              %更改matlab路径
    data = ncread(name,varname);                                            %读取变量
    data = squeeze(data);
    % data = permute(data,[2,1,3,4]);                                       %把矩阵转置和xy对应
    msftyz = cat(4,msftyz,data);
end

try
    lat = ncread(Files(3).name,'lat');
catch
    try
        lat = ncread(Files(3).name,'rlat');
    catch
        lat = ncread(Files(3).name,'nav_lat');
    end
end

try
    str = ncread(Files(3).name,'sector');
    for t = 1:size(str,2)
        if strcmpi(str(1,t),'a')
            sector = t;
        end
    end
catch
    try
        str = ncread(Files(3).name,'basin');
        sector = 1;
    catch
        sector = 2;
    end
end
latTarget = -29;
[~,j_inx] = min(abs(lat-latTarget));
fai = msftyz(j_inx,:,sector,:)./1025./10^6;


%% 转化为AMOC强度
T = max(fai,[],2,"omitmissing");                                            %寻找全深度流函数最大值作为AMOC强度
T = squeeze(T);                                                             %降维