function[] = process(dataname)
%%%modelList = {'ACCESS-CM2','ACCESS-ESM1.5','CanESM5','CanESM5-CanOE','CESM2','CESM2-WACCM','CIESM','HadGEM3-GC31-LL','HadGEM3-GC31-MM','IPSL-CM6A-LR','MRI-ESM2-0','NorESM2-LM','NorESM2-MM','UKESM1-0-LL'};
foldRoot = strcat('D:\Desktop\work\SO&ITF\program\process');
savefile = strcat('D:\Desktop\work\SO&ITF\data\',dataname,'\T.mat');
varList = {"ATL","PAC","IND","ITF","SO","BST"};
addpath(foldRoot)
cd(foldRoot)


%% 计算三大洋流量
%  确定三大洋计算截面范围
atlRange = [-49.5,16.5];
indRange = [31.5,115.5];
pacRange = [153.5,287.5];

% 开启 MATLAB 的并行池
if isempty(gcp('nocreate'))
    parpool(6);
end
maxDepth = 1000;
ATL0 = solveOcean(dataname,atlRange,maxDepth);
IND0 = solveOcean(dataname,indRange,maxDepth);
PAC0 = solveOcean(dataname,pacRange,maxDepth);
SO0 = ATL0+IND0+PAC0;


%% 计算AMOC
% AMOC0 = solveAMOC(dataname);


%% 计算ITF
[ITF0,BST0] = solveITF(dataname);


%% 数据再处理
t = 1:86;
%  计算流量异常的趋势
for i = 1:6
    eval(strcat("data0 = ",varList{i},"0;"));
    for j = 1:t(end)
        data(j) = mean(data0(12*j-11:12*j),"all","omitmissing");            %年平均
    end
    anom = data-mean(data(1:10));
    [p,S] = polyfit(t,anom,1);                                                  %数据线性拟合重构
    [trend,error] = polyval(p,t,S);
    eval(strcat(varList{i},"a = anom;"));
    eval(strcat(varList{i},"k = trend;")) ;
    eval(strcat(varList{i},"e = error;")) ;
end

%  计算AMOC和南大洋过程分别影响了多少，并计算趋势
A = [1,-1;0.62,2.75];
k = 0.76*[0.62;2.75];
for i = 1:t(end)
    b = [-ATLa(i);INDa(i)+PACa(i)];
    x = A\b;
    frac(:,i) = k(:).*x(:);
end

for i = 1:2
    [p,S] = polyfit(t,frac(i,:),1);
    [trend,error] = polyval(p,t,S);
    frac_k(i,:) = trend(:);
    frac_e(i,:) = error(:);
end

%% 储存数据
save(savefile,'-regexp','^ATL','^PAC','^IND','^SO','^ITF','^frac','^BST')