function[] = transformation(dataname)
%%  读取位密
foldname = strcat('D:\data\CMIP6\',dataname,'\sigma');
Files = dir(foldname);                                                      %用结构体读取文件夹中全部nc文件
folder = Files.folder;
cd(folder)
name = Files(3).name;

%  读取经纬度
try
    x = ncread(name,'longitude');
    y = ncread(name,'latitude');
catch
    try
        x = ncread(name,'nav_lon');
        y = ncread(name,'nav_lat');
    catch
        x = ncread(name,'lon');
        y = ncread(name,'lat');
    end
end

%  深度
try
    lev = ncread(name,'level');
catch
    try
        lev = ncread(name,'lev');
    catch
        try
            lev = ncread(name,'depth');
        catch
            lev = ncread(name,'olevel');
        end
    end
end
if lev(end)>=10000
    lev = lev./100;  %CESM2的深度单位为cm
end

%  经纬度降维
inx = y<30 & y>-30;
j_inx = find(inx(1,:));
k_inx = find(lev<=3000);
lat = squeeze(mode(y,1));
lon = mode(x,2);
lat = lat(j_inx);
lev = lev(k_inx);
clear x y inx

%  数据调整顺序
[lon,i_inx] = sort(lon);

%  读取
sigma2 = readnc(name,'sigma2',i_inx,j_inx,k_inx);

%  年平均
[nx,ny,nz,~] = size(sigma2);
sigma = zeros([nx,ny,nz,86]);
for t = 1:86
    sigma(:,:,:,t) = mean(sigma2(:,:,:,12*t-11:12*t),4,"omitmissing");
end

% %% 读取混合层厚度
% foldname = strcat('D:\Desktop\work\SO&ITF\data\',dataname,'\mlotst');
% Files = dir(foldname);                                                      %用结构体读取文件夹中全部nc文件
% folder = Files.folder;
% cd(folder)
% 
% mlotst = [];
% parfor i = 3:length(Files)                                                %前两个为上下级，忽略掉向后两个读取
%     name = Files(i).name;                                                 %读取nc文件名
%     data = readnc(name,'mlotst',i_inx,j_inx);                        %读取变量
%     data = permute(data,[1,3,2]);                                       %矩阵转置
%     mlotst = [mlotst,data];
% end
% mlotst = permute(mlotst,[1,3,2]);
% 
% %  年平均
% depth = zeros([nx,ny,86]);
% for t = 1:86
%     depth(:,:,t) = mean(mlotst(:,:,12*t-11:12*t),3,'omitmissing');
% end

%% 转化为混合层密度
% parfor t = 1:86
%     for i = 1:nx
%         for j = 1:ny
%             mld = depth(i,j,t);
%             rho = squeeze(sigma(i,j,:,t));
%             mls(i,j,t) = interp1(lev,rho,mld);
%         end
%     end
% end
% clear mld rho
mls = squeeze(sigma);
clear sigma

%% 读取浮力通量
cd(strcat('D:\Desktop\work\SO&ITF\data\',dataname))
load("B.mat",'buoyancy')

%  年平均
w = zeros([nx,ny,86]);
for t = 1:86
    w(:,:,t) = mean(buoyancy(:,:,12*t-11:12*t),3,'omitmissing')/10;
end

%% 读取网格面积
foldname = strcat('D:\Desktop\work\SO&ITF\data\',dataname,'\areacello');
Files = dir(foldname);                                                      %用结构体读取文件夹中全部nc文件
folder = Files.folder;
cd(folder)
name = Files(3).name;
area = readnc(name,'areacello',i_inx,j_inx);

%% 计算
delta = 0.5;
ref = 25:delta:34;
nn = length(ref);

%  水团转化率
for n = 1:nn
    mask = mls<ref(n)+0.5*delta & mls>ref(n)-0.5*delta;
    parfor t = 1:86
        T(t,n) = -sum(mask(:,:,t).*area.*w(:,:,t),'all','omitmissing')/10^6*1025/delta;
    end
end
WMF = -diff(T,1,2);
Fmean = mean(WMF(1:10,:),1);

%  线性趋势
time = 1:86;
Ftrend = zeros(size(Fmean));
for n = 1:nn-1
    Anom = WMF(:,n)-Fmean(n);
    [p,S] = polyfit(time,Anom,1);                                                  %数据线性拟合重构
    [trend,~] = polyval(p,time,S);
    Ftrend(n) = trend(end)-trend(1);
end


%% 画图
ref1 = 25+0.5*delta:delta:34-0.5*delta;
foldname = strcat('D:\Desktop\work\SO&ITF\picture\',dataname);
if ~exist(foldname,"dir")
    mkdir(foldname)
end
cd(foldname)

hold on
figure(1)
set(gcf,'color','white')
set(gcf,'position',[100,100,1000,800])
bar(ref1,Ftrend)
plot(ref1,Fmean,LineWidth=2)
% plot(ref1,Ftrend,LineWidth=2)
plot([ref1(1) ref1(end)],[0 0],'k--','LineWidth',1)
legend('trend','climatology','')

path = cd;
saveas(gcf,strcat(path,'/Formation.jpg'));
close;