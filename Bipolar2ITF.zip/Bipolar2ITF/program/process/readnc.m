function[var] = readnc(name,varname,i_inx,j_inx,k_inx)
nx = length(i_inx);
ny = length(j_inx);
try
    nz = length(k_inx);
    hasDepth = 1;
catch
    hasDepth = 0;
end

try
    time = ncread(name,'time');
    hasTime = 1;
catch
    hasTime = 0;
end

%  如果经度存在分段则将索引也分开
i = 1;
while 1
    if i_inx(i+1)~=i_inx(i)+1
        i_inx1 = i_inx(1:i);
        i_inx2 = i_inx(i+1:end);
        split = 1;
        break
    end
    if i == nx-1
        split = 0;
        break
    end
    i = i+1;
end

%  根据范围截取数据
if split==0
    if hasTime == 1
        if hasDepth == 1
            var = ncread(name,varname,[i_inx(1),j_inx(1),1,1],[nx,ny,nz,length(time)]);
        elseif hasDepth == 0
            var = ncread(name,varname,[i_inx(1),j_inx(1),1],[nx,ny,length(time)]);
        end
    elseif hasTime == 0
        if hasDepth == 1
            var = ncread(name,varname,[i_inx(1),j_inx(1),1],[nx,ny,nz]);
        elseif hasDepth == 0
            var = ncread(name,varname,[i_inx(1),j_inx(1)],[nx,ny]);
        end
    end
elseif split==1
    if hasTime == 1
        if hasDepth == 1
            var1 = ncread(name,varname,[i_inx1(1),j_inx(1),1,1],[length(i_inx1),ny,nz,length(time)]);
            var2 = ncread(name,varname,[i_inx2(1),j_inx(1),1,1],[length(i_inx2),ny,nz,length(time)]);
            var = cat(1,var1,var2);
        elseif hasDepth == 0
            var1 = ncread(name,varname,[i_inx1(1),j_inx(1),1],[length(i_inx1),ny,length(time)]);
            var2 = ncread(name,varname,[i_inx2(1),j_inx(1),1],[length(i_inx2),ny,length(time)]);
            var = cat(1,var1,var2);
        end
    elseif hasTime == 0
        if hasDepth == 1
            var1 = ncread(name,varname,[i_inx1(1),j_inx(1),1],[length(i_inx1),ny,nz,]);
            var2 = ncread(name,varname,[i_inx2(1),j_inx(1),1],[length(i_inx2),ny,nz]);
            var = cat(1,var1,var2);
        elseif hasDepth == 0
            var1 = ncread(name,varname,[i_inx1(1),j_inx(1)],[length(i_inx1),ny]);
            var2 = ncread(name,varname,[i_inx2(1),j_inx(1)],[length(i_inx2),ny]);
            var = cat(1,var1,var2);
        end
    end
end