clear
modelList = {'ACCESS-CM2','ACCESS-ESM1-5','CESM2','CESM2-WACCM','CIESM','CMCC-CM2-SR5','CMCC-ESM2','CanESM5','CanESM5-1','CanESM5-CanOE','EC-Earth3-CC','GISS-E2-1-G','HadGEM3-GC31-LL','HadGEM3-GC31-MM','IPSL-CM6A-LR','MPI-ESM1-2-HR','MRI-ESM2-0','NorESM2-LM','NorESM2-MM','UKESM1-0-LL'};
for i = 1:length(modelList)
    dataname = modelList{i};
    process(dataname)
    disp(dataname)
end