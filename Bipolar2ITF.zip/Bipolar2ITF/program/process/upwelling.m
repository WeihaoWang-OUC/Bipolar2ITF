clear
dataname = 'ACCESS-CM2';

%% 读取速度
foldname = strcat('D:\Desktop\work\SO&ITF\data\',dataname,'\wo');
Files = dir(foldname);                                                      %用结构体读取文件夹中全部nc文件
folder = Files.folder;
cd(folder)
name = Files(3).name;

%  纬度
try
    lat = ncread(name,'latitude');
catch
    try
        lat = ncread(name,'nav_lat');
    catch
        lat = ncread(name,'lat');
    end
end

%  深度
try
    lev = ncread(name,'level');
catch
    try
        lev = ncread(name,'lev');
    catch
        try
            lev = ncread(name,'depth');
        catch
            lev = ncread(name,'olevel');
        end
    end
end
if lev(end)>=10000
    lev = lev./100;  %CESM2的深度单位为cm
end

[nx,ny] = size(lat);
[~,k_inx1] = min(abs(lev-1000));
[~,k_inx2] = min(abs(lev-2000));
[~,k_inx3] = min(abs(lev-3000));
k_inx = [k_inx1 k_inx2 k_inx3];
lev = lev(k_inx);
nz = length(lev);

w = [];
for i = 3:length(Files)                                                %前两个为上下级，忽略掉向后两个读取
    name = Files(i).name;                                                 %读取nc文件名
    time = ncread(name,'time');
    nt = length(time);
    data = ncread(name,'wo',[1,1,k_inx(1),1],[nx,ny,nz,nt]);                        %读取变量
    wo = nan([nx,ny,nz,nt/12]);
    for t = 1:nt/12
        wo(:,:,:,t) = mean(data(:,:,:,12*t-11:12*t),4,"omitmissing");
    end
    w = cat(4,w,wo);
    clear data wo
end

w = permute(w,[1,2,4,3]);


%% 读取网格面积
foldname = strcat('D:\Desktop\work\SO&ITF\data\',dataname,'\areacello');
Files = dir(foldname);                                                      %用结构体读取文件夹中全部nc文件
folder = Files.folder;
cd(folder)
name = Files(3).name;
area = ncread(name,'areacello');

%% 读取海盆mask
foldname = strcat('D:\Desktop\work\SO&ITF\data\',dataname,'\basin');
Files = dir(foldname);                                                      %用结构体读取文件夹中全部nc文件
folder = Files.folder;
cd(folder)
name = Files(3).name;
mask = ncread(name,'basin');

for i = 1:nx
    for j = 1:ny
        if lat(i,j)>5||lat(i,j)<-5
            mask(i,j) = 0;
        end
    end
end

atl = mask==2;
ind = mask==5;
pac = mask==3;

%% 计算
[I1,I2,I3] = solvew(ind,w,area);
[P1,P2,P3] = solvew(pac,w,area);

%% 画图
colorstyle = {"#FABB6E","#369F2D"};
figure(1)
clf
set(gcf,'color','white')
set(gcf,'position',[-1000,-100,3000,1000])
set(gcf, 'DefaultTextFontName', 'Times New Roman');

%  (a)800m
ax1 = subplot('Position', [0.03, 0.1, 0.3, 0.7]); 
set(gca,'Fontsize',16,'FontName','Times New Roman')
hold on

k1 = solveTrend(I1,colorstyle{1});
k2 = solveTrend(P1,colorstyle{2});

xlim([2015,2100])
xlabel('Time (year)','FontSize',30,'FontName','Times New Roman')
ylabel('Upwelling velocity change (10^{-8}m/s)','FontSize',30,'FontName','Times New Roman')
title('(a) 800m','FontSize',28,'FontName','Times New Roman');

ax = gca;
ax.TitleHorizontalAlignment = 'left';
ax.TickDir = 'out';

xc = get(gca,'XColor');
yc = get(gca,'YColor');
unit = get(gca,'units');
ax = axes( 'Units', unit,...
    'Position',get(gca,'Position'),...
    'XAxisLocation','top',...
    'YAxisLocation','right',...
    'Color','none',...
    'XColor',xc,...
    'YColor',yc);
set(ax, 'linewidth',1,...
    'XTick', [],...
    'YTick', [],'Fontsize',12);
box on

%  (b)1000m
ax2 = subplot('Position', [0.36, 0.1, 0.3, 0.7]); 
set(gca,'Fontsize',16,'FontName','Times New Roman')
hold on

k1 = solveTrend(I2,colorstyle{1});
k2 = solveTrend(P2,colorstyle{2});

xlim([2015,2100])
xlabel('Time (year)','FontSize',30,'FontName','Times New Roman')
title('(b) 1000m','FontSize',28,'FontName','Times New Roman');

ax = gca;
ax.TitleHorizontalAlignment = 'left';
ax.TickDir = 'out';

xc = get(gca,'XColor');
yc = get(gca,'YColor');
unit = get(gca,'units');
ax = axes( 'Units', unit,...
    'Position',get(gca,'Position'),...
    'XAxisLocation','top',...
    'YAxisLocation','right',...
    'Color','none',...
    'XColor',xc,...
    'YColor',yc);
set(ax, 'linewidth',1,...
    'XTick', [],...
    'YTick', [],'Fontsize',12);
box on

%  (c)2000m
ax2 = subplot('Position', [0.69, 0.1, 0.3, 0.7]); 
set(gca,'Fontsize',16,'FontName','Times New Roman')
hold on

k1 = solveTrend(I3,colorstyle{1});
k2 = solveTrend(P3,colorstyle{2});

xlim([2015,2100])
xlabel('Time (year)','FontSize',30,'FontName','Times New Roman')
title('(c) 2000m','FontSize',28,'FontName','Times New Roman');

ax = gca;
ax.TitleHorizontalAlignment = 'left';
ax.TickDir = 'out';

xc = get(gca,'XColor');
yc = get(gca,'YColor');
unit = get(gca,'units');
ax = axes( 'Units', unit,...
    'Position',get(gca,'Position'),...
    'XAxisLocation','top',...
    'YAxisLocation','right',...
    'Color','none',...
    'XColor',xc,...
    'YColor',yc);
set(ax, 'linewidth',1,...
    'XTick', [],...
    'YTick', [],'Fontsize',12);
box on

%  legend
legend([k1,k2],{'Indian','Pacific'},'Position', [0.26, 0.87, 0.5, 0.1], 'Orientation', 'horizontal','FontSize',36,'FontName','Times New Roman');




function [w1,w2,w3] = solvew(mask,w,area)
[~,~,nt,~] = size(w);
S = sum(mask.*area,"all","omitmissing");
w1 = zeros([nt,1]);
w2 = zeros([nt,1]);
w3 = zeros([nt,1]);
for t = 1:nt
    T = sum(mask.*area.*w(:,:,t,1),"all","omitmissing");
    w1(t) = T/S;
    T = sum(mask.*area.*w(:,:,t,2),"all","omitmissing");
    w2(t) = T/S;
    T = sum(mask.*area.*w(:,:,t,3),"all","omitmissing");
    w3(t) = T/S;
end
end

function [k1] = solveTrend(data,colorstyle)
t = 2015:2100;
climatology = mean(data(1:10),"all");
anomaly = data-climatology;
p = polyfit(t,anomaly,1);
trend = polyval(p,t);
plot(t,anomaly,'--','Color',colorstyle,'LineWidth',2);
k1 = plot(t,trend,'Color',colorstyle,'LineWidth',3);
disp((trend(end)-trend(1)/86))
end