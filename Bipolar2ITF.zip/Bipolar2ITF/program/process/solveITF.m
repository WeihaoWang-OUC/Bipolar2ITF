function[T1,T2] = solveITF(dataname)
%% 确定作差位置
lonTarget1 = 106;
lonTarget2 = 123;
latTarget1 = 10;
latTarget2 = -20;

lonTarget3 = -173.36;
lonTarget4 = -165.39;
latTarget3 = 65.55;
latTarget4 = 65.35;


%% 读入数据
varname = 'msftbarot';
foldname = strcat('D:\Desktop\work\SO&ITF\data\',dataname,'\',varname);
addpath(foldname)

Files = dir(foldname);                                                      %用结构体读取文件夹中全部nc文件
msftbarot = [];                                                                %建立空矩阵
for i = 3:length(Files)                                                     %前两个为上下级，忽略掉向后两个读取
    name = Files(i).name;                                                   %读取nc文件名
    folder = Files(i).folder;                                               %读取文件夹名称
    cd(folder)                                                              %更改matlab路径
    data = ncread(name,varname);                                            %读取变量
    % data = permute(data,[2,1,3,4]);                                       %把矩阵转置和xy对应
    msftbarot = cat(3,msftbarot,data);
end

%  经纬度在高纬度非网格化，这里由于不涉及高纬度的计算，简单选取第一列和第一行将经纬度降维，再重新网格化
try
    x = ncread(name,'longitude');
    y = ncread(name,'latitude');
catch
    try
        x = ncread(name,'nav_lon');
        y = ncread(name,'nav_lat');
    catch
        x = ncread(name,'lon');
        y = ncread(name,'lat');
    end
end
if ~isempty(x>180)
    inx = x>180;
    x(inx) = x(inx)-360;
end

[nx,~,nt] = size(msftbarot);

%  读取正压流函数，注意流函数代表质量输运，需除以平均密度1025
Fai = msftbarot/1025*10^-6;


%% 计算作差
%  寻找距离目标点最近的点
if size(x,2)~=1
    [~,inx1] = min((x-lonTarget1).^2+(y-latTarget1).^2,[],"all");
    [i_inx1,j_inx1] = redir(inx1,nx);
    [~,inx2] = min((x-lonTarget2).^2+(y-latTarget2).^2,[],"all");
    [i_inx2,j_inx2] = redir(inx2,nx);
    [~,inx3] = min((x-lonTarget3).^2+(y-latTarget3).^2,[],"all");
    [i_inx3,j_inx3] = redir(inx3,nx);
    [~,inx4] = min((x-lonTarget4).^2+(y-latTarget4).^2,[],"all");
    [i_inx4,j_inx4] = redir(inx4,nx);
else
    [~,i_inx1] = min(abs(x-lonTarget1),[],"all");
    [~,j_inx1] = min(abs(y-latTarget1),[],"all");
    [~,i_inx2] = min(abs(x-lonTarget2),[],"all");
    [~,j_inx2] = min(abs(y-latTarget2),[],"all");
    [~,i_inx3] = min(abs(x-lonTarget1),[],"all");
    [~,j_inx3] = min(abs(y-latTarget1),[],"all");
    [~,i_inx4] = min(abs(x-lonTarget2),[],"all");
    [~,j_inx4] = min(abs(y-latTarget2),[],"all");
end

%  如果最近点为nan则向海洋方向推移一个
while isnan(Fai(i_inx1,j_inx1,1))
    j_inx1 = j_inx1-1;
end

while isnan(Fai(i_inx2,j_inx2,1))
    j_inx2 = j_inx2+1;
end

while isnan(Fai(i_inx3,j_inx3,1))
    j_inx3 = j_inx3-1;
end

while isnan(Fai(i_inx4,j_inx4,1))
    j_inx4 = j_inx4+1;
end

%  作差并降维
T1 = zeros([nt,1]);
T2 = zeros([nt,1]);
for t = 1:nt
    T1(t) = Fai(i_inx2,j_inx2,t)-Fai(i_inx1,j_inx1,t);
    T2(t) = Fai(i_inx4,j_inx4,t)-Fai(i_inx3,j_inx3,t);
end
if mean(T1,"all","omitmissing")<0
    T1 = -T1;
    T2 = -T2;
end
T1 = squeeze(T1);
T2 = squeeze(T2);
end

function [i,j] = redir(inx,nx)
j = ceil(inx/nx);
i = mod(inx,nx);
end