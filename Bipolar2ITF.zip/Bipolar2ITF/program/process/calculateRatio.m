clear
% modelname = 'NorESM2-LM';
modelname = 'ACCESS-CM2';
% modelname = 'CMCC-ESM2';
cd(strcat('D:\data\CMIP6\',modelname))

%% mask
cd .\basin
Files = dir(cd);
name = Files(3).name;
lon = ncread(name,"longitude");
lat = ncread(name,"latitude");
mask = ncread(name,"basin");
m_SO = mask== 1;
m_ATL = mask == 2;
m_PAC = mask == 3;
m_IND = mask == 5;

[nx,ny] = size(lon);
for i = 1:nx
    for j = 1:ny
        if lat(i,j)<=-30 && m_ATL(i,j)
            m_ATL(i,j) = 0;
            m_SO(i,j) = 1;
        end
        if lat(i,j)<=-30 && m_IND(i,j)
            m_IND(i,j) = 0;
            m_SO(i,j) = 1;
        end
        if lat(i,j)<=-30 && m_PAC(i,j)
            m_PAC(i,j) = 0;
            m_SO(i,j) = 1;
        end
    end
end

%% area
cd ..\areacello\
Files = dir(cd);
name = Files(3).name;
area = ncread(name,"areacello");

%% calculate
SO = sum(m_SO.*area,"all","omitmissing");
ATL = sum(m_ATL.*area,"all","omitmissing");
PAC = sum(m_PAC.*area,"all","omitmissing");
IND = sum(m_IND.*area,"all","omitmissing");

rIP = PAC/(IND+PAC);
rS = (IND+PAC)/ATL;
rN = (IND+PAC)/(SO+IND+PAC);