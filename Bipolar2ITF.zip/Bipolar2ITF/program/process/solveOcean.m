function[T] = solveOcean(dataname,lonRange,maxDepth)
% 读入并处理数据
[vo,dx,dz] = nc2data(dataname,lonRange,maxDepth);

%  网格厚度定义
[nx,~,nz,nt] = size(vo);
T = zeros([nt 1]);
for t = 1:nt
    dT = zeros([nx,nz]);
    for i = 1:nx
        for k = 1:nz
            if length(size(dz))==3
                dT(i,k) = vo(i,1,k,t).*dx(i).*dz(i,k,t).*10^-6;
            elseif size(dz,1)~=1
                dT(i,k) = vo(i,1,k,t).*dx(i).*dz(i,k).*10^-6;
            elseif size(dz,1)==1
                dT(i,k) = vo(i,1,k,t).*dx(i).*dz(k).*10^-6;
            end
        end
    end
    T(t) = sum(dT,"all",'omitNan');
end

%  流量需降维
T = squeeze(T);