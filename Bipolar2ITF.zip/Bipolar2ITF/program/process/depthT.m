clear
modelList = {'ACCESS-CM2','CESM2','CIESM','CMCC-ESM2','CanESM5-1','HadGEM3-GC31-MM','IPSL-CM6A-LR','NorESM2-MM','UKESM1-0-LL'};
t = 1:86;

for i =1:length(modelList)
    cd D:\Desktop\data\CMIP6\
    cd(modelList{i})
    differentOcean(modelList{i},"ATL")
    differentOcean(modelList{i},"IND")
    differentOcean(modelList{i},"PAC")
    disp(modelList{i})
end



function [] = differentOcean(model,ocean)
[T1,T2,T3] = dataProcess(model,ocean);
cd ..\
save(strcat('D:\Desktop\SO&ITF\data\',model,'\',ocean,'.mat'),"T1","T2","T3")
end

function [T1,T2,T3] = dataProcess(dataname,ocean)
if strcmp(ocean,"ATL")
    oceanRange = [-49.5,16.5];
elseif strcmp(ocean,"IND")
    oceanRange = [31.5,115.5];
elseif strcmp(ocean,"PAC")
    oceanRange = [153.5,287.5];
end
data1 = solveOcean(dataname,oceanRange,1000);
T1 = solveTrend(data1);
data2 = solveOcean(dataname,oceanRange,1500);
T2 = solveTrend(data2);
data3 = solveOcean(dataname,oceanRange,2000);
T3 = solveTrend(data3);
end

function [anom] = solveTrend(data)
T = zeros([length(data)/12,1]);
for t = 1:length(T)
    T(t) = mean(data(12*t-11:12*t),"all","omitmissing");
end
anom = T-mean(T(1:10));
end