function [vo,dx,dz] = nc2data(dataname,lonRange,maxDepth)
foldname = strcat('D:\Desktop\data\CMIP6\',dataname,'\vo');
Files = dir(foldname);                                                      %用结构体读取文件夹中全部nc文件
folder = Files.folder;
cd(folder)


%% 读入经纬度、深度
name = Files(3).name;
%  经纬度
try
    x = ncread(name,'longitude');
    y = ncread(name,'latitude');
catch
    try
        x = ncread(name,'nav_lon');
        y = ncread(name,'nav_lat');
    catch
        x = ncread(name,'lon');
        y = ncread(name,'lat');
    end
end

%  深度
try
    lev = ncread(name,'lev');
catch
    try
        lev = ncread(name,'depth');
    catch
        lev = ncread(name,'olevel');
    end
end

if lev(end)>=10000
    lev = lev./100;  %CESM2的深度单位为cm
end


%% 数据截取
%  找出范围
latTarget = -30;
depthRange = [0 maxDepth];

%  经纬度降维
if size(y,2)~=1
    [~,inx] = min(abs(y-latTarget),[],2);
    j_inx = inx(1);
    lat = y(1,j_inx);
    lon = zeros([size(x,1),1]);
    lon(:) = x(:,j_inx);
else
    [~,j_inx] = min(abs(y-latTarget),[],"all");
    lat = y(j_inx);
    lon = x;
end

clear x y

%  经度统一0到360
if any(lon<0)
    inx = lon<0;
    lon(inx) = lon(inx)+360;
end

%  如果范围跨0°则经度改为-180到180
if lonRange(1)<=0
    inx = lon>=180 & lon<=360;
    lon(inx) = lon(inx)-360;
end

%  截取
i_inx = find(lon>=lonRange(1) & lon<=lonRange(2));
k_inx = find(lev>=depthRange(1) & lev<=depthRange(2));

lon = lon(i_inx);


%% 数据调整顺序
%  因为经度数据不是按顺序排列的，所以需要将其从小到大排列
[~,inx] = sort(lon);
i_inx0 = i_inx;
for i = 1:length(inx)
    i_inx(i) = i_inx0(inx(i));
end


%% 读取流速
vo = [];
parfor i = 3:length(Files)                                                %前两个为上下级，忽略掉向后两个读取
    name = Files(i).name;                                                 %读取nc文件名
    data = readnc(name,'vo',i_inx,j_inx,k_inx);                        %读取变量
    data = permute(data,[1,4,3,2]);                                       %矩阵转置
    vo = [vo,data];
end
vo = permute(vo,[1,4,3,2]);


%% 读取边界和层厚
if exist('..\thkcello\','dir')==7

    %  读取边界并转化为dx
    foldname = strcat('D:\Desktop\data\CMIP6\',dataname,'\thkcello');
    Files = dir(foldname);
    folder = Files.folder;
    cd(folder)

    name = Files(3).name;
    try
        bnd = ncread(name,'vertices_longitude');
        dem = 4;
    catch
        try
            bnd = ncread(name,'bounds_nav_lon');
            dem = 4;
        catch
            bnd = ncread(name,'lon_bnds');
            dem = 2;
        end
    end
    if dem == 2
        dx(:) = bnd(2,:)-bnd(1,:);
    elseif dem == 4
        grid_lon = bnd(:,i_inx,j_inx);
        grid_lon = sort(grid_lon,1);
        dx(:) = grid_lon(end,:,:)-grid_lon(1,:,:);
        inx = find(dx>300);
        dx(inx) = abs(dx(inx)-360);
    end

    %  读取厚度
    thkcello = [];
    parfor i = 3:length(Files)                                                %前两个为上下级，忽略掉向后两个读取
        name = Files(i).name;                                                 %读取nc文件名
        data = readnc(name,'thkcello',i_inx,[j_inx,j_inx+1],k_inx);                        %读取变量
        data = permute(data,[1,4,3,2]);                                       %矩阵转置
        thkcello = [thkcello,data];
    end
    thkcello = permute(thkcello,[1,4,3,2]);
    dz = squeeze(min(thkcello,[],2));

elseif exist('..\thkcello\','dir')==0

    %  读取边界并转化为dx
    name = Files(3).name;
    try
        bnd = ncread(name,'lon_bnds');
    catch
        bnd = ncread(name,'vertices_longitude');
    end
    if ndims(bnd)==3
        grid_lon = bnd(:,i_inx,j_inx);
        grid_lon = sort(grid_lon,1);
        dx(:) = grid_lon(end,:,:)-grid_lon(1,:,:);
    else
        dx = bnd(2,:)-bnd(1,:);
    end
    inx = find(dx>300);
    dx(inx) = abs(dx(inx)-360);

    %  读取厚度
    bnd = ncread(name,'lev_bnds');
    h = bnd(:,k_inx);
    dz(:) = h(2,:)-h(1,:);
    dz = squeeze(dz);

end

dx = dx.*111*10^3.*cosd(lat);