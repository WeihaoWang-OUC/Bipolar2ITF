clear
modelList = {'CESM2','HadGEM3-GC31-LL','NorESM2-LM'};
t = 1:86;
data = [];

%% 读取数据
for i = 1:length(modelList)
    dataname = modelList{i};
    varname = 'msftmz';
    cd(strcat('D:\Desktop\work\SO&ITF\data\',dataname))
    if exist(".\msftmz\","dir")==7
        varname = 'msftmz';
    elseif exist(".\msftmz\","dir")==0
        varname = 'msftyz';
    end
    foldname = strcat('D:\Desktop\work\SO&ITF\data\',dataname,'\',varname);
    addpath(foldname)

    Files = dir(foldname);                                                      %用结构体读取文件夹中全部nc文件
    msftyz = [];                                                                %建立空矩阵
    for j = 3:length(Files)                                                     %前两个为上下级，忽略掉向后两个读取
        name = Files(j).name;                                                   %读取nc文件名
        folder = Files(j).folder;                                               %读取文件夹名称
        cd(folder)                                                              %更改matlab路径
        T = ncread(name,varname);                                            %读取变量
        T = squeeze(T);
        % data = permute(data,[2,1,3,4]);                                       %把矩阵转置和xy对应
        msftyz = cat(4,msftyz,T);
    end

    try
        lat = ncread(Files(3).name,'lat');
    catch
        try
            lat = ncread(Files(3).name,'rlat');
        catch
            lat = ncread(Files(3).name,'nav_lat');
        end
    end

    lev = ncread(Files(3).name,'lev');
    if lev(end)>=10000
        lev = lev./100;  %CESM2的深度单位为cm
    end

    try
        str = ncread(Files(3).name,'sector');
        for j = 1:size(str,2)
            if strcmpi(str(1,j),'g')
                sector = j;
            end
        end
    catch
        try
            str = ncread(Files(3).name,'basin');
            sector = 3;
        catch
            sector = 1;
        end
    end

    %  南大洋
    [~,j_inx] = min(abs(lat+31));
    fai = msftyz(j_inx,:,sector,:)./1025./10^6;
    fai = squeeze(fai);
    T = zeros([length(lev),t(end)]);
    for j = 1:t(end)
        T(:,j) = mean(fai(:,12*j-11:12*j),2,"omitmissing");            %年平均
    end
    [~,inx] = max(T,[],1,"omitmissing");                                            %寻找全深度流函数最大值作为AMOC强度
    depth = lev(inx);
    data = [data,depth];
    % anom = data-mean(data(1:10));
    % [p,S] = polyfit(t,anom,1);                                                  %数据线性拟合重构
    % [trend,error] = polyval(p,t,S);
    % SO(i) = trend(end)-trend(1);
end

plot(data)