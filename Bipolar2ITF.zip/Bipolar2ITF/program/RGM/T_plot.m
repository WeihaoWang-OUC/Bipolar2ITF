%% 读取数据
clear
cd D:\Desktop\work\SO&ITF\data\RGM
filename1 = "control.txt";
filename2 = "SO.txt";
filename3 = "NA.txt";
filename4 = "SO&NA.txt";
filename5 = "SO_linear.txt";
filename6 = "NA_linear.txt";
filename7 = "SO&NA_linear.txt";
control = load(filename1);
data_SO = load(filename2);
data_NA = load(filename3);
data_SO_NA = load(filename4);
data_SO_linear = load(filename5);
data_NA_linear = load(filename6);
data_SO_NA_linear = load(filename7);
varList = {"ATL","PAC","IND","ITF","hatl","hpac","hind"};
climatology = [11.1 12.4 -14.2 13.7 1227.24 1294.47 1298.52 788.78];
[n1,n2] = size(control);
t = (1:n1)/12;
cd ../../picture/RGM

%% 南大洋与ITF(SO)
len = 100*12;
data = data_SO;
c = (1:len)/12;
figure(1)
set(gcf,'color','white')
set(gcf,'position',[100,100,900,700])
clf
hold on
for i = 1:4
    varName = varList{i};
    eval(strcat(varName," = data(1:len,i)-climatology(i);"));
end
SO = ATL+PAC+IND;
s = scatter(ATL,ITF,50,c,"filled");
p1 = plot([0 1.5],-1.4794*[0 1.5],'k--','LineWidth',1.5);
b = colorbar;
colormap("turbo")
b.Label.String = 'Time(years)';
b.Label.FontSize = 36;
xlim([0 1.5])
ylim([-2 0.5]);
xlabel("SO transport anomaly(Sv)","FontSize",36)
ylabel("ITF transport anomaly(Sv)","FontSize",36)
grid on
% path = cd;
% saveas(gcf,strcat(path,'/SOvsITF.jpg'));
% close;

%% 贡献分解
len = 100*12;
data = data_SO_NA;
for i = [1,3]
    varName = varList{i};
    eval(strcat(varName," = data(1:len,i)-climatology(i);"));
end
A = [1,-1;0.6703,1.9672];
% A = [1,-1;0.6833,1.9672];
k = [0.4761;1.4793];
for n = 1:len
    b = [-ATL(n);IND(n)];
    x = A\b;
    frac(:,n) = -k(:).*x(:);
end
ITF = zeros([2,len]);
data = data_NA;
ITF(1,:) = data(1:len,4)-climatology(4);
data = data_SO;
ITF(2,:) = data(1:len,4)-climatology(4);
ratio = frac./ITF;
% s = ratio(1,:)./ratio(2,:);
figure(1)
set(gcf,'color','white')
set(gcf,'position',[100,100,1000,900])
clf
set(gca,'Fontsize',24)
hold on
grid on
box on

p1 = plot(t(1:len),ratio(1,:),"LineWidth",2);
p2 = plot(t(1:len),ratio(2,:),"LineWidth",2);
% p3 = plot(t(1:len),mean(ratio,1),"LineWidth",2);
k = plot([0 len],[1 1],'k--','LineWidth',1.5);
xlim([10 t(len)])
% ylim([0,5])
legend({'North Atlantic','Southern Ocean',''},'FontSize',24)
xlabel('Time(year)','FontSize',36)
ylabel('Normalized ITF change','FontSize',36)

% path = cd;
% saveas(gcf,strcat(path,'/contribution.jpg'));
% close;

%% NA试验大西洋和印度洋厚度对比
len = 100*12;
data = data_NA;
c = (1:len)/12;
figure(1)
set(gcf,'color','white')
set(gcf,'position',[100,100,900,700])
clf
set(gcf,'color','white');
hold on
for i = 1:4
    varName = varList{i};
    eval(strcat(varName," = data(1:len,i+4)-climatology(i+4);"));
end
SO = ITF;
s = scatter(IND,ATL,50,c,"filled");
b = colorbar;
colormap("turbo")
b.Label.String = 'Time(years)';
b.Label.FontSize = 36;
% xlim([0,45])
% ylim([0,45])
% plot([0,45],[0,45],'k--','LineWidth',1.5)
xlabel("Indian depth anomaly(m)","FontSize",36)
ylabel("Atlantic depth anomaly(m)","FontSize",36)
grid on
% path = cd;
% saveas(gcf,strcat(path,'/INDvsPAC.jpg'));
% close;

%% SO试验厚度对比
len = 100*12;
data = data_SO;
c = (1:len)/12;
figure(1)
set(gcf,'color','white')
set(gcf,'position',[100,100,900,700])
clf
set(gcf,'color','white');
hold on
for i = 1:3
    varName = varList{i};
    eval(strcat(varName," = data(1:len,i+4)-climatology(i+4);"));
end
s = scatter(IND,ATL,50,c,"filled");
b = colorbar;
colormap("turbo")
b.Label.String = 'Time(years)';
b.Label.FontSize = 36;
xlim([0,45])
ylim([0,60])
plot([0,45],[8.5,53.5],'k--','LineWidth',1.5)
xlabel("Indian depth anomaly(m)","FontSize",36)
ylabel("Atlantic depth anomaly(m)","FontSize",36)
grid on
path = cd;
saveas(gcf,strcat(path,'/INDvsATL.jpg'));
close;

%% 厚度对比
len = 100*12;
data = data_SO;
colorstyle = {"#0072BD","#A2142F","#EDB120","#7E2F8E","#77AC30"};

figure(1)
set(gcf,'color','white')
set(gcf,'position',[100,100,900,700])
clf
set(gcf,'color','white');
hold on
for i = 1:4
    varName = varList{i};
    eval(strcat(varName," = data(1:len,i+4)-climatology(i+4);"));
    eval(strcat("p",num2str(i)," = plot(t(1:len),",varName,",'color','",colorstyle{i},"','lineWidth',2);")) ;
end
xlim([0,100])
% ylim([0,60])
% plot([0,45],[0,45],'k--','LineWidth',1.5)
xlabel("Indian depth anomaly(m)","FontSize",36)
ylabel("Pacific depth anomaly(m)","FontSize",36)
grid on
% path = cd;
% saveas(gcf,strcat(path,'/INDvsPAC.jpg'));
% close;

%% SO试验大西洋与印度洋输运对比
len = 100*12;
data = data_SO;
c = (1:len)/12;
figure(1)
set(gcf,'color','white')
set(gcf,'position',[100,100,1200,1000])
clf
set(gcf,'color','white');
hold on
for i = 1:4
    varName = varList{i};
    eval(strcat(varName," = data(1:len,i)-climatology(i);"));
end
SO = ATL+IND+PAC;
s = scatter(ATL,0.61*IND,50,c,"filled");
b = colorbar;
colormap("turbo")
b.Label.String = 'Time(years)';
b.Label.FontSize = 36;
% ylim([0,2.5])
% xlim([0,1.2])
% plot([0,1.2],1.9672*[0,1.2],'k--','LineWidth',1.5)
xlabel("Atlantic transport anomaly(Sv)","FontSize",36)
ylabel("Indian transport anomaly(Sv)","FontSize",36)
grid on
% path = cd;
% saveas(gcf,strcat(path,'/INDvsATLinSO.jpg'));
% close;

%% SO试验大西洋与印度洋输运对比
len = 100*12;
data = data_SO;
figure(1)
set(gcf,'color','white')
set(gcf,'position',[100,100,1200,1000])
clf
set(gcf,'color','white');
hold on
for i = 1:4
    varName = varList{i};
    eval(strcat(varName," = data(1:len,i)-climatology(i);"));
end
SO = ATL+IND+PAC;
p1 = plot(t(1:len),IND./ATL,'LineWidth',2);
p2 = plot([0 t(len)],[1.9672 1.9672],'k--','LineWidth',1.5);
% ylim([0,2.5])
xlim([1,t(len)])
% plot([0,1.2],1.9672*[0,1.2],'k--','LineWidth',1.5)
xlabel("Atlantic transport anomaly(Sv)","FontSize",36)
ylabel("Indian transport anomaly(Sv)","FontSize",36)
grid on
% path = cd;
% saveas(gcf,strcat(path,'/INDvsATLinSO.jpg'));
% close;

%% NA试验大西洋与印度洋输运对比
len = 100*12;
data = data_NA;
c = (1:len)/12;
figure(1)
set(gcf,'color','white')
set(gcf,'position',[100,100,1200,1000])
clf
set(gcf,'color','white');
hold on
for i = 1:4
    varName = varList{i};
    eval(strcat(varName," = data(1:len,i)-climatology(i);"));
end
s = scatter(ATL,IND,50,c,"filled");
b = colorbar;
colormap("turbo")
b.Label.String = 'Time(years)';
b.Label.FontSize = 36;
ylim([0,2.5])
xlim([-3.5,0])
plot([-3.5,0],-0.6703*[-3.5,0],'k--','LineWidth',1.5)
xlabel("Atlantic transport anomaly(Sv)","FontSize",36)
ylabel("Indian transport anomaly(Sv)","FontSize",36)
grid on
path = cd;
saveas(gcf,strcat(path,'/INDvsATLinNA.jpg'));
close;

%% NA试验大西洋与印度洋输运对比
len = 100*12;
data = data_NA;
figure(1)
set(gcf,'color','white')
set(gcf,'position',[100,100,1200,1000])
clf
set(gcf,'color','white');
hold on
for i = 1:4
    varName = varList{i};
    eval(strcat(varName," = data(1:len,i)-climatology(i);"));
end
SO = ATL+IND+PAC;
p1 = plot(t(1:len),IND./ATL,'LineWidth',2);
p2 = plot([0 t(len)],[-0.6703 -0.6703],'k--','LineWidth',1.5);
% ylim([0,2.5])
xlim([1,t(len)])
% plot([0,1.2],1.9672*[0,1.2],'k--','LineWidth',1.5)
xlabel("Atlantic transport anomaly(Sv)","FontSize",36)
ylabel("Indian transport anomaly(Sv)","FontSize",36)
grid on
box on
% path = cd;
% saveas(gcf,strcat(path,'/INDvsATLinNA.jpg'));
% close;

%%
len = 100*12;
data = data_SO;
c = (1:len)/12;
% figure(1)
% set(gcf,'color','white')
% set(gcf,'position',[100,100,1200,1000])
% clf
% set(gcf,'color','white');
% hold on
for i = 1:4
    varName = varList{i};
    eval(strcat(varName," = data(1:len,i)-climatology(i);"));
end
SO = ATL+IND+PAC;
V_atl = sum(ATL*30*24*3600)*10^6;
V_ip = sum(IND*30*24*3600)*10^6;
h_atl = V_atl/6.1684*10^-13;
h_ip = V_ip/1.2135*10^-14;

%% 厚度对比
len = 100*12;
data = data_SO;
c = (1:len)/12;
figure(1)
set(gcf,'color','white')
set(gcf,'position',[100,100,900,700])
clf
set(gcf,'color','white');
hold on
for i = 1:3
    varName = varList{i};
    eval(strcat(varName," = data(1:len,i)-climatology(i);"));
    eval(strcat("h_",varName," = data(1:len,i+4)-climatology(i+4);"));
end
S_atl = 6.1684*10^13;
S_ip = 1.2135*10^14;
A = [0;diff(h_ATL,1,1)-diff(h_IND,1,1)]/30/24/3600;
% A = zeros(size(ATL));
T = S_atl/S_ip*IND+S_atl*A/10^6;
% s = scatter(ATL,T,50,c,"filled");
s = scatter(ATL./IND,[0;diff(h_ATL,1,1)./diff(h_IND,1,1)],50,c,"filled");
b = colorbar;
colormap("turbo")
b.Label.String = 'Time(years)';
b.Label.FontSize = 36;
% xlim([1 10])
% ylim([-1.5 -1])

%% 比例随时间变化
len = 100*12;
colorList = {"#0072BD",	"#D95319"};
data = data_NA;
for i = 1:3
    varName = varList{i};
    eval(strcat(varName," = data(1:len,i)-climatology(i);"));
end
r1 = IND./ATL;

data = data_SO;
for i = 1:3
    varName = varList{i};
    eval(strcat(varName," = data(1:len,i)-climatology(i);"));
end
r2 = IND./ATL;

figure(1)
set(gcf,'color','white')
set(gcf,'position',[100,100,1200,1000])
clf
set(gcf,'color','white');
set(gca,'Fontsize',24)
hold on
grid on
box on

p1 = plot(t(1:len),r1,'Color',colorList{1},'LineWidth',2);
k1 = plot([0 t(len)],[-0.6703 -0.6703],'--','Color',colorList{1},'LineWidth',1.5);
p2 = plot(t(1:len),r2,'Color',colorList{2},'LineWidth',2);
k2 = plot([0 t(len)],[1.9672 1.9672],'--','Color',colorList{2},'LineWidth',1.5);
% ylim([0,2.5])
xlim([1,t(len)])
% plot([0,1.2],1.9672*[0,1.2],'k--','LineWidth',1.5)
xlabel("Time(year)","FontSize",36)
ylabel("Transport ratio","FontSize",36)
legend({'North Atlantic','','Southern Ocean',''},'FontSize',24)

path = cd;
saveas(gcf,strcat(path,'/Ratio.jpg'));
close;

%% SO试验各大洋等密面厚度随时间变化
len = 100*12;
data = data_SO;
colorList = {"#0072BD",	"#D95319","#EDB120","#7E2F8E"};
for i = 1:3
    varName = varList{i};
    eval(strcat(varName," = diff(data(1:len,i+4)/3600/24/30,1,1);"));
end
SO = diff(data(1:len,8)/3600/24/30,1,1);

figure(1)
set(gcf,'color','white')
set(gcf,'position',[100,100,1200,1000])
clf
set(gcf,'color','white');
set(gca,'Fontsize',24)
hold on
grid on
box on

p1 = plot(t(2:len),ATL,'Color',colorList{1},'LineWidth',2);
p2 = plot(t(2:len),IND,'Color',colorList{2},'LineWidth',2);
p3 = plot(t(2:len),PAC,'Color',colorList{3},'LineWidth',2);
p4 = plot(t(2:len),SO,'Color',colorList{4},'LineWidth',2);
xlim([1,t(len)])
xlabel("Time(year)","FontSize",36)
ylabel("Interface depth tendency(m/s)","FontSize",36)
legend({'Atlantic','Indian','Pacific','SO'},'FontSize',24,'Location','northeast')

% path = cd;
% saveas(gcf,strcat(path,'/difference.jpg'));
% close;

%% 分解合理性
len = 100*12;
dSO = data_SO;
dNA = data_NA;
data = data_SO_NA;
colorstyle = {"#0072BD","#A2142F","#EDB120","#7E2F8E","#77AC30"};
dT = 0;
T = 0;

figure(1)
set(gcf,'color','white')
set(gcf,'position',[100,100,1200,1000])
clf
set(gcf,'color','white');
set(gca,'Fontsize',24)
hold on
box on
grid on

for i = 1:4
    varName = varList{i};
    eval(strcat(varName," = (dSO(1:len,i)+dNA(1:len,i)-2*climatology(i))./(data(1:len,i)-climatology(i));"));
    eval(strcat("p",num2str(i)," = plot(t(1:len),",varName,",'color','",colorstyle{i},"','lineWidth',2);")) ;
    if i ~= 4
        dT = dT+dSO(1:len,i)+dNA(1:len,i)-2*climatology(i);
        T = T+data(1:len,i)-climatology(i);
    end
end
SO = dT./T;
p5 = plot(t(1:len),SO(1:len),'Color',colorstyle{5},'LineWidth',1.5);
legend({'Atlantic','Pacific','Indian','ITF','SO'},'FontSize',16,'Location','northeast')
xlim([10 t(len)])
% ylim([0.7 1])
xlabel("Time(year)","FontSize",36)
ylabel("Normalized transport response","FontSize",36)

%% SO试验厚度对比
len = 100*12;
data = data_SO;
c = (1:len)/12;
figure(1)
set(gcf,'color','white')
set(gcf,'position',[100,100,900,700])
clf
set(gcf,'color','white');
hold on
for i = 1:3
    varName = varList{i};
    eval(strcat(varName," = data(1:len,i+4)-climatology(i+4);"));
end
s = scatter(IND,ATL,50,c,"filled");
b = colorbar;
colormap("turbo")
b.Label.String = 'Time(years)';
b.Label.FontSize = 36;
xlim([0,45])
ylim([0,60])
plot([0,45],[8.5,53.5],'k--','LineWidth',1.5)
xlabel("Indian depth anomaly(m)","FontSize",36)
ylabel("Atlantic depth anomaly(m)","FontSize",36)
grid on
path = cd;
saveas(gcf,strcat(path,'/INDvsATL.jpg'));
close;

%% SO试验厚度趋势对比体积输运
len = 100*12;
data = data_SO;
c = (1:len)/12;
figure(1)
set(gcf,'color','white')
set(gcf,'position',[100,100,900,700])
clf
set(gcf,'color','white');
hold on
for i = 1:3
    varName = varList{i};
    eval(strcat(varName," = data(1:len,i)-climatology(i);"));
end
Tso = ATL+IND+PAC;
hso = [0;diff(data(1:len,8)/3600/24/30,1,1)];
s = scatter(Tso,hso,50,c,"filled");
b = colorbar;
colormap("turbo")
b.Label.String = 'Time(years)';
b.Label.FontSize = 36;
% xlim([0,45])
% ylim([0,60])
% plot([0,45],[8.5,53.5],'k--','LineWidth',1.5)
xlabel("Transport(Sv)","FontSize",36)
ylabel("Interface depth tendency(m/s)","FontSize",36)
grid on
% path = cd;
% saveas(gcf,strcat(path,'/INDvsATL.jpg'));
% close;