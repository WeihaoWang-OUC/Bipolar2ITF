clear
figure(1)
clf
set(gcf,'color','white')
set(gcf,'position',[100,100,2000,1000])
set(gcf, 'DefaultTextFontName', 'Times New Roman');
colorstyle = {"#B9181A","#FABB6E","#369F2D","#614099","#4995C6"};

%% 读取数据
cd D:\Desktop\work\SO&ITF\data\RGM
filename1 = "control.txt";
filename2 = "SO_linear.txt";
filename3 = "NA_linear.txt";
filename4 = "SO&NA_linear.txt";
control = load(filename1);
data_SO = load(filename2);
data_NA = load(filename3);
data_SO_NA = load(filename4);
varList = {"ATL","PAC","IND","ITF","hatl","hpac","hind"};
climatology = [11.1 12.4 -14.2 13.7 1227.24 1294.47 1298.52 788.78];
[n1,n2] = size(control);
t = (1:1200)/12;

len = 100*12;
dSO = data_SO;
dNA = data_NA;
data = data_SO_NA;

for i = 1:4
    varName = varList{i};
    eval(strcat(varName," = dSO(1:len,i)+dNA(1:len,i)-dSO(1,i)-dNA(1,i);"));
    eval(strcat(varName,"_NS = data(1:len,i)-data(1,i);"));
end

%% (a)
ax1 = subplot('Position', [0.05, 0.1, 0.4, 0.8]);
set(gca,'Fontsize',16,'FontName','Times New Roman')
hold on

scatter(ATL,ATL_NS,50,t,"filled")
plot([-2,0.1],[-2,0.1],'k--','LineWidth',1.5)

ax1.TickDir = 'out';
xlim([-1.9 0.1])
ylim([-1.9 0.1])
xlabel('$\delta T_{\rm ATL}^{\rm N}+\delta T_{\rm ATL}^{\rm S}$ (Sv)','FontSize',30,'FontName','Times New Roman','Interpreter','latex')
ylabel('$\delta T_{\rm ATL}$ (Sv)','FontSize',30,'FontName','Times New Roman','Interpreter','latex')
title('(a) Atlantic transport response','FontSize',28,'FontName','Times New Roman')
ax = gca;
ax.TitleHorizontalAlignment = 'left';

xc = get(gca,'XColor');
yc = get(gca,'YColor');
unit = get(gca,'units');
ax = axes( 'Units', unit,...
'Position',get(gca,'Position'),...
'XAxisLocation','top',...
'YAxisLocation','right',...
'Color','none',...
'XColor',xc,...
'YColor',yc);
set(ax, 'linewidth',1,...
'XTick', [],...
'YTick', [],'Fontsize',12);
box on

%% (b)
ax2 = subplot('Position', [0.525, 0.1, 0.4, 0.8]);
set(gca,'Fontsize',16,'FontName','Times New Roman')
hold on

scatter(ITF,ITF_NS,50,t,"filled")
plot([-3,0.5],[-3,0.5],'k--','LineWidth',1.5)

ax2.TickDir = 'out';
xlim([-3 0.1])
ylim([-3 0.1])
xlabel('$\delta T_{\rm ITF}^{\rm N}+\delta T_{\rm ITF}^{\rm S}$ (Sv)','FontSize',30,'FontName','Times New Roman','Interpreter','latex')
ylabel('$\delta T_{\rm ITF}$ (Sv)','FontSize',30,'FontName','Times New Roman','Interpreter','latex')
title('(b) ITF transport response','FontSize',28,'FontName','Times New Roman')
ax = gca;
ax.TitleHorizontalAlignment = 'left';

xc = get(gca,'XColor');
yc = get(gca,'YColor');
unit = get(gca,'units');
ax = axes( 'Units', unit,...
'Position',get(gca,'Position'),...
'XAxisLocation','top',...
'YAxisLocation','right',...
'Color','none',...
'XColor',xc,...
'YColor',yc);
set(ax, 'linewidth',1,...
'XTick', [],...
'YTick', [],'Fontsize',12);
box on

%% colorbar
h = colorbar;
set(h, 'Position', [0.945 0.1 0.014 0.8]);
h.Label.String = 'Time (year)';
h.Label.FontSize = 30;
h.Label.FontName = 'Times New Roman';
h.Ticks = 0:0.2:1;
h.TickLabels = 0:20:100;

%% 保存
cd ../../picture/RGM
path = cd;
exportgraphics(gcf, strcat(path,'\sumUpCompare.jpg'));
close;