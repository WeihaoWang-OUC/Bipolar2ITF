clear
figure(1)
clf
set(gcf,'color','white')
set(gcf,'position',[-1000,100,3000,1000])
set(gcf, 'DefaultTextFontName', 'Times New Roman');
colorstyle = {"#B9181A","#FABB6E","#369F2D","#4995C6"};

%% 读取数据
cd D:\Desktop\work\SO&ITF\data\RGM
filename1 = "control.txt";
filename2 = "SO_linear.txt";
filename3 = "NA_linear.txt";
filename4 = "SO&NA_linear.txt";
control = load(filename1);
data_SO = load(filename2);
data_NA = load(filename3);
data_SO_NA = load(filename4);
varList = {"ATL","PAC","IND","ITF","hatl","hpac","hind"};
climatology = [11.1 12.4 -14.2 13.7 1227.24 1294.47 1298.52 788.78];
[n1,n2] = size(control);
t = (1:1200)/12;
len = 100*12;

%% (a)
data = data_NA;
ax1 = subplot('Position', [0.04, 0.1, 0.28, 0.7]);
set(gca,'Fontsize',16,'FontName','Times New Roman')
hold on

for i = 1:3
    varName = varList{i};
    eval(strcat(varName," = diff(data(1:len,i+4)/3600/24/30*10^8,1,1);"));
end
SO = diff(data(1:len,8)/3600/24/30*10^8,1,1);
p1 = plot(t(2:len),ATL,'Color',colorstyle{1},'LineWidth',2);
p2 = plot(t(2:len),IND,'Color',colorstyle{2},'LineWidth',2);
p3 = plot(t(2:len),PAC,'Color',colorstyle{3},'LineWidth',2);
p4 = plot(t(2:len),SO,'Color',colorstyle{4},'LineWidth',2);
xlim([0,t(len)])
xlabel("Time (year)","FontSize",30,'FontName','Times New Roman')
ylabel("Interface depth tendency (10^{-8}m/s)","FontSize",30,'FontName','Times New Roman')

ax1.TickDir = 'out';
title('(a) NADW perturbation','FontSize',20,'FontName','Times New Roman')
ax = gca;
ax.TitleHorizontalAlignment = 'left';

xc = get(gca,'XColor');
yc = get(gca,'YColor');
unit = get(gca,'units');
ax = axes( 'Units', unit,...
'Position',get(gca,'Position'),...
'XAxisLocation','top',...
'YAxisLocation','right',...
'Color','none',...
'XColor',xc,...
'YColor',yc);
set(ax, 'linewidth',1,...
'XTick', [],...
'YTick', [],'Fontsize',12);
box on

%% (b)
data = data_SO;
ax2 = subplot('Position', [0.36, 0.1, 0.28, 0.7]);
set(gca,'Fontsize',16,'FontName','Times New Roman')
hold on

for i = 1:3
    varName = varList{i};
    eval(strcat(varName," = diff(data(1:len,i+4)/3600/24/30*10^8,1,1);"));
end
SO = diff(data(1:len,8)/3600/24/30*10^8,1,1);
p1 = plot(t(2:len),ATL,'Color',colorstyle{1},'LineWidth',2);
p2 = plot(t(2:len),IND,'Color',colorstyle{2},'LineWidth',2);
p3 = plot(t(2:len),PAC,'Color',colorstyle{3},'LineWidth',2);
p4 = plot(t(2:len),SO,'Color',colorstyle{4},'LineWidth',2);
xlim([0,t(len)])
xlabel("Time (year)","FontSize",30,'FontName','Times New Roman')

ax2.TickDir = 'out';
title('(b) SH westerly perturbation','FontSize',20,'FontName','Times New Roman')
ax = gca;
ax.TitleHorizontalAlignment = 'left';

xc = get(gca,'XColor');
yc = get(gca,'YColor');
unit = get(gca,'units');
ax = axes( 'Units', unit,...
'Position',get(gca,'Position'),...
'XAxisLocation','top',...
'YAxisLocation','right',...
'Color','none',...
'XColor',xc,...
'YColor',yc);
set(ax, 'linewidth',1,...
'XTick', [],...
'YTick', [],'Fontsize',12);
box on

%% (c)
data = data_SO_NA;
ax3 = subplot('Position', [0.68, 0.1, 0.28, 0.7]);
set(gca,'Fontsize',16,'FontName','Times New Roman')
hold on

for i = 1:3
    varName = varList{i};
    eval(strcat(varName," = diff(data(1:len,i+4)/3600/24/30*10^8,1,1);"));
end
SO = diff(data(1:len,8)/3600/24/30*10^8,1,1);
p1 = plot(t(2:len),ATL,'Color',colorstyle{1},'LineWidth',2);
p2 = plot(t(2:len),IND,'Color',colorstyle{2},'LineWidth',2);
p3 = plot(t(2:len),PAC,'Color',colorstyle{3},'LineWidth',2);
p4 = plot(t(2:len),SO,'Color',colorstyle{4},'LineWidth',2);
xlim([0,t(len)])
xlabel("Time (year)","FontSize",30,'FontName','Times New Roman')

ax3.TickDir = 'out';
title('(c) Bipolar perturbation','FontSize',20,'FontName','Times New Roman')
ax = gca;
ax.TitleHorizontalAlignment = 'left';

xc = get(gca,'XColor');
yc = get(gca,'YColor');
unit = get(gca,'units');
ax = axes( 'Units', unit,...
'Position',get(gca,'Position'),...
'XAxisLocation','top',...
'YAxisLocation','right',...
'Color','none',...
'XColor',xc,...
'YColor',yc);
set(ax, 'linewidth',1,...
'XTick', [],...
'YTick', [],'Fontsize',12);
box on

%% legend
legend([p1,p2,p3,p4],{'Atlantic','Pacific','Indian','SO'},'Position', [0.24, 0.84, 0.48, 0.1], 'Orientation', 'horizontal','FontSize',36,'FontName','Times New Roman')

%% 保存
cd ../../picture/RGM
path = cd;
exportgraphics(gcf, strcat(path,'\deepeningRate.jpg'));
close;