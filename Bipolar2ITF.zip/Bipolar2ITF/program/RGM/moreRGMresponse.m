%% 读取数据
clear
cd C:\Users\admin\Desktop\SO&ITF\data\RGM
filename1 = "control.txt";
filename2 = "SO.txt";
filename5 = "SO_linear.txt";
control = load(filename1);
data_SO = load(filename2);
data_SO_linear = load(filename5);
varList = {"ATL","PAC","IND","ITF","hatl","hpac","hind"};
climatology = [11.1 12.4 -14.2 13.7 1227.24 1294.47 1298.52 788.78];
[n1,n2] = size(control);
t = (1:n1)/12;
len = 100*12;

cd ../../picture/RGM
figure(1)
clf
set(gcf,'color','white')
set(gcf,'position',[100,100,2000,1000])
set(gcf, 'DefaultTextFontName', 'Times New Roman');

%% (a)体积输运
data = data_SO;
len = 100*12;
colorstyle = {"#B9181A","#FABB6E","#369F2D","#4995C6"};

ax1 = subplot('Position', [0.05, 0.15, 0.43, 0.7]);
set(gca,'Fontsize',16,'FontName','Times New Roman')
hold on

for i = 1:3
    varName = varList{i};
    eval(strcat(varName," = diff(data(1:len,i+4)/3600/24/30*10^7,1,1);"));
end
SO = diff(data(1:len,8)/3600/24/30*10^7,1,1);
p1 = plot(t(2:len),ATL,'Color',colorstyle{1},'LineWidth',2);
p2 = plot(t(2:len),IND,'Color',colorstyle{2},'LineWidth',2);
p3 = plot(t(2:len),PAC,'Color',colorstyle{3},'LineWidth',2);
p4 = plot(t(2:len),SO,'Color',colorstyle{4},'LineWidth',2);
xlim([0,t(len)])
xlabel("Time (year)","FontSize",30,'FontName','Times New Roman')
ylabel("Interface depth tendency (10^{-7}m/s)","FontSize",30,'FontName','Times New Roman')
legend([p1,p3,p2,p4],{'Atlantic','Indian','Pacific','SO'},'FontSize',28,'Location','northeast','FontName','Times New Roman')
ax1.TickDir = 'out';
title('(a)','FontSize',28,'FontName','Times New Roman')
ax = gca;
ax.TitleHorizontalAlignment = 'left';

R = 6371*10^3;
S_ATL = R^2*pi/3*(sind(62)+sind(30));
S_IND = R^2*pi/3*(sind(12)+sind(30));
S_PAC = R^2*5*pi/9*(sind(52)+sind(30));
S_SO = R^2*11*pi/9*(sind(61)-sind(31));

T_ATL = ATL*S_ATL/10^6/10^7;
T_IND = IND*S_IND/10^6/10^7;
T_PAC = PAC*S_PAC/10^6/10^7;
T_SO = SO*S_SO/10^6/10^7;

xc = get(gca,'XColor');
yc = get(gca,'YColor');
unit = get(gca,'units');
ax = axes( 'Units', unit,...
'Position',get(gca,'Position'),...
'XAxisLocation','top',...
'YAxisLocation','right',...
'Color','none',...
'XColor',xc,...
'YColor',yc);
set(ax, 'linewidth',1,...
'XTick', [],...
'YTick', [],'Fontsize',12);
box on

%% (b)比例
data = data_SO;
len = 100*12;
r1 = 0.5083;
r2 = 0.7479;
colorstyle = {"#3E608D","#CB9475"};

ax2 = subplot('Position', [0.55, 0.15, 0.43, 0.7]);
set(gca,'Fontsize',16,'FontName','Times New Roman')
hold on

for i = 1:4
    varName = varList{i};
    eval(strcat(varName," = data(1:len,i)-climatology(i);"));
end
p1 = plot(t(1:len),ATL./IND,'Color',colorstyle{1},'LineWidth',2.5);
p2 = plot(t(1:len),-ITF./IND,'Color',colorstyle{2},'LineWidth',2.5);
l1 = plot(t(1:len),r1*ones([1,len]),'--','color',colorstyle{1},'LineWidth',2);
l2 = plot(t(1:len),r2*ones([1,len]),'--','color',colorstyle{2},'LineWidth',2);
legend([p1 p2],{"$\delta\textit{T}_\mathrm{A}^\mathrm{\hspace{2pt}S}\hspace{2pt}/\hspace{2pt}\delta\textit{T}_\mathrm{I}^\mathrm{\hspace{2pt}S}$","$-\delta\textit{T}_\mathrm{ITF}^\mathrm{\hspace{2pt}S}\hspace{2pt}/\hspace{2pt}\delta\textit{T}_\mathrm{I}^\mathrm{\hspace{2pt}S}$"},'Fontsize',28,'Interpreter','latex')
xlim([0 t(len)])
xlabel("Time (year)","FontSize",30,'FontName','Times New Roman')
ylabel("Transport ratio","FontSize",30,'FontName','Times New Roman')
ax = gca;
ax.TickDir = 'out';

title('(b)','FontSize',28,'FontName','Times New Roman')
ax = gca;
ax.TitleHorizontalAlignment = 'left';

xc = get(gca,'XColor');
yc = get(gca,'YColor');
unit = get(gca,'units');
ax = axes( 'Units', unit,...
'Position',get(gca,'Position'),...
'XAxisLocation','top',...
'YAxisLocation','right',...
'Color','none',...
'XColor',xc,...
'YColor',yc);
set(ax, 'linewidth',1,...
'XTick', [],...
'YTick', [],'Fontsize',12);
box on

%% 保存
% path = cd;
% exportgraphics(gcf, strcat(path,'\moreRGMresponse.jpg'));
% close;