clear
cd C:\Users\admin\Desktop\SO&ITF\data\RGM
filename1 = "control.txt";
filename2 = "NA.txt";
control = load(filename1);
data_NA = load(filename2);
varList = {"ATL","PAC","IND","ITF","hatl","hpac","hind"};
[n1,n2] = size(control);
t = (1:n1)/12;
colorstyle = {"#DCA7EB","#E29135"};

figure(1)
clf
set(gcf,'color','white')
set(gcf,'position',[-1200,-200,1200,2000])
set(gcf, 'DefaultTextFontName', 'Times New Roman');
set(gca,'Fontsize',16,'FontName','Times New Roman')
hold on

%% (a)plot
ax1 = subplot('Position', [0.1, 0.565, 0.8, 0.25]);
set(gca,'Fontsize',16,'FontName','Times New Roman')
hold on

len = 1200;
data = data_NA;
r1 = 0.80;
r2 = 0.6703;
for i = 1:4
    varName = varList{i};
    eval(strcat(varName," = data(1:len,i)-data(1,i);"));
end
p = plot(t(1:len),-IND./ATL,'Color',"#474769",'LineWidth',3);
l1 = plot([t(1) t(len)],[r1 r1],'--','color',colorstyle{1},'LineWidth',2.5);
l2 = plot([t(1) t(len)],[r2 r2],'--','color',colorstyle{2},'LineWidth',2.5);
xlim([0 t(len)])
xlabel("Time (year)","FontSize",30,'FontName','Times New Roman')
ylabel("Transport ratio","FontSize",30,'FontName','Times New Roman')
title('(a)','FontSize',28,'FontName','Times New Roman')
ax = gca;
ax.TickDir = 'out';
ax.TitleHorizontalAlignment = 'left';

xc = get(gca,'XColor');
yc = get(gca,'YColor');
unit = get(gca,'units');
ax = axes( 'Units', unit,...
'Position',get(gca,'Position'),...
'XAxisLocation','top',...
'YAxisLocation','right',...
'Color','none',...
'XColor',xc,...
'YColor',yc);
set(ax, 'linewidth',1,...
'XTick', [],...
'YTick', [],'Fontsize',12);
box on

%% (b)scatter
ax2 = subplot('Position', [0.1, 0.05, 0.75, 0.45]);
set(gca,'Fontsize',16,'FontName','Times New Roman')
hold on

len = 1200;
data = data_NA;
r1 = -0.80;
r2 = -0.67;
t = (1:1200)/12;
for i = 1:4
    varName = varList{i};
    eval(strcat(varName," = data(1:len,i)-data(1,i);"));
end
scatter(ATL,IND,50,t,"filled")
h = colorbar;
set(h, 'Position', [0.885 0.05 0.015 0.45]);
h.Label.String = 'Time (year)';
h.Label.FontSize = 30;
h.Label.FontName = 'Times New Roman';
h.Ticks = 0:20:100;
h.TickLabels = 0:20:100;

l1 = plot([-3.1 0.1],r1*[-3.1 0.1],'--','color',colorstyle{1},'LineWidth',2.5);
l2 = plot([-3.1 0.1],r2*[-3.1 0.1],'--','color',colorstyle{2},'LineWidth',2.5);
xlim([-3.1 0.1])
ylim([-0.1 2.3])
xlabel("Atlantic response (Sv)","FontSize",30,'FontName','Times New Roman')
ylabel("Indian response (Sv)","FontSize",30,'FontName','Times New Roman')
title('(b)','FontSize',28,'FontName','Times New Roman')
ax = gca;
ax.TickDir = 'out';
ax.TitleHorizontalAlignment = 'left';

xc = get(gca,'XColor');
yc = get(gca,'YColor');
unit = get(gca,'units');
ax = axes( 'Units', unit,...
'Position',get(gca,'Position'),...
'XAxisLocation','top',...
'YAxisLocation','right',...
'Color','none',...
'XColor',xc,...
'YColor',yc);
set(ax, 'linewidth',1,...
'XTick', [],...
'YTick', [],'Fontsize',12);
box on

%% legend
legend([l1 l2],{"$\textit{r}_\mathrm{\hspace{2pt}N} = 0.80$","$\textit{r}_\mathrm{\hspace{2pt}N} = 0.67$"},'Position', [0.1, 0.825, 0.8, 0.05], 'Orientation', 'horizontal','Fontsize',28,'FontName','Times New Roman','interpreter','latex');

%% 保存
cd ../../picture/RGM/
path = cd;
exportgraphics(gcf, strcat(path,'\NAratio.jpg'));
close;