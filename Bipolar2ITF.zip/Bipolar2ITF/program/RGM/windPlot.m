%% 
clear
tau0 = 0.15;
lat = -72:1:72;
lon = 0:220;
dy = 111*10^3;
dyspace = 1;
yr = lat*2/144/dyspace;
amp = 0.5*exp(-(lat+25).^2/25)+1;
index = lat<-25;
amp(index) = 1.5;
anom = 0.07.*exp(-1*(yr+60*2/144).^2/0.016);%.*amp;
tau1d = (tau0/1.5.*(-cos(3*pi/2*yr)+0.8.*exp(-yr.^2/0.016))).*amp;
tau2d = tau1d+anom;

y = -72:12:72;
str = cell(size(y));
for i = 1:length(y)
    if y(i)<0
        str{i} = strcat(num2str(-y(i)),'\circ','S');
    elseif y(i)>0
        str{i} = strcat(num2str(y(i)),'\circ','N');
    elseif y(i)==0
        str{i} = '0';
    end
end

%% 风场差异绘图
figure(1)
clf
set(gcf,'color','white')
set(gcf,'position',[100,100,700,1200])
hold on
box on
grid on
p1 = plot(tau1d,lat,'LineWidth',2);
p2 = plot(tau2d,lat,'LineWidth',2);
p3 = plot([0 0],[-72,72],'k--','LineWidth',1.5);
legend([p1 p2],{'CTRL','Enhanced'},'FontSize',16)
xlim([-0.075 0.2])
ylim([-72 72])
yticks(y)
yticklabels(str)
xlabel("Wind stress forcing(N/m^{2})","FontSize",36)
set(gca,'Fontsize',24)

% cd D:\Desktop\work\SO&ITF\picture\RGM
% path = cd;
% saveas(gcf,strcat(path,'/wind.jpg'));
% close;

%%
rho = 1035;
f = 2*7.292*10^-5*sind(lat);
Lx = 220*111*10^3*cosd(lat);
% curl = diff(anom)/dy;
curl = diff(tau1d)/dy;
curl = [0,curl];
C = curl./f;%/rho.*Lx;
T = -anom./f/rho.*Lx*10^-6;
plot(T,lat,'LineWidth',3)
ylim([-60,-45])