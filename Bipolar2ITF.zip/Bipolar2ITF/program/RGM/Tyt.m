clear
cd D:\Desktop\work\SO&ITF\data\RGM\
filename = "Th.txt";
data = load(filename);
nmonth = floor(length(data)/64);
t = (1:nmonth)/12;
y = -61:-30;
T = zeros([32,nmonth]);
H = zeros([32,nmonth]);
for i = 1:nmonth
    T(:,i) = data(64*i-63:64*i-32);
    H(:,i) = data(64*i-31:64*i);
end
dT = T-T(:,1);
dh = H-H(:,1);

cd ../../picture/RGM
figure(1)
clf
set(gcf,'color','white')
set(gcf,'position',[100,100,2000,1000])
set(gcf, 'DefaultTextFontName', 'Times New Roman');

%% T
ax = gca;
set(ax,'Position',[0.1 0.1 0.8 0.8])
set(ax,'Fontsize',16,'FontName','Times New Roman')
hold on

contourf(t,y,dT,1:0.25:4.25,'LineStyle','none')
colormap(ax,cmocean('thermal',13))
h = colorbar(ax);
clim([1 4.25])
xlim([t(2),t(480)])
ylim([-50,-45])
xlabel("Time (year)","FontSize",30,'FontName','Times New Roman')
ylabel("Latitude (deg)","FontSize",30,'FontName','Times New Roman')
ax.TickDir = 'out';
title('(a)','FontSize',20,'FontName','Times New Roman')
ax.TitleHorizontalAlignment = 'left';

xc = get(gca,'XColor');
yc = get(gca,'YColor');
unit = get(gca,'units');
ax = axes( 'Units', unit,...
'Position',get(gca,'Position'),...
'XAxisLocation','top',...
'YAxisLocation','right',...
'Color','none',...
'XColor',xc,...
'YColor',yc);
set(ax, 'linewidth',1,...
'XTick', [],...
'YTick', [],'Fontsize',12);
box on

set(h, 'Position', [0.925 0.1 0.015 0.8]);
h.Label.String = 'Volume transport response (Sv)';
h.Label.FontSize = 30;
h.Label.FontName = 'Times New Roman';
% h.Ticks = 0:6.5/7:6.5;
% h.TickLabels = 0:7;

%% 保存
% path = cd;
% exportgraphics(gcf, strcat(path,'\eddyDiffusion.jpg'));
% close;