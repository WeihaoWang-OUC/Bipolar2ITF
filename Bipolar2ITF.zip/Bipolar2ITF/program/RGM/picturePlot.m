%% 读取数据
clear
cd D:\Desktop\work\SO&ITF\data\RGM\
filename1 = "diagnosis.txt";
filename2 = "wind_strengthen.txt";          %时间步长为一年
data1 = load(filename1);
data2 = load(filename2);
varList = {"ATL","PAC","IND","ITF","hatl","hpac","hind"};
mean = [11.1 12.4 -14.2 13.7 1227.24 1294.47 1298.52];
[n1,n2] = size(data1);
t = (1:n1)/12;
cd D:\Desktop\work\SO&ITF\picture\RGM\

%% 流量
len = 3000*12;
data = data1;
colorstyle = {"#0072BD","#A2142F","#EDB120","#7E2F8E"};
figure(1)
set(gcf,'color','white')
clf
hold on
for i = 1:4
    varName = varList{i};
    eval(strcat(varName," = data(1:len,i);"));
    eval(strcat("p",num2str(i)," = plot(t(1:len),",varName,",'color','",colorstyle{i},"','lineWidth',1.5);")) ;
    eval(strcat("plot([0 t(len)],[mean(i) mean(i)],'color','",colorstyle{i},"','lineStyle','--','linewidth',1.5)"))
end
legend([p1 p2 p3 p4],varList{1:4})
xlim([0 t(len)])
ylim([-15 22])
xlabel("time(year)","FontSize",20)
path = cd;
saveas(gcf,strcat(path,'/transport.jpg'));
close;

%% 流量异常
len = 100*12;
data = data2;
colorstyle = {"#0072BD","#A2142F","#EDB120","#7E2F8E","#77AC30"};
figure(1)
set(gcf,'color','white')
clf
hold on
for i = 1:4
    varName = varList{i};
    eval(strcat(varName," = data(1:len,i)-mean(i);"));
    eval(strcat("p",num2str(i)," = plot(t(1:len),",varName,",'color','",colorstyle{i},"','lineWidth',1.5);")) ;
end
SO = ATL+PAC+IND;
p5 = plot(t(1:len),SO(1:len),'Color',colorstyle{5},'LineWidth',1.5);
plot([0 t(len)],[0 0],'k--','LineWidth',1)
legend([p1 p2 p3 p4 p5],{varList{1:4} 'SO'})
xlim([0 t(len)])
ylim([-2 5]);
xlabel("time(year)","FontSize",20)
path = cd;
saveas(gcf,strcat(path,'/transportAnomally.jpg'));
%close;

%% 输运异常演变同步性
len = 100*12;
data = data2;
r1 = 0.4998;
r2 = 0.7479;
colorstyle = {"#0072BD","#A2142F"};

figure(1)
set(gcf,'color','white')
clf
hold on
for i = 1:4
    varName = varList{i};
    eval(strcat(varName," = data(1:len,i)-mean(i);"));
end
p1 = plot(t(1:len),-ITF./(IND+PAC+ATL),'Color',colorstyle{1},'LineWidth',1.5);
p2 = plot(t(1:len),-ITF./IND,'Color',colorstyle{2},'LineWidth',1.5);
l1 = plot(t(1:len),r1*ones([1,len]),'--','color',colorstyle{1},'LineWidth',1);
l2 = plot(t(1:len),r2*ones([1,len]),'--','color',colorstyle{2},'LineWidth',1);
legend([p1 p2],{"-ITF/SO","-ITF/IND"})
xlim([0 t(len)])
ylim([0 1])
xlabel("time(year)","FontSize",20)
path = cd;
saveas(gcf,strcat(path,'/transportRatio.jpg'));
close;

%% 流量差分
len = 3000*12;
data = data1;
colorstyle = {"#0072BD","#A2142F","#EDB120","#7E2F8E"};
figure(1)
clf
hold on
for i = 1:4
    varName = varList{i};
    eval(strcat(varName," = diff(data(1:len,i));"));
    eval(strcat("p",num2str(i)," = plot(t(1:len-1),",varName,",'color','",colorstyle{i},"','lineWidth',1.5);")) ;
end
legend([p1 p1 p2 p3],varList{1:4})
xlim([0 t(len)])
xlabel("time(year)","FontSize",20)
title("Transport difference evolution","FontSize",32)

%% 厚度
len = 3000*12;
data = data1;
colorstyle = {"#0072BD","#A2142F","#EDB120"};
figure(1)
clf
hold on
for i = 1:3
    varName = varList{i};
    eval(strcat(varName," = data(1:len,i+4);"));
    eval(strcat("p",num2str(i)," = plot(t(1:len),",varName,",'color','",colorstyle{i},"','lineWidth',1.5);")) ;
end
legend([p1 p2 p3],varList{1:3})
xlim([0 t(len)])
ylim([500 1450])
xlabel("time(year)","FontSize",20)
path = cd;
saveas(gcf,strcat(path,'/h.jpg'));
close;

%% 不同大洋厚度演变同步性
len = 100*12;
data = data2;
figure(1)
clf
hold on
for i = 1:3
    varName = varList{i};
    eval(strcat(varName," = data(1:len,i+4);"));
end
p1 = plot(t(1:len),PAC./IND,'LineWidth',1.5);
p2 = plot(t(1:len),ATL./IND,'LineWidth',1.5);
legend([p1 p2],{"PAC/IND","ATL/IND"})
xlim([0 t(len)])
xlabel("time(year)","FontSize",20)
title("ratio evolution","FontSize",32)

%% 厚度异常
len = 100*12;
data = data2;
colorstyle = {"#0072BD","#A2142F","#EDB120"};
figure(1)
clf
set(gcf,'color','white');
hold on
for i = 1:3
    varName = varList{i};
    eval(strcat(varName," = data(1:len,i+4)-mean(i+4);"));
    eval(strcat("p",num2str(i)," = plot(t(1:len),",varName,",'color','",colorstyle{i},"','lineWidth',1.5);")) ;
end
plot([0 t(len)],[0 0],'k--','LineWidth',1)
legend([p1 p2 p3],varList{1:3})
xlim([0 t(len)])
ylim([0 65])
xlabel("time(year)","FontSize",20)
path = cd;
saveas(gcf,strcat(path,'/hAnomally.jpg'));
close;

%% 南大洋涡旋输运异常估算
len = 100*12;
data = data2;
Kgm = 10^3;
Lx = [60 60 100];
Ly = 42;
figure(1)
clf
set(gcf,'color','white');
hold on
for i = 1:3
    varName = varList{i};
    eval(strcat(varName," = Kgm.*Lx(i)./Ly.*(data(1:len,i+4)-mean(i+4))./10^6;"));
end
SOe = ATL+PAC+IND;
plot(t(1:len),SOe,'LineWidth',1.5)
xlim([0 t(len)])
xlabel("time(year)","FontSize",20)
title("SO eddy Transport anomally evolution","FontSize",32)


%% 绝热输运
len = 100*12;
data = data2;
S = (111*10^3)^2*[90*60 80*100 45*60];
colorstyle = {"#0072BD","#A2142F","#EDB120","#7E2F8E"};
figure(1)
clf
set(gcf,'color','white');
hold on
for i = 1:3
    varName = varList{i};
    eval(strcat(varName," = diff(data(1:len,i+4))/30/24/3600*S(i)/10^6;"));
    eval(strcat("p",num2str(i)," = plot(t(1:len-1),",varName,",'color','",colorstyle{i},"','lineWidth',1.5);")) ;
end
Tad = ATL+PAC+IND;
p4 = plot(t(1:len-1),Tad(1:len-1),'color',colorstyle{4},'LineWidth',1.5);
legend([p1 p2 p3 p4],{varList{1:3} 'T_{adiabat}'})
xlim([0 t(len)])
xlabel("time(year)","FontSize",20)
title("adiabat Transport evolution","FontSize",32)