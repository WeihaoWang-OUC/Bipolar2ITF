%% 读取数据
clear
cd C:\Users\admin\Desktop\SO&ITF\data\RGM
filename1 = "control.txt";
filename2 = "SO.txt";
filename5 = "SO_linear.txt";
control = load(filename1);
data_SO = load(filename2);
data_SO_linear = load(filename5);
varList = {"ATL","PAC","IND","ITF","hatl","hpac","hind"};
climatology = [11.1 12.4 -14.2 13.7 1227.24 1294.47 1298.52 788.78];
[n1,n2] = size(control);
t = (1:n1)/12;
len = 100*12;

figure(1)
clf
set(gcf,'color','white')
set(gcf,'position',[100,100,2000,1000])
set(gcf, 'DefaultTextFontName', 'Times New Roman');

%% (a)深度剖面
colorstyle = turbo(6);
data = load('depth.txt');
depth = reshape(data,[220,7]);
depth(1:2,:) = nan;
depth(end-1:end,:) = nan;
yr = [1,5,10,25,45];
str = cell([length(yr)+1,1]);

ax1 = subplot('Position', [0.05, 0.15, 0.43, 0.7]);
set(gca,'Fontsize',16,'FontName','Times New Roman')
hold on

for i = 1:length(yr)
    plot(depth(:,i+1)-depth(:,1),'LineWidth',2.5,'Color',colorstyle(i+1,:));
    str{i} = strcat('Year ',num2str(yr(i)));
end
% k1 = plot([0 220],[0 0],'k--','LineWidth',1.5);
k2 = plot([60 60],[-5 30],'--','LineWidth',2,'Color',.6*[1 1 1]);
k3 = plot([120 120],[-5 30],'--','LineWidth',2,'Color',.6*[1 1 1]);
text(30,27,'Atlantic','HorizontalAlignment', 'center','Color',"#B9181A","FontSize",36)
text(30,17,'$\delta T_{\mathrm{A}}>0$','Interpreter','latex','HorizontalAlignment', 'center','Color',"#B9181A","FontSize",30,'FontName','Cambria Math')
text(90,27,'Indian','HorizontalAlignment', 'center','Color',"#369F2D","FontSize",36)
text(90,17,'$\delta T_{\mathrm{I}}>0$','Interpreter','latex','HorizontalAlignment', 'center','Color',"#369F2D","FontSize",30,'FontName','Cambria Math')
text(170,27,'Pacific','HorizontalAlignment', 'center','Color',"#FABB6E","FontSize",36)
text(170,17,'$\delta T_{\mathrm{P}}\approx 0$','Interpreter','latex','HorizontalAlignment', 'center','Color',"#FABB6E","FontSize",30,'FontName','Cambria Math')
str{end} = '';

set(gca, 'YDir', 'reverse');
ax1.TickDir = 'out';
ax1.YGrid = 'on';  % 横向网格线（与 Y 轴平行）
ax1.XGrid = 'off';  % 关闭纵向网格线（与 X 轴平行）
lgd = legend(str,'NumColumns',5,'FontSize',28,'Location','north','FontName','Times New Roman');
% set(lgd, 'BackgroundAlpha', 0.8);
xlim([0 220])
ylim([-5,30])
xlabel("Longitude (deg)","FontSize",30,'FontName','Times New Roman')
ylabel("Interface depth anomaly at 30\circS (m)","FontSize",30,'FontName','Times New Roman')

title('(a)','FontSize',28,'FontName','Times New Roman')
ax = gca;
ax.TitleHorizontalAlignment = 'left';

xc = get(gca,'XColor');
yc = get(gca,'YColor');
unit = get(gca,'units');
ax = axes( 'Units', unit,...
'Position',get(gca,'Position'),...
'XAxisLocation','top',...
'YAxisLocation','right',...
'Color','none',...
'XColor',xc,...
'YColor',yc);
set(ax, 'linewidth',1,...
'XTick', [],...
'YTick', [],'Fontsize',12);
box on

%% (b)体积输运
data = data_SO;
colorstyle = {"#B9181A","#FABB6E","#369F2D","#614099","#4995C6"};

ax2 = subplot('Position', [0.545, 0.15, 0.43, 0.7]);
set(gca,'Fontsize',16,'FontName','Times New Roman')
hold on
grid on

for i = 1:4
    varName = varList{i};
    eval(strcat(varName," = data(1:len,i)-data(1,i);"));
    eval(strcat("p",num2str(i)," = plot(t(1:len),",varName,",'color','",colorstyle{i},"','lineWidth',2.5);")) ;
end
SO = ATL+PAC+IND;
p5 = plot(t(1:len),SO(1:len),'Color',colorstyle{5},'LineWidth',2.5);
% k = plot([0 len],[0 0],'--','LineWidth',2,'Color',.6*[1 1 1]);
lgd = legend([p1,p3,p2,p4,p5],{'Atlantic','Indian','Pacific','ITF','SO'},'NumColumns',5,'FontSize',28,'Location','northeast','FontName','Times New Roman');
set(lgd, 'BackgroundAlpha', 0.8);
ax2.TickDir = 'out';
xlim([1,t(len)])
ylim([-2 4]);
xlabel("Time (year)","FontSize",30,'FontName','Times New Roman')
ylabel("Transport response (Sv)","FontSize",30,'FontName','Times New Roman')
title('(b)','FontSize',28,'FontName','Times New Roman')
ax = gca;
ax.TitleHorizontalAlignment = 'left';

xc = get(gca,'XColor');
yc = get(gca,'YColor');
unit = get(gca,'units');
ax = axes( 'Units', unit,...
'Position',get(gca,'Position'),...
'XAxisLocation','top',...
'YAxisLocation','right',...
'Color','none',...
'XColor',xc,...
'YColor',yc);
set(ax, 'linewidth',1,...
'XTick', [],...
'YTick', [],'Fontsize',12);
box on

%% 保存
cd ../../picture/RGM
path = cd;
exportgraphics(gcf, strcat(path,'\RGMresponse.jpg'));
close;