%% 读取数据
clear
cd D:\Desktop\work\SO&ITF\data\RGM\
filename1 = "control.txt";
filename2 = "SO.txt";
filename3 = "NA.txt";
filename4 = "SO&NA.txt";
filename5 = "SO_linear.txt";
filename6 = "NA_linear.txt";
filename7 = "SO&NA_linear.txt";
control = load(filename1);
data_SO = load(filename2);
data_NA = load(filename3);
data_SO_NA = load(filename4);
data_SO_linear = load(filename5);
data_NA_linear = load(filename6);
data_SO_NA_linear = load(filename7);
varList = {"ATL","PAC","IND","ITF","hatl","hpac","hind"};
mean = [11.1 12.4 -14.2 13.7 1227.24 1294.47 1298.52 17.81 -21.62 3.14];
[n1,n2] = size(control);
t = (1:n1)/12;
% cd D:\Desktop\work\SO&ITF\picture\RGM\

%% 流量异常(SO)
len = 100*12;
data = data_NA_linear;
colorstyle = {"#0072BD","#A2142F","#EDB120","#7E2F8E","#77AC30"};
figure(1)
set(gcf,'color','white')
set(gcf,'position',[100,100,900,700])
clf
set(gca,'Fontsize',24)
hold on
box on
grid on

for i = 1:4
    varName = varList{i};
    eval(strcat(varName," = data(1:len,i)-mean(i);"));
    % eval(strcat(varName," = data(1:len,i)-data(1,i);"));
    eval(strcat("p",num2str(i)," = plot(t(1:len),",varName,",'color','",colorstyle{i},"','lineWidth',2);")) ;
end
SO = ATL+PAC+IND;
p5 = plot(t(1:len),SO(1:len),'Color',colorstyle{5},'LineWidth',1.5);
legend({'Atlantic','Pacific','Indian','ITF','SO'},'FontSize',16,'Location','northwest')
xlim([0 t(len)])
% ylim([-2 4]);
xlabel("Time(year)","FontSize",36)
ylabel("Transport anomaly(Sv)","FontSize",36)
grid on
% path = cd;
% saveas(gcf,strcat(path,'/SOtransport.jpg'));
% close;

%% 流量异常(SO)
len = 100*12;
data = load("40S.txt");
colorstyle = {"#0072BD","#A2142F","#EDB120","#7E2F8E","#77AC30"};
figure(1)
set(gcf,'color','white')
set(gcf,'position',[100,100,900,700])
clf
hold on
for i = 1:3
    varName = varList{i};
    eval(strcat(varName," = data(1:len,i)-data(1,i);"));
    eval(strcat("p",num2str(i)," = plot(t(1:len),",varName,",'color','",colorstyle{i},"','lineWidth',2);")) ;
end
T = PAC+IND+ATL;
p = plot(t(1:len),T,'LineWidth',2);
legend({'Atlantic','Pacific','Indian','SO'},'FontSize',16)
xlim([0 t(len)])
xlabel("Time(year)","FontSize",36)
ylabel("Transport anomaly(Sv)","FontSize",36)
grid on
% path = cd;
% saveas(gcf,strcat(path,'/SOtransport.jpg'));
% close;

%% 流量异常(NA)
len = 100*12;
data = data_NA;
colorstyle = {"#0072BD","#A2142F","#EDB120","#7E2F8E","#77AC30"};
figure(1)
set(gcf,'color','white')
set(gcf,'position',[100,100,900,700])
clf
hold on
for i = 1:4
    varName = varList{i};
    eval(strcat(varName," = data(1:len,i)-mean(i);"));
    eval(strcat("p",num2str(i)," = plot(t(1:len),",varName,",'color','",colorstyle{i},"','lineWidth',1.5);")) ;
end
SO = ATL+PAC+IND;
p5 = plot(t(1:len),SO(1:len),'Color',colorstyle{5},'LineWidth',1.5);
legend({'Atlantic','Pacific','Indian','ITF','SO'},'FontSize',16)
xlim([0 t(len)])
ylim([-4 3]);
xlabel("Time(year)","FontSize",36)
ylabel("Transport anomaly(Sv)","FontSize",36)
grid on
path = cd;
saveas(gcf,strcat(path,'/NAtransport.jpg'));
close;

%% 流量异常(NA&SO)
len = 100*12;
data = data_SO_NA;
colorstyle = {"#0072BD","#A2142F","#EDB120","#7E2F8E","#77AC30"};
figure(1)
set(gcf,'color','white')
set(gcf,'position',[100,100,900,700])
clf
hold on
for i = 1:4
    varName = varList{i};
    eval(strcat(varName," = data(1:len,i)-mean(i);"));
    eval(strcat("p",num2str(i)," = plot(t(1:len),",varName,",'color','",colorstyle{i},"','lineWidth',1.5);")) ;
end
SO = ATL+PAC+IND;
p5 = plot(t(1:len),SO(1:len),'Color',colorstyle{5},'LineWidth',1.5);
legend({'Atlantic','Pacific','Indian','ITF','SO'},'FontSize',16)
xlim([0 t(len)])
ylim([-4 5]);
xlabel("Time(year)","FontSize",36)
ylabel("Transport anomaly(Sv)","FontSize",36)
grid on
path = cd;
saveas(gcf,strcat(path,'/SO&NAtransport.jpg'));
close;

%% 输运异常演变同步性
len = 100*12;
data = data_SO;
r1 = 0.5083;
r2 = 0.7479;
colorstyle = {"#0072BD","#A2142F"};

figure(1)
set(gcf,'color','white')
set(gcf,'position',[100,100,800,600])
clf
set(gcf,'color','white');
set(gca,'Fontsize',16,'FontName','Times New Roman')
hold on

for i = 1:4
    varName = varList{i};
    eval(strcat(varName," = data(1:len,i)-mean(i);"));
    % eval(strcat(varName," = data(1:len,i)-data(1,i);"));
end
p1 = plot(t(1:len),ATL./IND,'Color',colorstyle{1},'LineWidth',2.5);
p2 = plot(t(1:len),-ITF./IND,'Color',colorstyle{2},'LineWidth',2.5);
l1 = plot(t(1:len),r1*ones([1,len]),'--','color',colorstyle{1},'LineWidth',2);
l2 = plot(t(1:len),r2*ones([1,len]),'--','color',colorstyle{2},'LineWidth',2);
legend([p1 p2],{"Atlantic vs Indian","Indian vs ITF"},'Fontsize',20,'FontName','Times New Roman')
xlim([3 t(len)])
% ylim([0 1])
xlabel("Time(year)","FontSize",30,'FontName','Times New Roman')
ylabel("Transport ratio","FontSize",30,'FontName','Times New Roman')
ax = gca;
ax.TickDir = 'out';

xc = get(gca,'XColor');
yc = get(gca,'YColor');
unit = get(gca,'units');
ax = axes( 'Units', unit,...
'Position',get(gca,'Position'),...
'XAxisLocation','top',...
'YAxisLocation','right',...
'Color','none',...
'XColor',xc,...
'YColor',yc);
set(ax, 'linewidth',1,...
'XTick', [],...
'YTick', [],'Fontsize',12);
box on

path = cd;
exportgraphics(gcf, strcat(path,'\transportRatio.jpg'));
close;

%%
data = load('depth.txt');
depth = reshape(data,[220,7]);
depth(1:2,:) = nan;
depth(end-1:end,:) = nan;
yr = [1,5,10,25,45,70];
str = cell(size(yr));

figure(1)
set(gcf,'color','white')
set(gcf,'position',[100,100,1200,1000])
clf
set(gcf,'color','white');
set(gca,'Fontsize',24)
hold on
box on
grid on

for t = 1:length(yr)
    plot(depth(:,t+1)-depth(:,1),'LineWidth',2);
    str{t} = strcat('Year ',num2str(yr(t)));
end

set(gca, 'YDir', 'reverse');
legend(str,'NumColumns',3) 
xlim([0 220])
xlabel("Longitude(deg)","FontSize",36)
ylabel("Interface depth anomaly at 30\circS(m)","FontSize",36)

%% 流量异常与地转输运(SO)
len = 100*12;
data = data_SO;
colorstyle = {"#0072BD","#A2142F","#EDB120","#7E2F8E","#77AC30"};
figure(1)
set(gcf,'color','white')
set(gcf,'position',[100,100,900,700])
clf
set(gca,'Fontsize',24)
hold on
box on
grid on

for i = 1:3
    varName = varList{i};
    eval(strcat(varName," = data(1:len,i)-mean(i);"));
    % eval(strcat(varName," = data(1:len,i)-data(1,i);"));
    eval(strcat("p",num2str(i)," = plot(t(1:len),",varName,",'color','",colorstyle{i},"','lineWidth',2);")) ;
end
SO = ATL+PAC+IND;
p5 = plot(t(1:len),SO(1:len),'Color',colorstyle{5},'LineWidth',1.5);
for i = 1:3
    varName = varList{i};
    eval(strcat(varName," = data(1:len,i+8)-mean(i+7);"));
    % eval(strcat(varName," = data(1:len,i)-data(1,i);"));
    eval(strcat("k",num2str(i)," = plot(t(1:len),",varName,",'--','color','",colorstyle{i},"','lineWidth',2);")) ;
end
SO = ATL+PAC+IND;
k5 = plot(t(1:len),SO(1:len),'--','Color',colorstyle{5},'LineWidth',1.5);
legend({'Atlantic','Pacific','Indian','SO'},'FontSize',16,'Location','northwest')
xlim([0 t(len)])
% ylim([-2 4]);
xlabel("Time(year)","FontSize",36)
ylabel("Transport anomaly(Sv)","FontSize",36)
grid on
% path = cd;
% saveas(gcf,strcat(path,'/SOtransport.jpg'));
% close;

%% 不同纬度流量异常(SO)
len = 100*12;
colorstyle = {"#0072BD","#A2142F","#EDB120","#7E2F8E","#77AC30"};
figure(1)
set(gcf,'color','white')
set(gcf,'position',[100,100,900,700])
clf
hold on
box on
data = data_SO;
for i = 1:3
    varName = varList{i};
    eval(strcat(varName," = data(1:len,i)-data(1,i);"));
end
T = PAC+IND+ATL;
p1 = plot(t(1:len),T,'LineWidth',2);

data = load("40S.txt");
for i = 1:3
    varName = varList{i};
    eval(strcat(varName," = data(1:len,i)-data(1,i);"));
end
T = PAC+IND+ATL;
p2 = plot(t(1:len),T,'LineWidth',2);

data = load("45S.txt");
for i = 1:3
    varName = varList{i};
    eval(strcat(varName," = data(1:len,i)-data(1,i);"));
end
T = PAC+IND+ATL;
p3 = plot(t(1:len),T,'LineWidth',2);

data = load("50S.txt");
for i = 1:3
    varName = varList{i};
    eval(strcat(varName," = data(1:len,i)-data(1,i);"));
end
T = PAC+IND+ATL;
p4 = plot(t(1:len),T,'LineWidth',2);

data = load("55S.txt");
for i = 1:3
    varName = varList{i};
    eval(strcat(varName," = data(1:len,i)-data(1,i);"));
end
T = PAC+IND+ATL;
p5 = plot(t(1:len),T,'LineWidth',2);

data = load("60S.txt");
for i = 1:3
    varName = varList{i};
    eval(strcat(varName," = data(1:len,i)-data(1,i);"));
end
T = PAC+IND+ATL;
p6 = plot(t(1:len),T,'LineWidth',2);

legend({'30\circS','40\circS','45\circS','50\circS','55\circS','60\circS'},'FontSize',16)
xlim([0 t(len)])
xlabel("Time(year)","FontSize",36)
ylabel("Transport anomaly(Sv)","FontSize",36)
cd D:\Desktop\work\SO&ITF\picture\RGM\
path = cd;
saveas(gcf,strcat(path,'/transportInDifferentY.jpg'));
close;