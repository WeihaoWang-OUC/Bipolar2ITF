clear

%% 读取数据
cd D:\Desktop\work\SO&ITF\data\RGM\
filename = "Th.txt";
data = load(filename);
nmonth = floor(length(data)/64);
t = (1:nmonth)/12;
y = -61:-30;
T = zeros([32,nmonth]);
H = zeros([32,nmonth]);
for i = 1:nmonth
    T(:,i) = data(64*i-63:64*i-32);
    H(:,i) = data(64*i-31:64*i);
end

h = H(:,end);
hy = diff(h,1)/111/10^3;

%% 计算积分
yy = -60:0.05:-30;
dt = 3600*24*30;
dy = 111*10^3/20;
Kgm = 1000;
rho = 1035;
tau0 = 0.15;
kappa = 2*10^-5;
f = 2*7.292*10^-5*sind(yy);
Lx = 220*111*10^3*cosd(yy);
yr = yy*2/144;
amp = 0.5*exp(-(yy+25).^2/25)+1;
index = yy<-25;
amp(index) = 1.5;
anom = 0.07.*exp(-1*(yr+60*2/144).^2/0.016);%.*amp;
tau1d = (tau0/1.5.*(-cos(3*pi/2*yr)+0.8.*exp(-yr.^2/0.016))).*amp;
tau2d = tau1d+anom;

I1 = zeros(size(yy));
I2 = I1;
% I1(end) = -hy(end)*rho*Kgm;
I1(1) = -hy(2)*rho*Kgm;
I2(1) = -h(2)*rho*Kgm;
% for j = length(yy):-1:2
%     I1(j-1) = I1(j)-1/2*(1/f(j-1)+1/f(j))*(tau2d(j)-tau2d(j-1));
% end
for j = 2:length(yy)
    I1(j) = I1(j-1)+1/2*(1/f(j-1)+1/f(j))*(tau2d(j)-tau2d(j-1));
end
for j = 2:length(yy)
    I2(j) = I2(j-1)+1/2*(I1(j-1)+I1(j))*dy;
end
h_bar = -I2/rho/Kgm;
h0 = h_bar(1:20:end);
H = H(2:end,:);
hh = zeros([length(y) nmonth]);
for i = 1:length(y)-1
    for j = 1:nmonth
        hh(i,j) = h0(i)-H(i,j);
    end
end

%% 画图
cd ../../picture/RGM
figure(1)
clf
set(gcf,'color','white')
set(gcf,'position',[100,100,2000,1000])
set(gcf, 'DefaultTextFontName', 'Times New Roman');

ax = gca;
set(gca,'Position', [0.1, 0.1, 0.8, 0.8]);
set(ax,'Fontsize',16,'FontName','Times New Roman')
hold on

contourf(t,y,hh,0:100:1400,'LineStyle','none')
colormap(ax,cmocean('deep',14))
h = colorbar(ax);
xlim([t(1),t(1200)])
ylim([-60,-45])
clim(ax,[0 1400])
xlabel("Time (year)","FontSize",30,'FontName','Times New Roman')
ylabel("Latitude (deg)","FontSize",30,'FontName','Times New Roman')
ax.TickDir = 'out';
ax.TitleHorizontalAlignment = 'left';

xc = get(gca,'XColor');
yc = get(gca,'YColor');
unit = get(gca,'units');
ax = axes( 'Units', unit,...
'Position',get(gca,'Position'),...
'XAxisLocation','top',...
'YAxisLocation','right',...
'Color','none',...
'XColor',xc,...
'YColor',yc);
set(ax, 'linewidth',1,...
'XTick', [],...
'YTick', [],'Fontsize',12);
box on

set(h, 'Position', [0.925 0.1 0.015 0.8]);
h.Label.String = 'Zonal mean interface depth (m)';
h.Label.FontSize = 30;
h.Label.FontName = 'Times New Roman';