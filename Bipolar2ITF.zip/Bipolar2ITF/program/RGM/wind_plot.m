%% 
clear
tau0 = 0.15;
lat = -72:72;
lon = 0:220;
dy = 111*10^3;
dyspace = 1;
rou0 = 1035;
Omega = 7.29*10^-5;
kappa = 2*10^-5;
g = 0.02;
h = 900;
dh = 200;
f = 2*Omega.*sind(lat);
yr = lat*2/144/dyspace;
amp = 0.5*exp(-(lat+25).^2/25)+1;
index = lat<-25;
amp(index) = 1.5;
anom = 0.07.*exp(-1*(yr+60*2/144).^2/0.016);%.*amp;
tau1d = (tau0/1.5.*(-cos(3*pi/2*yr)+0.8.*exp(-yr.^2/0.016))).*amp;
tau2d = tau1d+anom;
cd ../picture/

%% 风场差异绘图
figure(1)
set(gcf,'color','white')
p1 = plot(tau1d,lat,'LineWidth',1.5);
hold on
p2 = plot(tau2d,lat,'LineWidth',1.5);
p3 = plot([-0.075 0.2],[-30,-30],'k--','LineWidth',1);
legend([p1 p2],{'origin','strengthening'})
xlim([-0.075 0.2])
ylim([-72 72])
xlabel("wind stress forcing(N/m^{2})","FontSize",20)
ylabel("latitude(\circ)","FontSize",20)
path = cd;
saveas(gcf,strcat(path,'/wind.jpg'));
close;

%% island rule输运异常
index = lat == -30;
Tis = -anom(index)*(220-120)*dx(lat==-30)/Omega/rou0*10^-6;

%% Ekman输运异常
beta = 2*Omega.*cosd(lat);
dtau = [0 diff(anom)];
wEkman = -dtau./dy/f/rou0+beta.*anom./f.^2/rou0;
wEkman(73) = 0;
index = lat>-72 & lat<-62;
TEkman = index*rot90(wEkman.*dy^2)*10^-6;

%% 太平洋非绝热输运异常
dwDia = kappa/(h+dh)-kappa/h;
index = lat<50 &lat>-30;
S = 100*80*dy^2;
Tdia = dwDia*S/10^6;
