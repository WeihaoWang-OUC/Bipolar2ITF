%% 读取数据
clear
cd D:\Desktop\work\SO&ITF\data\RGM
filename = "global_depth.txt";
data = load(filename);
data = reshape(data,[144,3,5,220]);
data = permute(data,[1,4,3,2]);
depth = data(:,:,:,1);
inx = depth==0;
depth(inx) = nan;
% lev = [-5,-2,-1,-0.005,0.005,0.006,0.007,0.008,0.009,0.01,0.015,0.02,0.03,0.05,0.1,0.5,1,10,30];
% lev = [-30,-10,-1,-0.5,-0.1,-0.05,-0.03,-0.02,-0.015,-0.01,-0.009,-0.008,-0.007,-0.006,-0.005,0.005,0.006,0.007,0.008,0.009,0.01,0.015,0.02,0.03,0.05,0.1,0.5,1,10,30];
lev = [-1000,-30,-10,-1,-0.5,-0.1,-0.05,-0.03,-0.02,-0.01,-0.005,0.005,0.01,0.02,0.03,0.05,0.1,0.5,1,10,30,1000];
n = length(lev);
label = cell([n 1]);
for i = 1:n
    label{i} = num2str(lev(i));
end
day = [0,3,30,120,200];
letter = {'(a) ','(b) ','(c) ','(d) '};

%% 界面异常
cd ../../picture/RGM
figure(1)
clf
set(gcf,'color','white')
set(gcf,'position',[-100,000,2200,1000])
set(gcf, 'DefaultTextFontName', 'Times New Roman');

cmap = cmocean('balance',n-3);

pos1 = [0.1 0.55 0.30 0.35];
pos2 = [0.45 0.55 0.30 0.35];
pos3 = [0.1 0.1 0.30 0.35];
pos4 = [0.45 0.1 0.30 0.35];

lon = 0.5:219.5;
lat = -71.5:71.5;
h0 = squeeze(depth(:,:,1));
for t = 2:length(day)
    eval(strcat('ax = subplot("Position",pos',num2str(t-1),');'))
    set(gca,'Fontsize',16,'FontName','Times New Roman')
    hold on
    % ax = subplot(2,2,t-1);
    set(gca,'Fontsize',16)
    yr = day(t);
    tmp = squeeze(depth(:,:,t));
    anom = tmp-h0;
    [~, ~, idx] = histcounts(anom,lev);
    idx(inx(:,:,2)) = nan;
    c = pcolor(lon,lat,idx);
    shading interp
    colormap(cmap)
    clim([1 n-2])
    xlim([0 220])
    ylim([-72 72])
    ax.TickDir = 'out';
    if t == 4 || t ==5
        xlabel("Longitude (deg)","FontSize",30,'FontName','Times New Roman')
    end
    if t == 2 || t ==4
        ylabel("Latitude (deg)","FontSize",30,'FontName','Times New Roman')
    end
    title(strcat(letter(t-1),num2str(yr),' days'),'FontSize',28,'FontName','Times New Roman');

    ax = gca;
    ax.TitleHorizontalAlignment = 'left';

    xc = get(gca,'XColor');
    yc = get(gca,'YColor');
    unit = get(gca,'units');
    ax = axes( 'Units', unit,...
        'Position',get(gca,'Position'),...
        'XAxisLocation','top',...
        'YAxisLocation','right',...
        'Color','none',...
        'XColor',xc,...
        'YColor',yc);
    set(ax, 'linewidth',1,...
        'XTick', [],...
        'YTick', [],'Fontsize',12);
    box on
end

h = colorbar('ticks',lev);
set(h, 'Position', [0.78 0.10 0.015 0.8]);
h.Label.String = 'Interface depth anomaly (m)';
h.Label.FontSize = 30;
h.Label.FontName = 'Times New Roman';
h.Ticks = 0:1/(n-3):1;
h.TickLabels = label(2:end);

%% 储存
path = cd;
exportgraphics(gcf, strcat(path,'/wavePath.jpg'));
close;

% %% 界面异常
% cd ../../picture/RGM
% figure(1)
% clf
% set(gcf,'color','white')
% set(gcf,'position',[100,100,1800,1000])
% cmap = cmocean('balance',n-3);
% 
% pos1 = [0.1 0.57 0.35 0.35];
% pos2 = [0.47 0.57 0.35 0.35];
% pos3 = [0.1 0.1 0.35 0.35];
% pos4 = [0.47 0.1 0.35 0.35];
% 
% lon = 0.5:219.5;
% lat = -71.5:71.5;
% h0 = squeeze(depth(:,:,1));
% for t = 2:length(day)
%     eval(strcat('ax = subplot("Position",pos',num2str(t-1),');'))
%     % ax = subplot(2,2,t-1);
%     hold on
%     box on
%     set(gca,'Fontsize',16)
%     axis equal
%     yr = day(t);
%     tmp = squeeze(depth(:,:,t));
%     anom = tmp-h0;
%     [~, ~, idx] = histcounts(anom,lev);
%     idx(inx(:,:,2)) = nan;
%     c = pcolor(lon,lat,idx);
%     shading interp
%     colormap(cmap)
%     clim([1 n-2])
%     xlim([0 220])
%     ylim([-72 72])
%     ax.TickDir = 'out';
%     xlabel("Longitude(deg)","FontSize",18)
%     ylabel("Latitude(deg)","FontSize",18)
%     title(strcat(letter(t-1),num2str(yr),'days'),'FontSize',24);
% end
% 
% h = colorbar('ticks',lev);
% set(h, 'Position', [0.82 0.10 0.015 0.82]);
% h.Label.String = 'Depth anomaly(m)';
% h.Label.FontSize = 36;
% h.Ticks = 1:n;
% h.TickLabels = label(2:end-1);

% path = cd;
% saveas(gcf,'wavePath.jpg');
% close;