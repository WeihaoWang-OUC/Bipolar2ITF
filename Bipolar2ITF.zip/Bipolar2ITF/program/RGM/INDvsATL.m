clear
figure(1)
clf
set(gcf,'color','white')
set(gcf,'position',[-1000,0,2000,1000])
set(gcf, 'DefaultTextFontName', 'Times New Roman');

% annotation('textbox', [0.0, 0.965, 1, 0.05], 'String', 'Atlantic vs. Indian', ...
%     'EdgeColor', 'none', 'FontName','Times New Roman','HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize',48);
% annotation('textbox', [0.0, 0.47, 1, 0.05], 'String', 'Indian vs. ITF', ...
%     'EdgeColor', 'none', 'FontName','Times New Roman','HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize',48);

%% 读取数据
cd D:\Desktop\work\SO&ITF\data\RGM
filename1 = "control.txt";
filename2 = "SO_linear.txt";
filename3 = "NA_linear.txt";
control = load(filename1);
data_SO = load(filename2);
data_NA = load(filename3);
varList = {"ATL","PAC","IND","ITF","hatl","hpac","hind"};
climatology = [11.1 12.4 -14.2 13.7 1227.24 1294.47 1298.52 788.78];
[n1,n2] = size(control);
t = (1:1200)/12;

len = 100*12;

%% (a)
data = data_NA;
ax1 = subplot('Position', [0.05, 0.1, 0.4, 0.8]);
set(gca,'Fontsize',16,'FontName','Times New Roman')
hold on

for i = 1:3
    varName = varList{i};
    eval(strcat(varName," = data(1:len,i)-data(1,i);"));
end
s = scatter(ATL,IND,50,t,"filled");
plot([-3,1],-0.67*[-3,1],'k--','LineWidth',1.5)

ax1.TickDir = 'out';
xlim([-2.9 0.1])
ylim([-0.1 2.1])
xlabel('Atlantic response (Sv)','FontSize',30,'FontName','Times New Roman')
ylabel('Indian response (Sv)','FontSize',30,'FontName','Times New Roman')
title('(a) NADW perturbation','FontSize',28,'FontName','Times New Roman')
ax = gca;
ax.TitleHorizontalAlignment = 'left';

xc = get(gca,'XColor');
yc = get(gca,'YColor');
unit = get(gca,'units');
ax = axes( 'Units', unit,...
'Position',get(gca,'Position'),...
'XAxisLocation','top',...
'YAxisLocation','right',...
'Color','none',...
'XColor',xc,...
'YColor',yc);
set(ax, 'linewidth',1,...
'XTick', [],...
'YTick', [],'Fontsize',12);
box on

%% (b)
data = data_SO;
ax2 = subplot('Position', [0.51, 0.1, 0.4, 0.8]);
set(gca,'Fontsize',16,'FontName','Times New Roman')
hold on

for i = 1:3
    varName = varList{i};
    eval(strcat(varName," = data(1:len,i)-data(1,i);"));
end
s = scatter(ATL,IND,50,t,"filled");
plot([-0.2,1.5],1.97*[-0.2,1.5],'k--','LineWidth',1.5)

ax2.TickDir = 'out';
xlim([-0.05 1.05])
ylim([-0.05 1.75])
xlabel('Atlantic response (Sv)','FontSize',30,'FontName','Times New Roman')
title('(b) Southern Ocean perturbation','FontSize',28,'FontName','Times New Roman')
ax = gca;
ax.TitleHorizontalAlignment = 'left';

xc = get(gca,'XColor');
yc = get(gca,'YColor');
unit = get(gca,'units');
ax = axes( 'Units', unit,...
'Position',get(gca,'Position'),...
'XAxisLocation','top',...
'YAxisLocation','right',...
'Color','none',...
'XColor',xc,...
'YColor',yc);
set(ax, 'linewidth',1,...
'XTick', [],...
'YTick', [],'Fontsize',12);
box on

% %% (c)
% data = data_NA;
% ax3 = subplot('Position', [0.05, 0.05, 0.4, 0.4]);
% set(gca,'Fontsize',16,'FontName','Times New Roman')
% hold on
% 
% for i = 1:4
%     varName = varList{i};
%     eval(strcat(varName," = data(1:len,i)-data(1,i);"));
% end
% s = scatter(IND,ITF,50,t,"filled");
% plot([-0.05,2.5],-0.76*[-0.05,2.5],'k--','LineWidth',1.5)
% 
% ax3.TickDir = 'out';
% xlim([-0.05 2.05])
% ylim([-1.6 0.05])
% xlabel('Indian response (Sv)','FontSize',30,'FontName','Times New Roman')
% ylabel('ITF response (Sv)','FontSize',30,'FontName','Times New Roman')
% title('(c) NADW perturbation','FontSize',20,'FontName','Times New Roman')
% ax = gca;
% ax.TitleHorizontalAlignment = 'left';
% 
% xc = get(gca,'XColor');
% yc = get(gca,'YColor');
% unit = get(gca,'units');
% ax = axes( 'Units', unit,...
% 'Position',get(gca,'Position'),...
% 'XAxisLocation','top',...
% 'YAxisLocation','right',...
% 'Color','none',...
% 'XColor',xc,...
% 'YColor',yc);
% set(ax, 'linewidth',1,...
% 'XTick', [],...
% 'YTick', [],'Fontsize',12);
% box on
% 
% %% (d)
% data = data_SO;
% ax4 = subplot('Position', [0.51, 0.05, 0.4, 0.4]);
% set(gca,'Fontsize',16,'FontName','Times New Roman')
% hold on
% 
% for i = 1:4
%     varName = varList{i};
%     eval(strcat(varName," = data(1:len,i)-data(1,i);"));
% end
% s = scatter(IND,ITF,50,t,"filled");
% plot([-0.05,2],-0.76*[-0.05,2],'k--','LineWidth',1.5)
% 
% ax4.TickDir = 'out';
% xlim([-0.05 1.75])
% ylim([-1.35 0.05])
% xlabel('Indian response (Sv)','FontSize',30,'FontName','Times New Roman')
% title('(d) SH westerly wind perturbation','FontSize',20,'FontName','Times New Roman')
% ax = gca;
% ax.TitleHorizontalAlignment = 'left';
% 
% xc = get(gca,'XColor');
% yc = get(gca,'YColor');
% unit = get(gca,'units');
% ax = axes( 'Units', unit,...
% 'Position',get(gca,'Position'),...
% 'XAxisLocation','top',...
% 'YAxisLocation','right',...
% 'Color','none',...
% 'XColor',xc,...
% 'YColor',yc);
% set(ax, 'linewidth',1,...
% 'XTick', [],...
% 'YTick', [],'Fontsize',12);
% box on

%% colorbar
h = colorbar;
set(h, 'Position', [0.935 0.1 0.014 0.8]);
h.Label.String = 'Time (year)';
h.Label.FontSize = 30;
h.Label.FontName = 'Times New Roman';
h.Ticks = 0:0.2:1;
h.TickLabels = 0:20:100;

%% 保存
cd ../../picture/RGM
path = cd;
exportgraphics(gcf, strcat(path,'\INDvsATLlinear.jpg'));
close;