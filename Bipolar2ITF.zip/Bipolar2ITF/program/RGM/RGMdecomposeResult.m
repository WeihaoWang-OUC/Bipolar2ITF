clear
figure(1)
clf
set(gcf,'color','white')
set(gcf,'position',[-1200,-100,1200,1200])
set(gcf, 'DefaultTextFontName', 'Times New Roman');

%% (a)&(b)
%  读取数据
cd D:\Desktop\work\SO&ITF\data\RGM
filename1 = "control.txt";
% filename2 = "SO_linear.txt";
% filename3 = "NA_linear.txt";
% filename4 = "SO&NA_linear.txt";
filename2 = "SO.txt";
filename3 = "NA.txt";
filename4 = "SO&NA.txt";
control = load(filename1);
data_SO = load(filename2);
data_NA = load(filename3);
data_SO_NA = load(filename4);
varList = {"ATL","PAC","IND","ITF","hatl","hpac","hind"};
climatology = [11.1 12.4 -14.2 13.7 1227.24 1294.47 1298.52 788.78];
[n1,n2] = size(control);
t = (1:n1)/12;

%  贡献分解
len = 100*12;
data = data_SO_NA;
for i = [1,3]
    varName = varList{i};
    eval(strcat(varName," = data(1:len,i)-climatology(i);"));
end
A = [1,-1;0.6703,1.9672];
k = [0.4761;1.4793];
for n = 1:len
    b = [-ATL(n);IND(n)];
    x = A\b;
    frac(:,n) = -k(:).*x(:);
end
ITF = zeros([2,len]);
data = data_NA;
ITF(1,:) = data(1:len,4)-climatology(4);
data = data_SO;
ITF(2,:) = data(1:len,4)-climatology(4);

%  画图(a)
ax1 = subplot('Position', [0.1, 0.53, 0.8, 0.35]);
set(gca,'Fontsize',16,'FontName','Times New Roman')
hold on

p1 = plot(t(1:len),frac(1,1:len),'LineWidth',2.5,'Color','#F09BA0');
p2 = plot(t(1:len),ITF(1,1:len),'LineWidth',2.5,'Color','#614099');
text(25, -0.25, 'NA experiment', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize',24);

ax1.TickDir = 'out';
legend({'Decomposition','Real change'},'FontSize',28,'FontName','Times New Roman')
% xlabel('Time (year)','FontSize',30,'FontName','Times New Roman')
ylabel('Transport change (Sv)','FontSize',30,'FontName','Times New Roman')
title('(a)','FontSize',20,'FontName','Times New Roman')
ax = gca;
ax.TitleHorizontalAlignment = 'left';

xc = get(gca,'XColor');
yc = get(gca,'YColor');
unit = get(gca,'units');
ax = axes( 'Units', unit,...
'Position',get(gca,'Position'),...
'XAxisLocation','top',...
'YAxisLocation','right',...
'Color','none',...
'XColor',xc,...
'YColor',yc);
set(ax, 'linewidth',1,...
'XTick', [],...
'YTick', [],'Fontsize',12);
box on

%  画图(b)
ax2 = subplot('Position', [0.1, 0.1, 0.8, 0.35]);
set(gca,'Fontsize',16,'FontName','Times New Roman')
hold on

p1 = plot(t(1:len),frac(2,1:len),'LineWidth',2.5,'Color','#BFDFD2');
p2 = plot(t(1:len),ITF(2,1:len),'LineWidth',2.5,'Color','#614099');
text(25, -0.25, 'SO experiment', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize',24);

ax2.TickDir = 'out';
legend({'Decomposition','Real change'},'FontSize',28,'FontName','Times New Roman')
xlabel('Time (year)','FontSize',30,'FontName','Times New Roman')
ylabel('Transport change (Sv)','FontSize',30,'FontName','Times New Roman')
title('(b)','FontSize',20,'FontName','Times New Roman')
ax = gca;
ax.TitleHorizontalAlignment = 'left';

xc = get(gca,'XColor');
yc = get(gca,'YColor');
unit = get(gca,'units');
ax = axes( 'Units', unit,...
'Position',get(gca,'Position'),...
'XAxisLocation','top',...
'YAxisLocation','right',...
'Color','none',...
'XColor',xc,...
'YColor',yc);
set(ax, 'linewidth',1,...
'XTick', [],...
'YTick', [],'Fontsize',12);
box on

%% 保存
cd ../../picture/RGM
path = cd;
exportgraphics(gcf, strcat(path,'\RGMdecomposeResult.jpg'));
close;