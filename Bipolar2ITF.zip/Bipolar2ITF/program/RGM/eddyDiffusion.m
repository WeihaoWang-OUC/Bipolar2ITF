clear
cd C:\Users\admin\Desktop\SO&ITF\data\RGM
% filename = "Th.txt";
% data = load(filename);
% nmonth = floor(length(data)/64);
% t = (1:nmonth)/12;
% y = -61:-30;
% T = zeros([32,nmonth]);
% H = zeros([32,nmonth]);
% for i = 1:nmonth
%     T(:,i) = data(64*i-63:64*i-32);
%     H(:,i) = data(64*i-31:64*i);
% end
% dT = T-T(:,1);
% dh = H-H(:,1);

filename = "Thh.txt";
data = load(filename);
nmonth = floor(length(data)/84);
t = (1:nmonth)/12;
y = -71:-30;
T = zeros([42,nmonth]);
H = zeros([42,nmonth]);
for i = 1:nmonth
    T(:,i) = data(84*i-83:84*i-42);
    H(:,i) = data(84*i-41:84*i);
end
dT = T-T(:,1);
dh = H-H(:,1);

cd ../../picture/RGM
figure(1)
clf
set(gcf,'color','white')
set(gcf,'position',[100,100,2000,1000])
set(gcf, 'DefaultTextFontName', 'Times New Roman');

% annotation('textbox', [0.05, 0.88, 0.43, 0.05], 'String', 'Volume transport', ...
%     'EdgeColor', 'none', 'FontName','Times New Roman','HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize',48);
% annotation('textbox', [0.53, 0.88, 0.43, 0.05], 'String', 'Interface depth', ...
%     'EdgeColor', 'none', 'FontName','Times New Roman','HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize',48);

%%
% dt = 3600*24*30;
% dy = 111*10^3;
% Kgm = 1000;
% rho = 1035;
% tau0 = 0.15;
% kappa = 2*10^-5;
% f = 2*7.292*10^-5*sind(y);
% Lx = 220*111*10^3*cosd(y);
% yr = y*2/144;
% amp = 0.5*exp(-(y+25).^2/25)+1;
% index = y<-25;
% amp(index) = 1.5;
% anom = 0.07.*exp(-1*(yr+60*2/144).^2/0.016);%.*amp;
% tau1d = (tau0/1.5.*(-cos(3*pi/2*yr)+0.8.*exp(-yr.^2/0.016))).*amp;
% tau2d = tau1d+anom;
% 
% % curl = diff(anom)/dy;
% curl = diff(tau2d,1)/dy;
% curl = [0,curl];
% C = curl./f/rho;
% 
% ht = diff(H,1,2)/dt;
% ht = [zeros([32,1]),ht];
% hy = diff(H,1,1)/dy;
% hy = [zeros([1,nmonth]);hy];
% hyy = diff(hy,1,1)/dy;
% hyy = [zeros([1,nmonth]);hyy];
% Ty = diff(T,1,1)/dy*10^6;
% Ty = [zeros([1,nmonth]);Ty];
% 
% A = -Kgm*hyy;
% % res = zeros(size(A));
% % Tso = zeros(size(A));
% for j = 1:length(y)
%     res(j,:) = (A(j,:))/C(j);
%     Tso(j,:) = (-tau2d(j)*Lx(j)/rho/f(j)-Kgm*hy(j,:))/10^6;
%     D(j,:) = -Ty(j,:)/Lx(j);
%     E(j,:) = kappa./H(j,:);
%     aa = D./E;
% end
% contourf(t(2:3600),y(y<=-45&y>=-60),log(abs(aa(y<=-45&y>=-60,2:3600))))
% ylim([-60,-45])

%% (a)T
ax1 = subplot('Position', [0.06, 0.25, 0.43, 0.6]);
set(gca,'Fontsize',16,'FontName','Times New Roman')
hold on

contourf(t,y,dT,1:0.25:4.25,'LineStyle','none')
colormap(ax1,cmocean('thermal',13))
clim([1 4.25])
xlim([t(2),t(480)])
ylim([-50,-45])
xlabel("Time (year)","FontSize",30,'FontName','Times New Roman')
ylabel("Latitude (deg)","FontSize",30,'FontName','Times New Roman')
ax1.TickDir = 'out';
title('(a) Volume transport response','FontSize',28,'FontName','Times New Roman')
ax = gca;
ax.TitleHorizontalAlignment = 'left';

xc = get(gca,'XColor');
yc = get(gca,'YColor');
unit = get(gca,'units');
ax = axes( 'Units', unit,...
'Position',get(gca,'Position'),...
'XAxisLocation','top',...
'YAxisLocation','right',...
'Color','none',...
'XColor',xc,...
'YColor',yc);
set(ax, 'linewidth',1,...
'XTick', [],...
'YTick', [],'Fontsize',12);
box on

h = colorbar(ax1,'horiz');
set(h, 'Position', [0.06 0.1 0.43 0.03]);
h.Label.String = 'Sv';
h.Label.FontSize = 30;
h.Label.FontName = 'Times New Roman';

%% (b)h
ax2 = subplot('Position', [0.54, 0.25, 0.43, 0.6]);
% ax2 = gca;
% set(gca,'Position',[0.1, 0.1, 0.8, 0.8])
set(gca,'Fontsize',16,'FontName','Times New Roman')
hold on

% contourf(t,y,H,-20:20:200,'LineStyle','none')
contourf(t,y,dh,0:12.5:150,'LineStyle','none')
colormap(ax2,cmocean('deep',12))
clim([0 150])
xlim([t(2),t(480)])
ylim([-50,-45])
xlabel("Time (year)","FontSize",30,'FontName','Times New Roman')
ax2.TickDir = 'out';
title('(b) Zonal mean interface depth anomaly','FontSize',28,'FontName','Times New Roman')
ax = gca;
ax.TitleHorizontalAlignment = 'left';

xc = get(gca,'XColor');
yc = get(gca,'YColor');
unit = get(gca,'units');
ax = axes( 'Units', unit,...
'Position',get(gca,'Position'),...
'XAxisLocation','top',...
'YAxisLocation','right',...
'Color','none',...
'XColor',xc,...
'YColor',yc);
set(ax, 'linewidth',1,...
'XTick', [],...
'YTick', [],'Fontsize',12);
box on

h = colorbar(ax2,'horiz');
set(h, 'Position', [0.54 0.1 0.43 0.03]);
h.Label.String = 'm';
h.Label.FontSize = 30;
h.Label.FontName = 'Times New Roman';

%% h
% ax1 = subplot('Position', [0.1, 0.1, 0.25, 0.8]);
% set(ax1,'Fontsize',16,'FontName','Times New Roman')
% hold on
% 
% contourf(t,y,H,0:100:1600,'LineStyle','none')
% colormap(ax1,cmocean('deep',16))
% xlim([t(1),t(1200)])
% ylim([-60,-45])
% clim(ax1,[0 1600])
% % xlabel("Time (year)","FontSize",30,'FontName','Times New Roman')
% ylabel("Latitude (deg)","FontSize",30,'FontName','Times New Roman')
% ax1.TickDir = 'out';
% ax1.TitleHorizontalAlignment = 'left';
% 
% xc = get(gca,'XColor');
% yc = get(gca,'YColor');
% unit = get(gca,'units');
% ax = axes( 'Units', unit,...
% 'Position',get(gca,'Position'),...
% 'XAxisLocation','top',...
% 'YAxisLocation','right',...
% 'Color','none',...
% 'XColor',xc,...
% 'YColor',yc);
% set(ax, 'linewidth',1,...
% 'XTick', [],...
% 'YTick', [],'Fontsize',12);
% box on
% 
% ax2 = subplot('Position', [0.355, 0.1, 0.55, 0.8]);
% set(ax2,'Fontsize',16,'FontName','Times New Roman')
% hold on
% 
% contourf(t,y,H,0:100:1600,'LineStyle','none')
% colormap(ax2,cmocean('deep',16))
% h = colorbar(ax2);
% xlim([t(1201),t(end)])
% ylim([-60,-45])
% clim(ax2,[0 1600])
% ax2.YTick = [];
% ax2.TickDir = 'out';
% ax2.TitleHorizontalAlignment = 'left';
% 
% xc = get(gca,'XColor');
% yc = get(gca,'YColor');
% unit = get(gca,'units');
% ax = axes( 'Units', unit,...
% 'Position',get(gca,'Position'),...
% 'XAxisLocation','top',...
% 'YAxisLocation','right',...
% 'Color','none',...
% 'XColor',xc,...
% 'YColor',yc);
% set(ax, 'linewidth',1,...
% 'XTick', [],...
% 'YTick', [],'Fontsize',12);
% box on
% 
% set(h, 'Position', [0.925 0.1 0.015 0.8]);
% h.Label.String = 'Zonal mean interface depth (m)';
% h.Label.FontSize = 30;
% h.Label.FontName = 'Times New Roman';
% % h.Ticks = [0,low+(180-low)/10:(180-low)/10:180];
% % h.TickLabels = 0:20:200;
% 
% annotation('textbox', [0.1, 0.01, 0.805, 0.1], 'String', 'Time (year)', ...
%     'EdgeColor', 'none', 'FontName','Times New Roman','HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize',30);

%% 保存
% path = cd;
% exportgraphics(gcf, strcat(path,'\eddyDiffusion.jpg'));
% close;